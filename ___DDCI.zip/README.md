# DDCI: A DRL-Assisted Decentralized Framework for UAV Swarm Collaborative Inference

This repository contains the reference implementation accompanying the paper
*"A DRL-Assisted Decentralized Framework for UAV Swarm Collaborative Inference"*.
It provides the simulation environment, the DRL policy, all baseline strategies,
and the training/evaluation entry points needed to reproduce the main results.

> **Note.** In-code comments are partly in Chinese; the code, APIs, and CLI are in
> English. The implementation is self-contained and runs without the trained model
> checkpoints (which are omitted here for size).

## Overview

DDCI lets each UAV autonomously decide, per inference task, **which neighbor to
collaborate with** and **where to partition the DNN**, using a locally executed
Deep Q-Network. Two core mechanisms support the framework:

- **Pareto-optimal Top-K neighbor selection** — filters the variable-size neighbor
  set into a fixed-size candidate set by the non-dominated trade-off between
  communication distance and computational load, giving the DRL agent a
  fixed-dimensional action space.
- **Mini-batch pipeline execution** — overlaps local computation, feature-map
  transmission, and remote computation across successive images to reduce
  end-to-end latency.

## Repository structure

```
config/         Configuration objects and ConfigManager (simulation, drone, task, DRL)
tasks/          Hierarchical priority task queue, task generator, scheduler
models/         DNN partitioners and the mini-batch pipeline engine
environment/    Core simulation: collaboration env, Pareto selection, energy,
                signal attenuation, spatial (mobility) manager
communication/  Link/bandwidth and neighbor communication models
utils/          Latency calculator, performance metrics, statistical tools
baselines/      Baseline decision policies (Comm-Min/Neurosurgeon, CoDNN,
                Greedy-Load, EPCTA, Random, Local, and the EPCTA chain variant)
experiments/bandwidth_adaptive_training/
                DynamicTopologyEnv — the mobility-enabled evaluation environment
evaluation/     Full-metric evaluation script (reproduces the main comparison)
train_dqn_multi_network.py   Training entry point
```

## Requirements

- Python 3.10
- See `requirements.txt`. Key packages:
  `stable-baselines3==2.7.0`, `torch==2.5.1`, `gymnasium==1.1.1`,
  `numpy==2.0.1`, `scipy==1.15.3`, `matplotlib==3.10.1`.

```bash
pip install -r requirements.txt
```

## Training

Train the DDCI (DQN) policy for a given backbone network:

```bash
# Single network
python train_dqn_multi_network.py --network vgg-16 --timesteps 800000

# All networks used in the paper
python train_dqn_multi_network.py --network all --timesteps 800000
```

Supported `--network` values include `vgg-16`, `vgg-19`, `googlenet-22`,
`yolov5m`, and `resnext-101` (see `models/configurable_partitioner.py`).
Trained models and periodic evaluation checkpoints are written under
`drl_training_results/`.

## Evaluation environment

`DynamicTopologyEnv` (in `experiments/bandwidth_adaptive_training/`) is the
mobility-enabled environment used for all reported results. A minimal usage
sketch:

```python
from experiments.bandwidth_adaptive_training.dynamic_topology_env import DynamicTopologyEnv
from config import ConfigManager

env = DynamicTopologyEnv(
    config_manager=ConfigManager(), num_drones=10, k_neighbors=3,
    network_type='vgg-16', simulation_time=40.0, bandwidth_mbps=400.0,
    enable_mobility=True, move_every_n_steps=15, move_distance=50.0,
    move_probability=0.9,
)
obs, _ = env.reset(seed=0)
done = False
while not done:
    action = env.action_space.sample()   # replace with a trained policy
    obs, reward, terminated, truncated, info = env.step(action)
    done = terminated or truncated
print(info['deadline_sat_all'])
```

Baseline policies in `baselines/` expose a common `*_strategy(obs)` interface and
can be plugged into the same environment for comparison.

## Reproducing the paper's metrics

`evaluation/eval_full_metrics.py` reproduces the full-metric comparison table:
deadline / high-priority satisfaction, end-to-end P50/P95 latency, energy, and
failure/drop rates, together with the complete statistics (mean/std/CI95,
Cliff's delta effect size, and paired Wilcoxon tests with Holm correction).

```bash
# Pass the path (without .zip) to a trained DQN model per network; omit to skip.
python evaluation/eval_full_metrics.py path/to/vgg16_model [vgg19_model ...]
```

The default simulation parameters (10 UAVs, K=3 Pareto candidates, communication
range and bandwidth, mobility model) match those reported in the paper.
Satisfaction rates use the all-arrived-tasks denominator; latency is the
end-to-end value including queueing.

## License

Released for academic review and research use.
