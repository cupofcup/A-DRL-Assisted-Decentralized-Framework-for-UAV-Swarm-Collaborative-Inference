"""
Neighbor discovery and Top-3 candidate selection module.

Mathematical model based on CLAUDE.md:
- Candidate pre-screening: TopK(N_i(t), utility(.))
- Utility function: utility(u_j) = w1*(1-L_j/L_max) + w2*(1-d_{i,j}/d_max) + w3*Cap_j/Cap_max
- Top-3 candidate selection as the input to the DRL decision
"""

import math
import numpy as np
from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass
from enum import Enum

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from environment.spatial_manager import SpatialManager, DroneState, SpatialConfiguration, MovementPattern
from communication.communication_engine import CommunicationEngine, NetworkType, LinkQuality


@dataclass
class NeighborInfo:
    """Detailed neighbor information."""
    drone_id: str
    position: Tuple[float, float]
    distance: float
    communication_delay: float
    available_bandwidth: float
    processing_load: float
    battery_level: float
    reliability_score: float
    link_quality: LinkQuality


@dataclass
class CandidateScore:
    """Detailed candidate score."""
    drone_id: str
    utility_score: float
    load_factor: float      # load factor (lower is better)
    distance_factor: float  # distance factor (lower is better)
    capacity_factor: float  # capacity factor (higher is better)
    reliability_factor: float  # reliability factor (higher is better)
    final_rank: int        # final rank (1, 2, 3)


class SelectionStrategy(Enum):
    """Candidate selection strategy."""
    LOAD_BALANCED = "load_balanced"      # load-balancing priority
    DISTANCE_OPTIMAL = "distance_optimal"  # distance-optimization priority
    RELIABILITY_FIRST = "reliability_first"  # reliability priority
    COMPREHENSIVE = "comprehensive"       # composite score (default)


class NeighborDiscoveryManager:
    """
    Neighbor discovery manager.

    Responsible for:
    1. Integrating with the spatial manager to obtain the neighbor list
    2. Integrating with the communication engine to assess link quality
    3. Implementing the Top-K candidate selection algorithm
    4. Providing a fixed-dimension candidate feature matrix for the DRL
    5. Supporting multiple selection strategies and dynamic weight adjustment
    """

    def __init__(self, spatial_manager: SpatialManager,
                 communication_engine: CommunicationEngine,
                 K: int = 3):
        self.spatial_manager = spatial_manager
        self.comm_engine = communication_engine
        self.K = K  # number of Top-K candidates

        # Utility function weights (based on CLAUDE.md)
        self.utility_weights = {
            'load': 0.4,        # w1: load weight
            'distance': 0.3,    # w2: distance weight
            'capacity': 0.2,    # w3: capacity weight
            'reliability': 0.1  # w4: reliability weight
        }

        # Caching mechanism
        self.neighbor_cache: Dict[str, List[NeighborInfo]] = {}
        self.candidate_cache: Dict[str, List[CandidateScore]] = {}
        self.cache_ttl = 5.0  # cache time-to-live (seconds)
        self.last_update_time: Dict[str, float] = {}

        # Performance stats
        self.discovery_requests = 0
        self.cache_hits = 0
        
    def discover_neighbors(self, drone_id: str, refresh_cache: bool = False) -> List[NeighborInfo]:
        """
        Discover and analyze all neighbors.

        Args:
            drone_id: ID of the requesting drone
            refresh_cache: whether to force a cache refresh

        Returns:
            detailed list of neighbor information
        """
        self.discovery_requests += 1

        # Check the cache
        if not refresh_cache and self._is_cache_valid(drone_id, 'neighbor'):
            self.cache_hits += 1
            return self.neighbor_cache[drone_id]

        # Get the state of the requesting drone
        requester_drone = self.spatial_manager.get_drone_state(drone_id)
        if not requester_drone:
            return []

        # Get the list of neighbor IDs from the spatial manager
        neighbor_ids = self.spatial_manager.get_all_neighbors(drone_id)

        neighbor_infos = []

        for neighbor_id in neighbor_ids:
            neighbor_drone = self.spatial_manager.get_drone_state(neighbor_id)
            if not neighbor_drone or not neighbor_drone.is_active:
                continue

            # Compute the distance
            distance = self.spatial_manager.calculate_distance(drone_id, neighbor_id)

            # Assess the communication quality
            link_quality = self.comm_engine.assess_link_quality(
                requester_drone.position,
                neighbor_drone.position,
                NetworkType.WIFI_5  # default network type; should really be chosen by distance
            )

            # Create the neighbor info
            neighbor_info = NeighborInfo(
                drone_id=neighbor_id,
                position=neighbor_drone.position,
                distance=distance,
                communication_delay=link_quality.latency_ms / 1000,  # convert to seconds
                available_bandwidth=link_quality.available_bandwidth,
                processing_load=neighbor_drone.processing_load,
                battery_level=neighbor_drone.battery_level,
                reliability_score=link_quality.reliability_score,
                link_quality=link_quality
            )

            neighbor_infos.append(neighbor_info)

        # Update the cache
        self.neighbor_cache[drone_id] = neighbor_infos
        self.last_update_time[drone_id] = self.spatial_manager.current_time
        
        return neighbor_infos
        
    def select_top_candidates(self, drone_id: str, 
                            strategy: SelectionStrategy = SelectionStrategy.COMPREHENSIVE,
                            custom_weights: Optional[Dict[str, float]] = None) -> List[CandidateScore]:
        """
        Select the Top-K candidates.

        Args:
            drone_id: ID of the requesting drone
            strategy: selection strategy
            custom_weights: custom weights (optional)

        Returns:
            sorted list of Top-K candidates
        """
        # Check the cache
        cache_key = f"{drone_id}_{strategy.value}"
        if cache_key in self.candidate_cache and self._is_cache_valid(drone_id, 'candidate'):
            return self.candidate_cache[cache_key]

        # Get all neighbors
        neighbors = self.discover_neighbors(drone_id)

        if not neighbors:
            return []

        # Use the specified weights
        weights = custom_weights or self._get_strategy_weights(strategy)

        # Compute the utility score of each neighbor
        candidate_scores = []

        for neighbor in neighbors:
            score = self._calculate_utility_score(neighbor, weights)
            candidate_scores.append(score)

        # Sort by utility score and select the Top-K
        candidate_scores.sort(key=lambda x: x.utility_score, reverse=True)
        top_candidates = candidate_scores[:self.K]

        # Set the final rank
        for i, candidate in enumerate(top_candidates):
            candidate.final_rank = i + 1

        # Update the cache
        self.candidate_cache[cache_key] = top_candidates
        
        return top_candidates
        
    def get_candidate_feature_matrix(self, drone_id: str, 
                                   strategy: SelectionStrategy = SelectionStrategy.COMPREHENSIVE) -> np.ndarray:
        """
        Get the fixed-dimension candidate feature matrix, used as DRL input.

        Based on CLAUDE.md: S_neighbors in R^{K x 2} contains [distance_norm, load_rate]
        Extended to more features: [distance_norm, load_rate, reliability, battery_level]

        Args:
            drone_id: ID of the requesting drone
            strategy: selection strategy

        Returns:
            feature matrix of shape (K, 4); padded with 0 if there are fewer than K candidates
        """
        candidates = self.select_top_candidates(drone_id, strategy)

        # Initialize the feature matrix
        feature_matrix = np.zeros((self.K, 4))  # K x 4 features

        # Get the requesting drone's state (for normalization)
        requester_drone = self.spatial_manager.get_drone_state(drone_id)
        if not requester_drone:
            return feature_matrix

        max_comm_radius = requester_drone.communication_radius

        for i, candidate in enumerate(candidates):
            if i >= self.K:
                break

            # Normalize features to [0, 1]
            distance_norm = candidate.distance_factor  # already normalized
            load_rate = 1.0 - candidate.load_factor     # convert: higher load, lower rate
            reliability = candidate.reliability_factor

            # Battery level (obtained from the neighbor info)
            neighbor_info = next((n for n in self.neighbor_cache.get(drone_id, [])
                                if n.drone_id == candidate.drone_id), None)
            battery_level = neighbor_info.battery_level if neighbor_info else 0.5
            
            feature_matrix[i] = [distance_norm, load_rate, reliability, battery_level]
            
        return feature_matrix
        
    def _calculate_utility_score(self, neighbor: NeighborInfo, weights: Dict[str, float]) -> CandidateScore:
        """Compute the utility score of a neighbor."""
        # Load factor (lower is better)
        load_factor = neighbor.processing_load  # 0-1

        # Distance factor (normalized to 0-1, lower is better)
        max_distance = self.spatial_manager.config.default_comm_radius
        distance_factor = min(neighbor.distance / max_distance, 1.0)

        # Capacity factor (based on bandwidth, higher is better)
        max_bandwidth = 1000.0  # Mbps, assumed maximum bandwidth
        capacity_factor = min(neighbor.available_bandwidth / max_bandwidth, 1.0)

        # Reliability factor (already 0-1)
        reliability_factor = neighbor.reliability_score

        # Compute the weighted utility score (based on the CLAUDE.md formula)
        utility_score = (
            weights['load'] * (1 - load_factor) +          # lower load is better
            weights['distance'] * (1 - distance_factor) +   # closer distance is better
            weights['capacity'] * capacity_factor +         # stronger capacity is better
            weights['reliability'] * reliability_factor     # higher reliability is better
        )
        
        return CandidateScore(
            drone_id=neighbor.drone_id,
            utility_score=utility_score,
            load_factor=load_factor,
            distance_factor=distance_factor,
            capacity_factor=capacity_factor,
            reliability_factor=reliability_factor,
            final_rank=0  # set later
        )

    def _get_strategy_weights(self, strategy: SelectionStrategy) -> Dict[str, float]:
        """Get the weights for a given strategy."""
        if strategy == SelectionStrategy.LOAD_BALANCED:
            return {'load': 0.6, 'distance': 0.2, 'capacity': 0.1, 'reliability': 0.1}
        elif strategy == SelectionStrategy.DISTANCE_OPTIMAL:
            return {'load': 0.1, 'distance': 0.6, 'capacity': 0.2, 'reliability': 0.1}
        elif strategy == SelectionStrategy.RELIABILITY_FIRST:
            return {'load': 0.2, 'distance': 0.2, 'capacity': 0.1, 'reliability': 0.5}
        else:  # COMPREHENSIVE
            return self.utility_weights.copy()
            
    def _is_cache_valid(self, drone_id: str, cache_type: str) -> bool:
        """Check whether the cache is valid."""
        if drone_id not in self.last_update_time:
            return False

        elapsed_time = self.spatial_manager.current_time - self.last_update_time[drone_id]
        return elapsed_time < self.cache_ttl

    def update_utility_weights(self, new_weights: Dict[str, float]) -> None:
        """Update the utility function weights."""
        # Normalize the weights
        total_weight = sum(new_weights.values())
        if total_weight > 0:
            self.utility_weights = {k: v/total_weight for k, v in new_weights.items()}

        # Clear the cache
        self.candidate_cache.clear()

    def get_neighbor_statistics(self) -> Dict:
        """Get neighbor-discovery statistics."""
        cache_hit_rate = self.cache_hits / max(1, self.discovery_requests)
        
        return {
            'discovery_requests': self.discovery_requests,
            'cache_hits': self.cache_hits,
            'cache_hit_rate': cache_hit_rate,
            'cached_neighbors': len(self.neighbor_cache),
            'cached_candidates': len(self.candidate_cache),
            'current_weights': self.utility_weights.copy()
        }
        
    def clear_cache(self, drone_id: Optional[str] = None) -> None:
        """Clear the cache."""
        if drone_id:
            # Clear the cache of a specific drone
            self.neighbor_cache.pop(drone_id, None)
            self.last_update_time.pop(drone_id, None)

            # Clear the related candidate cache
            keys_to_remove = [k for k in self.candidate_cache.keys() if k.startswith(f"{drone_id}_")]
            for key in keys_to_remove:
                self.candidate_cache.pop(key, None)
        else:
            # Clear all caches
            self.neighbor_cache.clear()
            self.candidate_cache.clear()
            self.last_update_time.clear()


if __name__ == "__main__":
    # Test the neighbor discovery manager
    print("Testing Neighbor Discovery Manager...")
    print("=" * 70)

    # Modules are already imported at the top

    # Create the spatial manager
    spatial_config = SpatialConfiguration(
        area_bounds=((-300, -300), (300, 300)),
        default_comm_radius=200.0
    )
    spatial_manager = SpatialManager(spatial_config)
    
    # Create the communication engine
    comm_engine = CommunicationEngine()

    # Create the neighbor discovery manager
    neighbor_manager = NeighborDiscoveryManager(spatial_manager, comm_engine, K=3)

    # Register test drones
    test_drones = [
        ("DroneA", (0, 0), 0.2),      # center drone, medium load
        ("DroneB", (100, 0), 0.1),    # right, low load
        ("DroneC", (0, 100), 0.8),    # above, high load
        ("DroneD", (70, 70), 0.3),    # upper-right, medium-low load
        ("DroneE", (-120, 50), 0.5),  # upper-left, medium load
        ("DroneF", (180, 0), 0.4),    # far right, possibly out of communication range
    ]

    print("Registering test drones:")
    for drone_id, pos, load in test_drones:
        spatial_manager.register_drone(drone_id, pos)
        # Set the processing load
        drone_state = spatial_manager.get_drone_state(drone_id)
        if drone_state:
            drone_state.processing_load = load
        print(f"  {drone_id} at {pos}, load: {load}")

    print()

    # Update the spatial topology
    spatial_manager.update_topology()

    # Test neighbor discovery
    test_drone = "DroneA"
    print(f"Testing neighbor discovery for {test_drone}:")
    print("-" * 50)
    
    neighbors = neighbor_manager.discover_neighbors(test_drone)
    print(f"Found {len(neighbors)} neighbors:")
    
    for neighbor in neighbors:
        print(f"  {neighbor.drone_id}:")
        print(f"    Distance: {neighbor.distance:.1f}m")
        print(f"    Processing Load: {neighbor.processing_load:.1f}")
        print(f"    Bandwidth: {neighbor.available_bandwidth:.1f} Mbps")
        print(f"    Reliability: {neighbor.reliability_score:.3f}")
        print()
    
    # Test Top-3 candidate selection
    print("Testing Top-3 candidate selection:")
    print("-" * 50)
    
    strategies = [
        SelectionStrategy.COMPREHENSIVE,
        SelectionStrategy.LOAD_BALANCED,
        SelectionStrategy.DISTANCE_OPTIMAL,
        SelectionStrategy.RELIABILITY_FIRST
    ]
    
    for strategy in strategies:
        print(f"Strategy: {strategy.value}")
        candidates = neighbor_manager.select_top_candidates(test_drone, strategy)
        
        for i, candidate in enumerate(candidates):
            print(f"  Rank {candidate.final_rank}: {candidate.drone_id}")
            print(f"    Utility Score: {candidate.utility_score:.3f}")
            print(f"    Load Factor: {candidate.load_factor:.3f}")
            print(f"    Distance Factor: {candidate.distance_factor:.3f}")
            print(f"    Capacity Factor: {candidate.capacity_factor:.3f}")
            print()
            
    print()
    
    # Test the DRL feature matrix
    print("Testing DRL feature matrix:")
    print("-" * 50)
    
    feature_matrix = neighbor_manager.get_candidate_feature_matrix(test_drone)
    print(f"Feature matrix shape: {feature_matrix.shape}")
    print("Features: [distance_norm, load_rate, reliability, battery_level]")
    print(feature_matrix)
    print()
    
    # Performance stats
    stats = neighbor_manager.get_neighbor_statistics()
    print("Performance Statistics:")
    print("-" * 30)
    for key, value in stats.items():
        if isinstance(value, float):
            print(f"  {key}: {value:.3f}")
        elif isinstance(value, dict):
            print(f"  {key}: {value}")
        else:
            print(f"  {key}: {value}")
            
    print()
    print("Neighbor discovery manager ready for DRL integration!")