"""
Communication engine: realistic distance-latency modeling and network-condition simulation.

Mathematical model based on CLAUDE.md:
- comm_cost = data_size x distance x network_factor
- delay = propagation_delay + transmission_delay + processing_delay
- Supports multiple network types such as WiFi, 5G, and satellite
"""

import math
import time
import numpy as np
from typing import Tuple, Dict, List, Optional
from dataclasses import dataclass
from enum import Enum

class NetworkType(Enum):
    """Network type enumeration."""
    WIFI_4 = "WiFi4"      # 802.11n, ~50Mbps
    WIFI_5 = "WiFi5"      # 802.11ac, ~200Mbps
    WIFI_6 = "WiFi6"      # 802.11ax, ~1Gbps
    FIVEG = "5G"          # 5G NR, ~500Mbps
    SATELLITE = "Satellite"  # satellite communication, ~20Mbps, high latency

@dataclass
class LinkQuality:
    """Link quality assessment."""
    signal_strength: float      # dBm, signal strength
    snr: float                  # dB, signal-to-noise ratio
    packet_loss_rate: float     # 0-1, packet loss rate
    latency_ms: float          # ms, base latency
    available_bandwidth: float  # Mbps, available bandwidth
    reliability_score: float    # 0-1, reliability score

@dataclass
class CommunicationResult:
    """Communication result."""
    transmission_time: float    # seconds, transmission time
    propagation_delay: float    # seconds, propagation delay
    processing_delay: float     # seconds, processing delay
    total_delay: float         # seconds, total delay
    energy_cost: float         # joules, energy cost
    reliability: float         # 0-1, transmission reliability
    success_probability: float # 0-1, success probability

class CommunicationEngine:
    """
    Core communication engine class.

    Provides realistic communication-time modeling, accounting for:
    1. Distance-dependent propagation delay and signal attenuation
    2. Bandwidth and latency characteristics of the network type
    3. Environmental interference and multi-user contention
    4. Dynamic network-condition changes
    """

    def __init__(self):
        # Physical constants
        self.light_speed = 3e8  # speed of light, m/s
        self.rf_speed = 2.4e8   # radio signal propagation speed (~80% of light speed)

        # Network parameter configuration
        self.network_configs = self._initialize_network_configs()

        # Environment parameters
        self.base_noise_power = -90  # dBm, base noise power
        self.interference_factor = 0.1  # interference coefficient

        # Performance stats
        self.total_transmissions = 0
        self.successful_transmissions = 0

    def _initialize_network_configs(self) -> Dict[NetworkType, Dict]:
        """Initialize the configuration parameters for each network type."""
        return {
            NetworkType.WIFI_4: {
                'max_bandwidth': 50,      # Mbps
                'base_latency': 2,        # ms
                'max_range': 100,         # meters
                'tx_power': 20,           # dBm
                'frequency': 2.4,         # GHz
                'path_loss_exponent': 2.5,
                'processing_delay': 1,    # ms
            },
            NetworkType.WIFI_5: {
                'max_bandwidth': 200,
                'base_latency': 1.5,
                'max_range': 80,
                'tx_power': 23,
                'frequency': 5.0,
                'path_loss_exponent': 2.7,
                'processing_delay': 0.8,
            },
            NetworkType.WIFI_6: {
                'max_bandwidth': 1000,
                'base_latency': 1,
                'max_range': 120,
                'tx_power': 25,
                'frequency': 6.0,
                'path_loss_exponent': 2.4,
                'processing_delay': 0.5,
            },
            NetworkType.FIVEG: {
                'max_bandwidth': 500,
                'base_latency': 0.5,
                'max_range': 500,
                'tx_power': 30,
                'frequency': 28.0,  # mmWave
                'path_loss_exponent': 3.0,
                'processing_delay': 0.3,
            },
            NetworkType.SATELLITE: {
                'max_bandwidth': 20,
                'base_latency': 250,     # geostationary orbit delay
                'max_range': 50000,     # km scale
                'tx_power': 40,
                'frequency': 12.0,      # Ku band
                'path_loss_exponent': 2.0,  # free space
                'processing_delay': 5,
            }
        }
        
    def calculate_path_loss(self, distance_m: float, frequency_ghz: float, 
                          path_loss_exponent: float = 2.0) -> float:
        """Compute path loss (Free Space Path Loss + environmental factor)."""
        if distance_m <= 0:
            return 0

        # Free space path loss (dB)
        fspl = 20 * math.log10(distance_m) + 20 * math.log10(frequency_ghz) + 92.45

        # Environmental path loss (accounting for obstacles, atmospheric absorption, etc.)
        if distance_m > 1:  # avoid log(0)
            env_loss = 10 * path_loss_exponent * math.log10(distance_m / 1.0)
        else:
            env_loss = 0
            
        return fspl + env_loss
        
    def calculate_signal_strength(self, tx_power_dbm: float, distance_m: float,
                                frequency_ghz: float, path_loss_exponent: float) -> float:
        """Compute the received signal strength."""
        path_loss = self.calculate_path_loss(distance_m, frequency_ghz, path_loss_exponent)
        received_power = tx_power_dbm - path_loss

        # Add shadow fading (log-normal distribution)
        shadow_fading = np.random.normal(0, 4)  # standard deviation 4dB

        return received_power + shadow_fading

    def calculate_snr(self, signal_power_dbm: float, interference_power_dbm: float = None) -> float:
        """Compute the signal-to-noise ratio."""
        if interference_power_dbm is None:
            interference_power_dbm = self.base_noise_power

        # Account for thermal noise and interference
        noise_power = interference_power_dbm + 10 * math.log10(1 + self.interference_factor)
        snr = signal_power_dbm - noise_power

        return max(snr, -20)  # cap the minimum SNR at -20dB

    def calculate_available_bandwidth(self, network_type: NetworkType, snr_db: float,
                                    distance_m: float) -> float:
        """Compute available bandwidth based on SNR and distance."""
        config = self.network_configs[network_type]
        max_bw = config['max_bandwidth']
        max_range = config['max_range']

        # SNR-based bandwidth attenuation (Shannon Capacity inspired)
        if snr_db > 20:
            snr_factor = 1.0
        elif snr_db > 10:
            snr_factor = 0.8
        elif snr_db > 0:
            snr_factor = 0.5
        else:
            snr_factor = 0.2
            
        # Distance-based attenuation
        if distance_m > max_range:
            return 0  # out of communication range

        distance_factor = max(0.1, 1 - (distance_m / max_range) ** 2)

        # Account for network congestion (simple model)
        congestion_factor = np.random.uniform(0.7, 1.0)

        available_bw = max_bw * snr_factor * distance_factor * congestion_factor

        return max(available_bw, 0.1)  # minimum guaranteed bandwidth

    def calculate_packet_loss_rate(self, snr_db: float, distance_m: float,
                                 network_type: NetworkType) -> float:
        """Compute the packet loss rate."""
        config = self.network_configs[network_type]
        max_range = config['max_range']

        # SNR-based packet loss rate
        if snr_db > 15:
            snr_loss = 0.001
        elif snr_db > 5:
            snr_loss = 0.01
        elif snr_db > -5:
            snr_loss = 0.05
        else:
            snr_loss = 0.2
            
        # Distance-based packet loss rate
        distance_ratio = min(distance_m / max_range, 1.0)
        distance_loss = distance_ratio * 0.02

        total_loss = min(snr_loss + distance_loss, 0.5)  # maximum 50%

        return total_loss

    def assess_link_quality(self, src_pos: Tuple[float, float],
                          dst_pos: Tuple[float, float],
                          network_type: NetworkType) -> LinkQuality:
        """Assess the link quality between two points."""
        # Compute the distance
        distance = math.sqrt((dst_pos[0] - src_pos[0])**2 + (dst_pos[1] - src_pos[1])**2)

        config = self.network_configs[network_type]

        # Signal strength
        signal_strength = self.calculate_signal_strength(
            config['tx_power'], distance,
            config['frequency'], config['path_loss_exponent']
        )

        # Signal-to-noise ratio
        snr = self.calculate_snr(signal_strength)

        # Available bandwidth
        available_bw = self.calculate_available_bandwidth(network_type, snr, distance)

        # Packet loss rate
        packet_loss = self.calculate_packet_loss_rate(snr, distance, network_type)

        # Base latency
        propagation_delay = distance / self.rf_speed * 1000  # ms
        base_latency_ms = config['base_latency'] + propagation_delay

        # Reliability score (0-1)
        reliability = max(0, min(1, (snr + 10) / 30)) * (1 - packet_loss)
        
        return LinkQuality(
            signal_strength=signal_strength,
            snr=snr,
            packet_loss_rate=packet_loss,
            latency_ms=base_latency_ms,
            available_bandwidth=available_bw,
            reliability_score=reliability
        )
        
    def calculate_transmission_time(self, data_size_bytes: int,
                                  src_pos: Tuple[float, float],
                                  dst_pos: Tuple[float, float], 
                                  network_type: NetworkType = NetworkType.WIFI_5) -> CommunicationResult:
        """
        Compute the full communication time.

        Args:
            data_size_bytes: data size (bytes)
            src_pos: source drone position (x, y)
            dst_pos: destination drone position (x, y)
            network_type: network type

        Returns:
            CommunicationResult: detailed communication result
        """
        # Assess link quality
        link_quality = self.assess_link_quality(src_pos, dst_pos, network_type)

        # Check whether within communication range
        distance = math.sqrt((dst_pos[0] - src_pos[0])**2 + (dst_pos[1] - src_pos[1])**2)
        config = self.network_configs[network_type]
        
        if distance > config['max_range']:
            return CommunicationResult(
                transmission_time=float('inf'),
                propagation_delay=float('inf'),
                processing_delay=0,
                total_delay=float('inf'),
                energy_cost=0,
                reliability=0,
                success_probability=0
            )
            
        # Propagation delay
        propagation_delay = distance / self.rf_speed  # seconds

        # Transmission delay
        data_size_mbits = data_size_bytes * 8 / 1e6  # Mbits
        transmission_time = data_size_mbits / link_quality.available_bandwidth  # seconds

        # Account for retransmission (based on packet loss rate)
        retransmission_factor = 1 / (1 - link_quality.packet_loss_rate + 1e-6)
        transmission_time *= retransmission_factor

        # Processing delay
        processing_delay = config['processing_delay'] / 1000  # convert to seconds

        # Total delay
        total_delay = propagation_delay + transmission_time + processing_delay

        # Energy modeling (simplified)
        tx_power_watts = 10 ** (config['tx_power'] / 10) / 1000  # convert to watts
        energy_cost = tx_power_watts * total_delay  # joules

        # Success probability
        success_prob = (1 - link_quality.packet_loss_rate) * link_quality.reliability_score

        # Update stats
        self.total_transmissions += 1
        if success_prob > 0.8:
            self.successful_transmissions += 1
            
        return CommunicationResult(
            transmission_time=transmission_time,
            propagation_delay=propagation_delay,
            processing_delay=processing_delay,
            total_delay=total_delay,
            energy_cost=energy_cost,
            reliability=link_quality.reliability_score,
            success_probability=success_prob
        )
        
    def get_optimal_network_type(self, src_pos: Tuple[float, float],
                                dst_pos: Tuple[float, float],
                                data_size_bytes: int,
                                priority_factor: str = "latency") -> NetworkType:
        """Select the optimal network type."""
        distance = math.sqrt((dst_pos[0] - src_pos[0])**2 + (dst_pos[1] - src_pos[1])**2)

        # Test all available network types
        candidates = []
        for net_type in NetworkType:
            if distance <= self.network_configs[net_type]['max_range']:
                result = self.calculate_transmission_time(data_size_bytes, src_pos, dst_pos, net_type)
                candidates.append((net_type, result))

        if not candidates:
            return NetworkType.SATELLITE  # last resort

        # Select based on the priority factor
        if priority_factor == "latency":
            best = min(candidates, key=lambda x: x[1].total_delay)
        elif priority_factor == "bandwidth":
            best = max(candidates, key=lambda x: 1/x[1].transmission_time)
        elif priority_factor == "reliability":
            best = max(candidates, key=lambda x: x[1].reliability)
        else:  # composite score
            best = max(candidates, key=lambda x: x[1].success_probability / (x[1].total_delay + 1e-6))
            
        return best[0]
        
    def get_communication_cost(self, data_size_bytes: int,
                             src_pos: Tuple[float, float], 
                             dst_pos: Tuple[float, float],
                             network_type: NetworkType = NetworkType.WIFI_5) -> float:
        """
        Compute the communication cost (used in the DRL reward function).

        Based on CLAUDE.md: comm_cost = data_size x distance x network_factor
        """
        distance = math.sqrt((dst_pos[0] - src_pos[0])**2 + (dst_pos[1] - src_pos[1])**2)

        # Network factor (weighted combination of delay and energy)
        result = self.calculate_transmission_time(data_size_bytes, src_pos, dst_pos, network_type)

        # Normalized cost (0-1 range)
        time_cost = min(result.total_delay / 10.0, 1.0)  # 10 seconds is the max delay
        energy_cost = min(result.energy_cost / 1.0, 1.0)  # 1 joule is the max energy
        reliability_penalty = 1 - result.reliability
        
        comm_cost = 0.4 * time_cost + 0.3 * energy_cost + 0.3 * reliability_penalty
        
        return comm_cost
        
    def get_performance_stats(self) -> Dict:
        """Get performance statistics."""
        success_rate = self.successful_transmissions / max(1, self.total_transmissions)
        
        return {
            'total_transmissions': self.total_transmissions,
            'successful_transmissions': self.successful_transmissions,
            'success_rate': success_rate,
            'supported_networks': list(self.network_configs.keys())
        }


if __name__ == "__main__":
    # Test the communication engine
    print("Testing Communication Engine...")
    print("=" * 60)

    engine = CommunicationEngine()

    # Test scenario: communication between two drones
    drone_a_pos = (0, 0)
    drone_b_pos = (100, 50)  # distance ~111 meters
    data_size = 1024 * 1024  # 1MB of data
    
    print(f"Test Scenario:")
    print(f"  DroneA position: {drone_a_pos}")
    print(f"  DroneB position: {drone_b_pos}")
    print(f"  Data size: {data_size/1024/1024:.1f}MB")
    print()
    
    # Test different network types
    print("Communication Performance by Network Type:")
    print("-" * 80)
    print(f"{'Network':<12} {'Total Delay(s)':<15} {'Bandwidth(Mbps)':<15} {'Reliability':<12} {'Success Rate':<12}")
    print("-" * 80)
    
    for network_type in NetworkType:
        result = engine.calculate_transmission_time(data_size, drone_a_pos, drone_b_pos, network_type)
        link_quality = engine.assess_link_quality(drone_a_pos, drone_b_pos, network_type)
        
        if result.total_delay < float('inf'):
            print(f"{network_type.value:<12} {result.total_delay:<15.3f} {link_quality.available_bandwidth:<15.1f} "
                  f"{result.reliability:<12.2f} {result.success_probability:<12.1%}")
        else:
            print(f"{network_type.value:<12} Out of Range")
    
    print()
    
    # Optimal network selection test
    optimal_network = engine.get_optimal_network_type(drone_a_pos, drone_b_pos, data_size, "latency")
    print(f"Optimal network for low latency: {optimal_network.value}")
    
    optimal_network_reliability = engine.get_optimal_network_type(drone_a_pos, drone_b_pos, data_size, "reliability")
    print(f"Optimal network for reliability: {optimal_network_reliability.value}")
    
    # Communication cost test
    comm_cost = engine.get_communication_cost(data_size, drone_a_pos, drone_b_pos)
    print(f"Communication cost (normalized): {comm_cost:.3f}")
    
    print("\n" + "=" * 60)
    print("Communication engine ready for spatial management integration!")