"""
Network models: detailed modeling of different communication technologies.

Provides technology-specific parameters and behavioral models for networks such as
WiFi, 5G, and satellite, supporting environmental-condition variation and interference modeling.
"""

import math
import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

@dataclass
class NetworkConditions:
    """Network environmental conditions."""
    weather_factor: float = 1.0      # weather impact factor (1.0=clear, >1.0=adverse)
    interference_level: float = 0.1  # interference level (0-1)
    user_density: float = 0.2        # user density (0-1, affects network congestion)
    time_of_day: float = 12.0       # time of day (0-24 hours)
    terrain_roughness: float = 0.1  # terrain roughness (0-1, affects signal propagation)

class WiFiModel:
    """WiFi network model (IEEE 802.11 family)."""

    def __init__(self, wifi_generation: str = "WiFi5"):
        self.generation = wifi_generation
        self.config = self._get_wifi_config(wifi_generation)

    def _get_wifi_config(self, generation: str) -> Dict:
        """Get the configuration for different WiFi generations."""
        configs = {
            "WiFi4": {  # 802.11n
                "max_bandwidth": 72.2,    # Mbps (theoretical)
                "typical_bandwidth": 50,   # Mbps (actual)
                "frequency_bands": [2.4, 5.0],  # GHz
                "channel_width": 40,       # MHz
                "mimo_streams": 4,
                "modulation": "64-QAM",
                "range_indoor": 70,        # meters
                "range_outdoor": 250,
            },
            "WiFi5": {  # 802.11ac
                "max_bandwidth": 433.3,
                "typical_bandwidth": 200,
                "frequency_bands": [5.0],
                "channel_width": 80,
                "mimo_streams": 8,
                "modulation": "256-QAM", 
                "range_indoor": 50,
                "range_outdoor": 150,
            },
            "WiFi6": {  # 802.11ax
                "max_bandwidth": 1201,
                "typical_bandwidth": 600,
                "frequency_bands": [2.4, 5.0, 6.0],
                "channel_width": 160,
                "mimo_streams": 8,
                "modulation": "1024-QAM",
                "range_indoor": 60,
                "range_outdoor": 180,
            }
        }
        return configs.get(generation, configs["WiFi5"])
        
    def calculate_throughput(self, distance: float, snr_db: float, 
                           conditions: NetworkConditions) -> float:
        """Compute WiFi throughput."""
        base_throughput = self.config["typical_bandwidth"]

        # Distance attenuation
        max_range = self.config["range_outdoor"]
        if distance > max_range:
            return 0

        distance_factor = max(0.1, 1 - (distance / max_range) ** 1.5)

        # SNR impact (based on the MCS table)
        if snr_db > 30:
            snr_factor = 1.0
        elif snr_db > 25:
            snr_factor = 0.85
        elif snr_db > 20:
            snr_factor = 0.65
        elif snr_db > 15:
            snr_factor = 0.45
        elif snr_db > 10:
            snr_factor = 0.25
        else:
            snr_factor = 0.1
            
        # Environmental condition impact
        weather_impact = 1 / conditions.weather_factor
        interference_impact = 1 - conditions.interference_level * 0.5
        congestion_impact = 1 - conditions.user_density * 0.6

        # Time-of-day impact (peak hours reduce performance)
        if 8 <= conditions.time_of_day <= 10 or 19 <= conditions.time_of_day <= 22:
            time_impact = 0.7  # peak hours
        else:
            time_impact = 1.0

        throughput = (base_throughput * distance_factor * snr_factor *
                     weather_impact * interference_impact * congestion_impact * time_impact)

        return max(throughput, 1.0)  # minimum 1Mbps

    def calculate_latency(self, distance: float, conditions: NetworkConditions) -> float:
        """Compute WiFi latency (milliseconds)."""
        # Base latency
        base_latency = 1.0  # ms

        # Propagation delay
        propagation_delay = distance / (3e8 * 0.8) * 1000  # ms

        # Processing delay (increases with user density)
        processing_delay = 0.5 + conditions.user_density * 2.0

        # Congestion delay
        congestion_delay = conditions.user_density * conditions.interference_level * 5.0
        
        total_latency = base_latency + propagation_delay + processing_delay + congestion_delay
        
        return total_latency

class FiveGModel:
    """5G network model (5G NR)."""

    def __init__(self, frequency_band: str = "sub6"):
        self.band = frequency_band  # "sub6" or "mmwave"
        self.config = self._get_5g_config(frequency_band)

    def _get_5g_config(self, band: str) -> Dict:
        """Get the configuration for different 5G frequency bands."""
        configs = {
            "sub6": {  # Sub-6 GHz
                "max_bandwidth": 1000,    # Mbps
                "typical_bandwidth": 300,
                "frequency": 3.5,         # GHz
                "range": 2000,           # meters
                "penetration": "good",    # penetration capability
                "latency": 1,            # ms
            },
            "mmwave": {  # mmWave (24-40 GHz)
                "max_bandwidth": 4000,
                "typical_bandwidth": 1500,
                "frequency": 28.0,
                "range": 300,
                "penetration": "poor",
                "latency": 0.5,
            }
        }
        return configs.get(band, configs["sub6"])
        
    def calculate_throughput(self, distance: float, snr_db: float,
                           conditions: NetworkConditions) -> float:
        """Compute 5G throughput."""
        base_throughput = self.config["typical_bandwidth"]
        max_range = self.config["range"]

        if distance > max_range:
            return 0

        # Distance attenuation (mmWave attenuates faster)
        if self.band == "mmwave":
            distance_factor = max(0.05, math.exp(-distance / 100))
        else:
            distance_factor = max(0.1, 1 - (distance / max_range) ** 1.2)

        # SNR impact (5G has higher SNR requirements)
        if snr_db > 25:
            snr_factor = 1.0
        elif snr_db > 20:
            snr_factor = 0.8
        elif snr_db > 15:
            snr_factor = 0.6
        elif snr_db > 10:
            snr_factor = 0.3
        else:
            snr_factor = 0.1
            
        # Environmental conditions (mmWave is more weather-sensitive)
        if self.band == "mmwave":
            weather_impact = 1 / (conditions.weather_factor ** 1.5)
        else:
            weather_impact = 1 / conditions.weather_factor

        interference_impact = 1 - conditions.interference_level * 0.3
        congestion_impact = 1 - conditions.user_density * 0.4  # 5G has strong congestion resistance

        throughput = (base_throughput * distance_factor * snr_factor *
                     weather_impact * interference_impact * congestion_impact)

        return max(throughput, 5.0)  # 5G minimum 5Mbps

    def calculate_latency(self, distance: float, conditions: NetworkConditions) -> float:
        """Compute 5G latency (milliseconds)."""
        base_latency = self.config["latency"]

        # Propagation delay
        propagation_delay = distance / (3e8 * 0.9) * 1000  # ms

        # Network processing delay (5G optimized)
        processing_delay = 0.1 + conditions.user_density * 0.5

        # Edge-computing acceleration (reduces latency)
        edge_acceleration = -0.2 if conditions.user_density < 0.5 else 0

        total_latency = base_latency + propagation_delay + processing_delay + edge_acceleration

        return max(total_latency, 0.1)  # minimum 0.1ms

class SatelliteModel:
    """Satellite communication model."""

    def __init__(self, orbit_type: str = "GEO"):
        self.orbit = orbit_type  # "GEO", "LEO", "MEO"
        self.config = self._get_satellite_config(orbit_type)

    def _get_satellite_config(self, orbit: str) -> Dict:
        """Get the configuration for satellites in different orbits."""
        configs = {
            "GEO": {  # geostationary orbit (35,786 km)
                "altitude": 35786000,     # meters
                "max_bandwidth": 50,      # Mbps
                "typical_bandwidth": 20,
                "latency": 250,          # ms (round-trip delay)
                "coverage": "global",
                "weather_sensitive": True,
            },
            "LEO": {  # low Earth orbit (500-2000 km)
                "altitude": 550000,       # Starlink average altitude
                "max_bandwidth": 150,
                "typical_bandwidth": 100,
                "latency": 20,
                "coverage": "regional",
                "weather_sensitive": False,
            },
            "MEO": {  # medium Earth orbit (2000-35786 km)
                "altitude": 20000000,     # O3b orbit
                "max_bandwidth": 100,
                "typical_bandwidth": 50,
                "latency": 130,
                "coverage": "regional",
                "weather_sensitive": True,
            }
        }
        return configs.get(orbit, configs["LEO"])
        
    def calculate_throughput(self, distance: float, snr_db: float,
                           conditions: NetworkConditions) -> float:
        """Compute satellite communication throughput."""
        base_throughput = self.config["typical_bandwidth"]

        # Satellite communication is not affected by ground distance; signal quality is what matters
        if snr_db > 15:
            snr_factor = 1.0
        elif snr_db > 10:
            snr_factor = 0.7
        elif snr_db > 5:
            snr_factor = 0.4
        else:
            snr_factor = 0.1

        # Weather impact (especially rain attenuation)
        if self.config["weather_sensitive"]:
            weather_impact = 1 / (conditions.weather_factor ** 2)
        else:
            weather_impact = 1 / conditions.weather_factor ** 0.5

        # Satellite communication has strong interference resistance
        interference_impact = 1 - conditions.interference_level * 0.1

        # User congestion impact
        congestion_impact = 1 - conditions.user_density * 0.3
        
        throughput = (base_throughput * snr_factor * weather_impact * 
                     interference_impact * congestion_impact)
        
        return max(throughput, 1.0)
        
    def calculate_latency(self, distance: float, conditions: NetworkConditions) -> float:
        """Compute satellite latency (milliseconds)."""
        # Base orbital delay (already includes round-trip time)
        base_latency = self.config["latency"]

        # Ground-segment processing delay
        ground_processing = 5 + conditions.user_density * 10

        # Weather delay (ionospheric and tropospheric effects)
        weather_delay = (conditions.weather_factor - 1) * 20
        
        total_latency = base_latency + ground_processing + weather_delay
        
        return total_latency


def create_adaptive_network_selector(conditions: NetworkConditions) -> callable:
    """Create an adaptive network selector."""

    def select_best_network(distance: float, data_size: int, priority: str = "balanced") -> str:
        """
        Select the best network based on conditions.

        Args:
            distance: communication distance (m)
            data_size: data size (bytes)
            priority: priority ("latency", "bandwidth", "reliability", "balanced")
        """
        # Initialize all network models
        wifi5 = WiFiModel("WiFi5")
        wifi6 = WiFiModel("WiFi6")
        fiveg_sub6 = FiveGModel("sub6")
        fiveg_mmwave = FiveGModel("mmwave")
        leo_satellite = SatelliteModel("LEO")
        
        models = {
            "WiFi5": wifi5,
            "WiFi6": wifi6, 
            "5G_Sub6": fiveg_sub6,
            "5G_mmWave": fiveg_mmwave,
            "LEO_Satellite": leo_satellite
        }
        
        # Evaluate each network
        scores = {}
        for name, model in models.items():
            # Assume SNR of 15dB (medium signal quality)
            throughput = model.calculate_throughput(distance, 15, conditions)
            latency = model.calculate_latency(distance, conditions)

            if throughput == 0:  # out of range
                scores[name] = 0
                continue

            # Compute the transmission time
            data_mbits = data_size * 8 / 1e6
            transmission_time = data_mbits / throughput  # seconds

            # Composite score
            if priority == "latency":
                score = 1 / (latency / 1000 + transmission_time + 1e-6)
            elif priority == "bandwidth":
                score = throughput
            elif priority == "reliability":
                # Satellite and 5G are usually more reliable
                reliability_bonus = 1.2 if "5G" in name or "Satellite" in name else 1.0
                score = throughput * reliability_bonus / (latency + 1)
            else:  # balanced
                # Composite score: throughput / (latency * transmission time)
                score = throughput / (latency / 1000 + transmission_time + 1e-6)

            scores[name] = score

        # Select the best network
        if not scores or max(scores.values()) == 0:
            return "LEO_Satellite"  # fallback option
            
        best_network = max(scores.keys(), key=lambda k: scores[k])
        return best_network
        
    return select_best_network


if __name__ == "__main__":
    # Test the network models
    print("Testing Network Models...")
    print("=" * 60)

    # Test conditions
    conditions = NetworkConditions(
        weather_factor=1.2,      # mildly adverse weather
        interference_level=0.3,  # medium interference
        user_density=0.4,        # medium user density
        time_of_day=14.0,        # 2 PM
        terrain_roughness=0.2
    )

    distance = 200  # 200-meter distance
    snr = 20       # 20dB signal-to-noise ratio
    data_size = 5 * 1024 * 1024  # 5MB of data
    
    print(f"Test Conditions:")
    print(f"  Distance: {distance}m")
    print(f"  SNR: {snr}dB") 
    print(f"  Data size: {data_size/1024/1024:.1f}MB")
    print(f"  Weather factor: {conditions.weather_factor}")
    print(f"  Interference: {conditions.interference_level}")
    print()
    
    # Test the various network models
    models = [
        ("WiFi5", WiFiModel("WiFi5")),
        ("WiFi6", WiFiModel("WiFi6")),
        ("5G Sub6", FiveGModel("sub6")),
        ("5G mmWave", FiveGModel("mmwave")),
        ("LEO Satellite", SatelliteModel("LEO"))
    ]
    
    print("Network Performance Comparison:")
    print("-" * 80)
    print(f"{'Network':<15} {'Throughput(Mbps)':<18} {'Latency(ms)':<12} {'Transfer Time(s)':<15}")
    print("-" * 80)
    
    for name, model in models:
        throughput = model.calculate_throughput(distance, snr, conditions)
        latency = model.calculate_latency(distance, conditions)
        
        if throughput > 0:
            transfer_time = (data_size * 8 / 1e6) / throughput  # seconds
            print(f"{name:<15} {throughput:<18.1f} {latency:<12.1f} {transfer_time:<15.2f}")
        else:
            print(f"{name:<15} Out of Range")
            
    print()
    
    # Test the adaptive selector
    selector = create_adaptive_network_selector(conditions)
    
    priorities = ["latency", "bandwidth", "reliability", "balanced"]
    print("Adaptive Network Selection:")
    print("-" * 40)
    
    for priority in priorities:
        best_network = selector(distance, data_size, priority)
        print(f"  {priority.capitalize():<12}: {best_network}")
        
    print("\n" + "=" * 60)
    print("Network models ready for communication engine integration!")