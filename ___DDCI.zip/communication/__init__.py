"""
Communication module for drone collaborative inference.

This module provides:
- Distance-based communication delay modeling
- Network condition simulation (WiFi, 5G, satellite)
- Dynamic bandwidth calculation with interference
- Link quality assessment for neighbor selection
- Integration with spatial management and DRL decision making

Based on CLAUDE.md mathematical models:
- comm_cost = data_size × distance × network_factor  
- delay = propagation_delay + transmission_delay + processing_delay
"""

from .communication_engine import (
    NetworkType,
    LinkQuality,
    CommunicationResult,
    CommunicationEngine
)

from .network_models import (
    WiFiModel,
    FiveGModel, 
    SatelliteModel,
    NetworkConditions,
    create_adaptive_network_selector
)

from .neighbor_manager import (
    NeighborDiscoveryManager,
    NeighborInfo,
    CandidateScore,
    SelectionStrategy
)

__all__ = [
    # Core communication
    'NetworkType',
    'LinkQuality', 
    'CommunicationResult',
    'CommunicationEngine',
    
    # Network models
    'WiFiModel',
    'FiveGModel',
    'SatelliteModel', 
    'NetworkConditions',
    'create_adaptive_network_selector',
    
    # Neighbor discovery
    'NeighborDiscoveryManager',
    'NeighborInfo',
    'CandidateScore',
    'SelectionStrategy',
]