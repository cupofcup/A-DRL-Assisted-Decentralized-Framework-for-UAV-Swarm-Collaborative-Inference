"""
Models module for ResNet collaborative inference based on CLAUDE.md.

This module provides:
- ResNetPartitioner: Layer-wise partitioning with FLOPS calculation
- MiniBatchPipelineEngine: True minibatch pipeline with overlapping execution  
- SerialInferenceEngine: Sequential processing baseline
- Support for optimal load balancing and communication modeling
"""

from .resnet_partitioner import (
    ResNetLayer,
    ResNetLayerSpec,
    ResNetPartitionResult,
    ResNetPartitioner
)

from .minibatch_pipeline_engine import (
    MiniBatch,
    DroneNode,
    MiniBatchPipelineEngine
)

from .serial_inference_engine import (
    SerialInferenceEngine
)

__all__ = [
    # ResNet partitioning
    'ResNetLayer',
    'ResNetLayerSpec', 
    'ResNetPartitionResult',
    'ResNetPartitioner',
    
    # Minibatch pipeline
    'MiniBatch',
    'DroneNode',
    'MiniBatchPipelineEngine',
    
    # Serial processing
    'SerialInferenceEngine',
]