"""
True mini-batch pipeline engine implementation.

Core idea:
1. Break a large batch into small mini-batches
2. As soon as DroneA finishes a mini-batch, it forwards it to DroneB
3. Achieve genuine overlapped execution, avoiding DroneB idling
4. ResNet-based model partitioning
"""

import torch
import time
import threading
import queue
import numpy as np
from typing import List, Dict, Tuple, Optional, Callable
from dataclasses import dataclass
from enum import Enum
from concurrent.futures import ThreadPoolExecutor, Future
import uuid

from .resnet_partitioner import ResNetPartitioner, ResNetLayer

@dataclass
class MiniBatch:
    """Mini-batch data structure."""
    batch_id: str
    data: torch.Tensor  # shape: (mini_batch_size, C, H, W)
    sequence_number: int  # index within the large batch
    start_time: float = 0.0
    part_a_completion_time: float = 0.0
    communication_start_time: float = 0.0
    communication_end_time: float = 0.0
    part_b_completion_time: float = 0.0
    
    # Intermediate results
    intermediate_result: Optional[torch.Tensor] = None
    final_result: Optional[torch.Tensor] = None

@dataclass
class DroneNode:
    """Drone node definition."""
    drone_id: str
    capacity: float  # FLOPS per second
    position: Tuple[float, float]

    # Runtime state
    is_busy: bool = False
    current_mini_batch: Optional[str] = None
    processed_mini_batches: int = 0

class MiniBatchPipelineEngine:
    """
    True mini-batch pipeline engine.

    Workflow:
    1. Split a large batch into multiple mini-batches (e.g. 32 -> 8 mini-batches of 4 samples each)
    2. DroneA processes Part A of mini-batch 1
    3. On completion it immediately forwards to DroneB while DroneA starts mini-batch 2
    4. DroneB processes Part B of mini-batch 1 while DroneA processes Part A of mini-batch 2
    5. This forms genuine overlapped pipeline execution
    """

    def __init__(self, mini_batch_size: int = 4):
        self.mini_batch_size = mini_batch_size
        self.partitioner = ResNetPartitioner()

        # Drone management
        self.drone_a: Optional[DroneNode] = None
        self.drone_b: Optional[DroneNode] = None

        # Pipeline queues
        self.part_a_queue = queue.Queue()  # DroneA -> DroneB data queue
        self.completed_queue = queue.Queue()  # final result queue

        # Performance stats
        self.total_mini_batches_processed = 0
        self.total_pipeline_time = 0.0

        # Synchronization control
        self.pipeline_active = False
        self.stop_event = threading.Event()
        
    def register_drones(self, drone_a_capacity: float, drone_b_capacity: float,
                       pos_a: Tuple[float, float] = (0, 0), 
                       pos_b: Tuple[float, float] = (50, 50)):
        """Register two collaborating drones."""
        self.drone_a = DroneNode("DroneA", drone_a_capacity, pos_a)
        self.drone_b = DroneNode("DroneB", drone_b_capacity, pos_b)
        
        print(f"Registered DroneA: {drone_a_capacity:.0e} FLOPS/s at {pos_a}")
        print(f"Registered DroneB: {drone_b_capacity:.0e} FLOPS/s at {pos_b}")
        
    def split_into_mini_batches(self, input_tensor: torch.Tensor) -> List[MiniBatch]:
        """Split a large batch into a fixed set of 4 mini-batches."""
        batch_size = input_tensor.shape[0]
        mini_batches = []

        # Fixed split into 4 mini-batches
        fixed_groups = 4
        samples_per_group = batch_size // fixed_groups
        remainder = batch_size % fixed_groups

        start_idx = 0
        for group_idx in range(fixed_groups):
            # The first few groups may get one extra sample (handling the remainder)
            current_group_size = samples_per_group + (1 if group_idx < remainder else 0)
            end_idx = start_idx + current_group_size

            if start_idx < batch_size:  # ensure we stay in range
                mini_data = input_tensor[start_idx:end_idx]
                
                mini_batch = MiniBatch(
                    batch_id=str(uuid.uuid4())[:8],
                    data=mini_data,
                    sequence_number=group_idx
                )
                mini_batches.append(mini_batch)
                
                start_idx = end_idx
        
        return mini_batches
        
    def calculate_communication_time(self, data_size: int) -> float:
        """Compute the communication time."""
        # Assume a high-speed network: 100MB/s
        bandwidth_mbps = 100.0
        data_mb = data_size / (1024 * 1024)
        return data_mb / bandwidth_mbps
        
    def process_part_a(self, mini_batch: MiniBatch, cut_layer: ResNetLayer) -> bool:
        """DroneA processes Part A."""
        if not self.drone_a:
            return False

        # Get the partition info
        partition = self.partitioner.partition_at_layer(cut_layer)

        # Mark start of processing
        mini_batch.start_time = time.time()
        self.drone_a.is_busy = True
        self.drone_a.current_mini_batch = mini_batch.batch_id

        # Compute the processing time (based on the number of samples in the mini-batch)
        actual_mini_batch_size = mini_batch.data.shape[0]
        part_a_flops = partition.part_a_flops * actual_mini_batch_size
        processing_time = part_a_flops / self.drone_a.capacity

        # Theoretical computation: remove the real sleep, compute the theoretical completion time directly
        # actual_sleep = min(processing_time, 0.05)  # removed
        # time.sleep(actual_sleep)  # removed real delay

        # Generate the intermediate result
        intermediate_shape = partition.intermediate_shape
        mini_batch.intermediate_result = torch.randn(actual_mini_batch_size, *intermediate_shape)
        # Use the theoretical processing time to compute the completion time
        mini_batch.part_a_completion_time = mini_batch.start_time + processing_time

        # Update stats
        self.drone_a.processed_mini_batches += 1
        self.drone_a.is_busy = False
        self.drone_a.current_mini_batch = None
        
        return True
        
    def process_part_b(self, mini_batch: MiniBatch, cut_layer: ResNetLayer) -> bool:
        """DroneB processes Part B."""
        if not self.drone_b or mini_batch.intermediate_result is None:
            return False

        # Get the partition info
        partition = self.partitioner.partition_at_layer(cut_layer)

        # Mark start of processing
        self.drone_b.is_busy = True
        self.drone_b.current_mini_batch = mini_batch.batch_id

        # Compute the processing time
        actual_mini_batch_size = mini_batch.intermediate_result.shape[0]
        part_b_flops = partition.part_b_flops * actual_mini_batch_size
        processing_time = part_b_flops / self.drone_b.capacity

        # Theoretical computation: remove the real sleep, compute the theoretical completion time directly
        # actual_sleep = min(processing_time, 0.05)  # removed
        # time.sleep(actual_sleep)  # removed real delay

        # Generate the final result
        mini_batch.final_result = torch.randn(actual_mini_batch_size, 1000)  # ResNet output
        # Use the theoretical processing time to compute the completion time (starting from the communication end time)
        mini_batch.part_b_completion_time = mini_batch.communication_end_time + processing_time

        # Update stats
        self.drone_b.processed_mini_batches += 1
        self.drone_b.is_busy = False
        self.drone_b.current_mini_batch = None
        
        return True
        
    def simulate_communication(self, mini_batch: MiniBatch, cut_layer: ResNetLayer) -> bool:
        """Simulate the communication process."""
        if mini_batch.intermediate_result is None:
            return False

        mini_batch.communication_start_time = mini_batch.part_a_completion_time

        # Compute the communication time
        data_size = mini_batch.intermediate_result.numel() * 4  # float32 = 4 bytes
        comm_time = self.calculate_communication_time(data_size)

        # Theoretical computation: remove the real sleep, compute the theoretical completion time directly
        # actual_sleep = min(comm_time, 0.01)  # removed
        # time.sleep(actual_sleep)  # removed real delay

        # Use the theoretical communication time to compute the completion time
        mini_batch.communication_end_time = mini_batch.communication_start_time + comm_time
        return True
        
    def drone_a_worker(self, mini_batches: List[MiniBatch], cut_layer: ResNetLayer):
        """DroneA worker thread: process Part A of all mini-batches."""
        for mini_batch in mini_batches:
            if self.stop_event.is_set():
                break

            # Process Part A
            if self.process_part_a(mini_batch, cut_layer):
                # Immediately forward to DroneB (via the queue)
                self.part_a_queue.put(mini_batch)
            else:
                print(f"DroneA failed to process mini-batch {mini_batch.batch_id}")

        # Send the end signal
        self.part_a_queue.put(None)

    def drone_b_worker(self, cut_layer: ResNetLayer):
        """DroneB worker thread: process the mini-batches forwarded from DroneA."""
        while not self.stop_event.is_set():
            try:
                # Get a mini-batch from the queue (blocking wait)
                mini_batch = self.part_a_queue.get(timeout=1.0)

                if mini_batch is None:  # end signal
                    break

                # Simulate communication
                if self.simulate_communication(mini_batch, cut_layer):
                    # Process Part B
                    if self.process_part_b(mini_batch, cut_layer):
                        # Put the completed mini-batch into the result queue
                        self.completed_queue.put(mini_batch)
                        self.total_mini_batches_processed += 1
                    else:
                        print(f"DroneB failed to process mini-batch {mini_batch.batch_id}")
                        
                self.part_a_queue.task_done()
                
            except queue.Empty:
                continue
                
    def execute_pipeline(self, input_tensor: torch.Tensor, cut_layer: ResNetLayer) -> Dict:
        """Execute the true mini-batch pipeline."""
        if not self.drone_a or not self.drone_b:
            return {'success': False, 'error': 'Drones not registered'}

        # Split into mini-batches
        mini_batches = self.split_into_mini_batches(input_tensor)
        total_mini_batches = len(mini_batches)

        print(f"Split {input_tensor.shape[0]} samples into {total_mini_batches} mini-batches of size {self.mini_batch_size}")

        # Reset state
        self.stop_event.clear()
        self.total_mini_batches_processed = 0

        # Clear the queues
        while not self.part_a_queue.empty():
            self.part_a_queue.get()
        while not self.completed_queue.empty():
            self.completed_queue.get()

        start_time = time.time()

        # Start the two worker threads
        with ThreadPoolExecutor(max_workers=2) as executor:
            # DroneA thread: process Part A of all mini-batches
            future_a = executor.submit(self.drone_a_worker, mini_batches, cut_layer)

            # DroneB thread: process the data forwarded from DroneA
            future_b = executor.submit(self.drone_b_worker, cut_layer)

            # Wait for DroneA to finish all Part A processing
            future_a.result()

            # Wait for DroneB to finish processing all data
            future_b.result()

        end_time = time.time()
        total_time = end_time - start_time

        # Collect all completed mini-batches
        completed_mini_batches = []
        while not self.completed_queue.empty():
            completed_mini_batches.append(self.completed_queue.get())

        # Sort by sequence number
        completed_mini_batches.sort(key=lambda x: x.sequence_number)

        # Merge the final results
        if completed_mini_batches:
            final_results = [mb.final_result for mb in completed_mini_batches if mb.final_result is not None]
            combined_result = torch.cat(final_results, dim=0) if final_results else None
        else:
            combined_result = None
            
        return {
            'success': True,
            'method': 'minibatch_pipeline',
            'total_time': total_time,
            'total_samples': input_tensor.shape[0],
            'mini_batch_size': self.mini_batch_size,
            'total_mini_batches': total_mini_batches,
            'completed_mini_batches': len(completed_mini_batches),
            'throughput': input_tensor.shape[0] / total_time,
            'final_result': combined_result,
            'drone_a_processed': self.drone_a.processed_mini_batches,
            'drone_b_processed': self.drone_b.processed_mini_batches,
            'pipeline_efficiency': len(completed_mini_batches) / total_mini_batches if total_mini_batches > 0 else 0
        }
        
    def execute_sequential_baseline(self, input_tensor: torch.Tensor, cut_layer: ResNetLayer) -> Dict:
        """Execute the serial baseline (single-drone processing)."""
        if not self.drone_a:
            return {'success': False, 'error': 'DroneA not registered'}

        # Get the model info
        partition = self.partitioner.partition_at_layer(cut_layer)
        total_flops_per_sample = partition.total_flops

        start_time = time.time()

        # Simulate serial processing of all samples
        batch_size = input_tensor.shape[0]
        total_processing_time = (total_flops_per_sample * batch_size) / self.drone_a.capacity

        # Theoretical computation: remove the real sleep
        # actual_sleep = min(total_processing_time, 0.5)  # removed
        # time.sleep(actual_sleep)  # removed real delay

        # Generate the result
        final_result = torch.randn(batch_size, 1000)
        
        end_time = time.time()
        total_time = end_time - start_time
        
        return {
            'success': True,
            'method': 'sequential_single_drone',
            'total_time': total_time,
            'theoretical_time': total_processing_time,
            'total_samples': batch_size,
            'throughput': batch_size / total_time,
            'final_result': final_result
        }
        
    def analyze_pipeline_timing(self, completed_mini_batches: List[MiniBatch]) -> Dict:
        """Analyze the pipeline timing."""
        if not completed_mini_batches:
            return {}

        # Sort by sequence number
        sorted_batches = sorted(completed_mini_batches, key=lambda x: x.sequence_number)
        
        timing_analysis = {
            'mini_batch_timings': [],
            'total_pipeline_stages': [],
            'overlap_analysis': {}
        }
        
        for mb in sorted_batches:
            part_a_time = mb.part_a_completion_time - mb.start_time
            comm_time = mb.communication_end_time - mb.communication_start_time
            part_b_time = mb.part_b_completion_time - mb.communication_end_time
            total_time = mb.part_b_completion_time - mb.start_time
            
            timing_analysis['mini_batch_timings'].append({
                'sequence': mb.sequence_number,
                'part_a_time': part_a_time,
                'communication_time': comm_time,
                'part_b_time': part_b_time,
                'total_time': total_time
            })
            
        return timing_analysis


if __name__ == "__main__":
    # Test the mini-batch pipeline engine
    print("Testing Minibatch Pipeline Engine...")
    print("=" * 60)

    # Create the engine
    engine = MiniBatchPipelineEngine(mini_batch_size=4)

    # Register drones
    engine.register_drones(
        drone_a_capacity=1e10,  # 10G FLOPS/s (10 GFLOPS) - level of a modern UAV AI platform
        drone_b_capacity=1e10   # 10G FLOPS/s (10 GFLOPS)
    )

    # Choose a suitable partition point
    partitioner = ResNetPartitioner()
    analysis = partitioner.analyze_all_partitions()
    best_cut = max(analysis, key=lambda x: x['load_balance_score'])
    cut_layer = best_cut['cut_layer']
    
    print(f"Using cut layer: {cut_layer.name}")
    print(f"Load balance score: {best_cut['load_balance_score']:.3f}")
    print()
    
    # Test different batch sizes
    test_batch_sizes = [8, 16, 32]
    
    print("Performance Comparison:")
    print("-" * 80)
    print(f"{'Batch Size':<12} {'Sequential(s)':<15} {'Pipeline(s)':<15} {'Speedup':<10} {'Efficiency':<12}")
    print("-" * 80)
    
    for batch_size in test_batch_sizes:
        # Create test data
        test_input = torch.randn(batch_size, 3, 224, 224)

        # Test the serial baseline
        seq_result = engine.execute_sequential_baseline(test_input, cut_layer)

        # Test the pipeline
        pipeline_result = engine.execute_pipeline(test_input, cut_layer)
        
        if seq_result['success'] and pipeline_result['success']:
            seq_time = seq_result['total_time']
            pipe_time = pipeline_result['total_time']
            speedup = seq_time / pipe_time
            efficiency = pipeline_result['pipeline_efficiency']
            
            print(f"{batch_size:<12} {seq_time:<15.3f} {pipe_time:<15.3f} {speedup:<10.2f} {efficiency:<12.1%}")
        else:
            print(f"{batch_size:<12} ERROR")
            
        # Reset drone state
        if engine.drone_a:
            engine.drone_a.processed_mini_batches = 0
        if engine.drone_b:
            engine.drone_b.processed_mini_batches = 0
            
    print("\n" + "=" * 60)
    print("Minibatch Pipeline Engine Test Complete!")