"""
Configurable model partitioner (V3: original 4 networks + real layer data calibration)

Supports the paper's original 4 networks, with per-layer FLOPs/feature maps
calibrated and verified against torchvision:
- ResNet-8:     simplified 8-layer CNN, ~1.28 GFLOPs
- VGG-13:       13 layers (10 conv + 3 FC), 11.3 GFLOPs (calibrated, fixes original 25.64G error)
- VGG-16:       16 layers (13 conv + 3 FC), 15.5 GFLOPs
- GoogLeNet-22: 22 layers, ~1.64 GFLOPs

Feature map size (data_size_bytes) uses real tensor dimensions: C x H x W x 4 (FP32)
Pipeline layer-partition collaboration: the partition point transmits that layer's
intermediate feature map.
"""
import numpy as np
from typing import Tuple, Dict, List
from dataclasses import dataclass
from enum import Enum


class NetworkType(Enum):
    """Network type definitions (scheme C: 3 heavy + 1 light, matching diverse UAV deployment)"""
    YOLOV5M = "YOLOv5m"          # 12.4G, real-time detection (medium-large)
    VGG_16 = "VGG-16"            # 15.5G, image classification
    VGG_19 = "VGG-19"            # 19.6G, heavy classification
    GOOGLENET_22 = "GoogLeNet-22"  # 1.6G, lightweight baseline
    RESNEXT_101 = "ResNeXt-101"  # 16.5G, heavy grouped-conv residual net (architecture diversity)


@dataclass
class LayerSpec:
    """Layer specification definition"""
    layer_id: int
    flops: float          # floating-point operations for this layer (FLOPs, op count)
    output_channels: int  # number of output channels
    output_size: int      # output feature map size (H=W)
    data_size_bytes: int  # output data size (bytes, FP32)


class ConfigurableModelPartitioner:
    """Configurable model partitioner (pipeline layer-partition collaboration)"""

    def __init__(self, network_type: NetworkType = NetworkType.VGG_16, batch_size: int = 1):
        self.network_type = network_type
        self.batch_size = batch_size

        if network_type == NetworkType.YOLOV5M:
            self.num_layers = 12
            self._init_yolov5m_specs()
        elif network_type == NetworkType.VGG_16:
            self.num_layers = 16
            self._init_vgg16_specs()
        elif network_type == NetworkType.VGG_19:
            self.num_layers = 19
            self._init_vgg19_specs()
        elif network_type == NetworkType.GOOGLENET_22:
            self.num_layers = 22
            self._init_googlenet_specs()
        elif network_type == NetworkType.RESNEXT_101:
            self.num_layers = 18
            self._init_resnext101_specs()
        else:
            raise ValueError(f"Unknown network type: {network_type}")

    def _build(self, layer_flops, chans, sizes, is_fc=None):
        """Generic builder: generate the LayerSpec list from per-layer FLOPs/channels/feature-map size"""
        self.layer_specs = []
        for i in range(len(layer_flops)):
            if is_fc and is_fc[i]:
                data_bytes = self.batch_size * chans[i] * 4  # FC: 1D vector
            else:
                data_bytes = self.batch_size * chans[i] * sizes[i] * sizes[i] * 4
            self.layer_specs.append(LayerSpec(
                layer_id=i, flops=layer_flops[i],
                output_channels=chans[i], output_size=sizes[i],
                data_size_bytes=data_bytes
            ))

    def _init_yolov5m_specs(self):
        """YOLOv5m: ~12.4 GFLOPs, real-time detection network (medium-large). Backbone(6)+Neck(6)=12 compute units"""
        # YOLOv5m is deeper and wider than the s variant, roughly 1.7x the compute
        flops = [0.36, 0.62, 1.00, 1.86, 2.48, 1.24,   # backbone 6
                 1.00, 1.00, 0.86, 0.74, 0.62, 0.62]   # neck 6
        flops = [f * 1e9 for f in flops]  # sum ~= 12.4G
        chans = [96, 192, 384, 768, 768, 768, 384, 384, 768, 768, 1024, 1024]
        sizes = [112, 56, 28, 14, 14, 14, 28, 28, 14, 14, 7, 7]
        self._build(flops, chans, sizes)

    def _init_vgg19_specs(self):
        """VGG-19: 19.6 GFLOPs. 16 conv + 3 FC = 19 layers"""
        layer_flops = [
            0.17, 0.17,                      # block1 (224, 64ch)
            0.34, 0.34,                      # block2 (112, 128ch)
            0.68, 0.68, 0.68, 0.68,          # block3 (56, 256ch) 4conv
            1.35, 1.35, 1.35, 1.35,          # block4 (28, 512ch) 4conv
            0.34, 0.34, 0.34, 0.34,          # block5 (14, 512ch) 4conv
            3.70, 0.03, 0.004                # FC6, FC7, FC8
        ]
        s = sum(layer_flops)
        layer_flops = [f * 19.6 / s * 1e9 for f in layer_flops]
        sizes = [224, 112, 112, 56, 56, 56, 56, 28, 28, 28, 28, 14, 14, 14, 14, 7, 1, 1, 1]
        chans = [64, 64, 128, 128, 256, 256, 256, 256, 512, 512, 512, 512, 512, 512, 512, 512, 4096, 4096, 1000]
        is_fc = [False]*16 + [True]*3
        self._build(layer_flops, chans, sizes, is_fc)

    def _init_vgg16_specs(self):
        """VGG-16: 15.5 GFLOPs (real value). 13 conv + 3 FC = 16 layers"""
        layer_flops = [
            0.17, 0.17,                # block1
            0.34, 0.34,                # block2
            0.68, 0.68, 0.68,          # block3
            1.35, 1.35, 1.35,          # block4
            0.34, 0.34, 0.34,          # block5
            3.70, 0.03, 0.004          # FC
        ]
        s = sum(layer_flops)
        layer_flops = [f * 15.5 / s * 1e9 for f in layer_flops]
        sizes = [224, 112, 112, 56, 56, 56, 28, 28, 28, 14, 14, 14, 7, 1, 1, 1]
        chans = [64, 64, 128, 128, 256, 256, 256, 512, 512, 512, 512, 512, 512, 4096, 4096, 1000]
        is_fc = [False]*13 + [True]*3
        self._build(layer_flops, chans, sizes, is_fc)

    def _init_googlenet_specs(self):
        """GoogLeNet-22: ~1.64 GFLOPs, 22 layers (including inception)"""
        flops = [0.037, 0.022, 0.067, 0.082, 0.097, 0.105, 0.105, 0.105,
                 0.112, 0.128, 0.142, 0.150, 0.075, 0.075, 0.060, 0.060,
                 0.052, 0.052, 0.045, 0.037, 0.020, 0.010]
        flops = [f * 1e9 for f in flops]
        sizes = [112, 56, 56, 28, 28, 28, 28, 28, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 7, 7, 1, 1]
        chans = [64, 64, 192, 256, 480, 480, 480, 480, 512, 512, 512, 528, 832, 832, 832, 832, 832, 832, 1024, 1024, 1024, 1000]
        is_fc = [False]*20 + [True]*2
        self._build(flops, chans, sizes, is_fc)

    def _init_resnext101_specs(self):
        """ResNeXt-101 32x8d: ~16.5 GFLOPs (torchvision measured, 224x224).

        Structure: stem (conv1 7x7 + maxpool) + 4 residual stages ([3,4,23,3] bottleneck blocks) + fc.
        To keep the partition granularity comparable with the other networks, the 101 layers
        are compressed into 18 compute units:
          stem(1) + stage1(2) + stage2(2) + stage3(10, heaviest with 23 blocks) + stage4(2) + fc(1).
        Per-stage FLOPs fractions follow torchvision measurements (stem 6% / s1 13% / s2 17% / s3 51% / s4 13%).
        Intermediate activation = C x H x W x 4 (FP32); residual-net activations shrink with stage depth
        (communication-friendly, deeper partition points carry less data).
        """
        flops = [0.990, 1.073, 1.073, 1.403, 1.403, 0.842, 0.842, 0.842, 0.842, 0.842,
                 0.842, 0.842, 0.842, 0.842, 0.842, 1.073, 1.073, 0.004]
        flops = [f * 1e9 for f in flops]  # sum ~= 16.5G
        sizes = [112, 56, 56, 28, 28, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 7, 7, 1]
        chans = [64, 256, 256, 512, 512, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024,
                 1024, 1024, 2048, 2048, 1000]
        is_fc = [False]*17 + [True]
        self._build(flops, chans, sizes, is_fc)

    def get_layer_cut_flops(self, layer_cut: int) -> Tuple[float, float]:
        """Get the compute allocation at the given partition point (part_a, part_b)"""
        if layer_cut <= 0:
            return 0.0, sum(s.flops for s in self.layer_specs)
        if layer_cut >= self.num_layers:
            return sum(s.flops for s in self.layer_specs), 0.0
        part_a = sum(s.flops for s in self.layer_specs[:layer_cut])
        part_b = sum(s.flops for s in self.layer_specs[layer_cut:])
        return part_a, part_b

    def get_model_info(self) -> Dict:
        total_flops = sum(s.flops for s in self.layer_specs)
        return {
            'network_type': self.network_type.value,
            'num_layers': self.num_layers,
            'total_flops': total_flops,
            'total_flops_gflops': total_flops / 1e9,
            'layer_specs': self.layer_specs
        }

    def get_cut_ratio(self, layer_cut: int) -> float:
        a, b = self.get_layer_cut_flops(layer_cut)
        return a / (a + b) if (a + b) > 0 else 0.0

    def print_model_info(self):
        info = self.get_model_info()
        print(f"\n  Network: {info['network_type']}")
        print(f"  Layers: {info['num_layers']}")
        print(f"  Total FLOPs: {info['total_flops_gflops']:.2f} GFLOPs")


def create_partitioner(network_type_str: str, batch_size: int = 1) -> ConfigurableModelPartitioner:
    """Factory function: create a partitioner of the given type. Supported: resnet-8, vgg-13, vgg-16, googlenet-22"""
    network_map = {
        'yolov5m': NetworkType.YOLOV5M,
        'yolov5s': NetworkType.YOLOV5M,
        'yolo': NetworkType.YOLOV5M,
        'vgg-16': NetworkType.VGG_16,
        'vgg16': NetworkType.VGG_16,
        'vgg-19': NetworkType.VGG_19,
        'vgg19': NetworkType.VGG_19,
        'googlenet': NetworkType.GOOGLENET_22,
        'googlenet-22': NetworkType.GOOGLENET_22,
        'resnext-101': NetworkType.RESNEXT_101,
        'resnext101': NetworkType.RESNEXT_101,
        'resnext': NetworkType.RESNEXT_101,
        # Backward compatibility: map legacy network names to scheme C networks
        'resnet-8': NetworkType.GOOGLENET_22,
        'resnet8': NetworkType.GOOGLENET_22,
        'alexnet': NetworkType.GOOGLENET_22,
        'alexnet-8': NetworkType.GOOGLENET_22,
        'vgg-13': NetworkType.YOLOV5M,
        'vgg13': NetworkType.YOLOV5M,
    }
    key = network_type_str.lower()
    if key not in network_map:
        raise ValueError(f"Unknown network type: {network_type_str}. Supported: {list(network_map.keys())}")
    return ConfigurableModelPartitioner(network_map[key], batch_size)
