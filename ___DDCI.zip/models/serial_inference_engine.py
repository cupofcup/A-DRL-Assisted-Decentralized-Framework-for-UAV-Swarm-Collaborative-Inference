"""
Serial inference engine implementation.

This is the traditional serial model-partitioning approach:
1. DroneA processes Part A of the entire batch
2. After A fully completes, it transfers all intermediate results to DroneB
3. DroneB processes Part B of the entire batch
4. No overlapped execution; DroneB must wait for DroneA to finish

Used to compare against the performance advantage of the mini-batch pipeline.
"""

import torch
import time
import numpy as np
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass

from .resnet_partitioner import ResNetPartitioner, ResNetLayer

@dataclass
class SerialExecutionResult:
    """Serial execution result."""
    success: bool
    total_time: float
    part_a_time: float
    communication_time: float
    part_b_time: float
    total_samples: int
    throughput: float
    final_result: Optional[torch.Tensor] = None
    method: str = "serial_pipeline"

class SerialInferenceEngine:
    """
    Serial inference engine.

    Implements the traditional serial model partitioning:
    - DroneA processes Part A of the full batch
    - After completion it transfers to DroneB
    - DroneB processes Part B of the full batch
    - No overlapped execution; idle waiting time exists
    """

    def __init__(self):
        self.partitioner = ResNetPartitioner()

        # Drone capacities
        self.drone_a_capacity: Optional[float] = None
        self.drone_b_capacity: Optional[float] = None

        # Performance stats
        self.total_executions = 0
        self.total_processing_time = 0.0

    def register_drones(self, drone_a_capacity: float, drone_b_capacity: float):
        """Register two collaborating drones."""
        self.drone_a_capacity = drone_a_capacity
        self.drone_b_capacity = drone_b_capacity
        
        print(f"Serial Engine - DroneA: {drone_a_capacity:.0e} FLOPS/s")
        print(f"Serial Engine - DroneB: {drone_b_capacity:.0e} FLOPS/s")
        
    def calculate_communication_time(self, data_size: int, bandwidth_mbps: float = 100.0) -> float:
        """Compute the communication time."""
        data_mb = data_size / (1024 * 1024)
        return data_mb / bandwidth_mbps

    def execute_serial_pipeline(self, input_tensor: torch.Tensor,
                               cut_layer: ResNetLayer) -> SerialExecutionResult:
        """Execute serial pipeline inference."""
        
        if not self.drone_a_capacity or not self.drone_b_capacity:
            return SerialExecutionResult(
                success=False, total_time=0, part_a_time=0, 
                communication_time=0, part_b_time=0, 
                total_samples=0, throughput=0
            )
            
        batch_size = input_tensor.shape[0]
        partition = self.partitioner.partition_at_layer(cut_layer)
        
        start_time = time.time()
        
        # Stage 1: DroneA processes Part A of the entire batch
        part_a_start = start_time

        part_a_flops_total = partition.part_a_flops * batch_size
        part_a_processing_time = part_a_flops_total / self.drone_a_capacity

        # Theoretical computation: remove the real sleep
        # actual_sleep_a = min(part_a_processing_time, 0.2)  # removed
        # time.sleep(actual_sleep_a)  # removed real delay

        # Generate the intermediate result
        intermediate_shape = partition.intermediate_shape
        intermediate_result = torch.randn(batch_size, *intermediate_shape)

        part_a_end = part_a_start + part_a_processing_time
        actual_part_a_time = part_a_processing_time

        # Stage 2: Communication transfer (intermediate data of the entire batch)
        comm_start = part_a_end

        total_data_size = intermediate_result.numel() * 4  # float32 = 4 bytes
        theoretical_comm_time = self.calculate_communication_time(total_data_size)

        # Theoretical computation: remove the real sleep
        # actual_sleep_comm = min(theoretical_comm_time, 0.05)  # removed
        # time.sleep(actual_sleep_comm)  # removed real delay

        comm_end = comm_start + theoretical_comm_time
        actual_comm_time = theoretical_comm_time

        # Stage 3: DroneB processes Part B of the entire batch
        part_b_start = comm_end

        part_b_flops_total = partition.part_b_flops * batch_size
        part_b_processing_time = part_b_flops_total / self.drone_b_capacity

        # Theoretical computation: remove the real sleep
        # actual_sleep_b = min(part_b_processing_time, 0.2)  # removed
        # time.sleep(actual_sleep_b)  # removed real delay

        # Generate the final result
        final_result = torch.randn(batch_size, 1000)  # ResNet output

        part_b_end = part_b_start + part_b_processing_time
        actual_part_b_time = part_b_processing_time

        total_end_time = part_b_end
        total_actual_time = total_end_time - start_time

        # Update stats
        self.total_executions += 1
        self.total_processing_time += total_actual_time
        
        return SerialExecutionResult(
            success=True,
            total_time=total_actual_time,
            part_a_time=actual_part_a_time,
            communication_time=actual_comm_time,
            part_b_time=actual_part_b_time,
            total_samples=batch_size,
            throughput=batch_size / total_actual_time,
            final_result=final_result
        )
        
    def execute_single_drone_baseline(self, input_tensor: torch.Tensor, 
                                    cut_layer: ResNetLayer) -> SerialExecutionResult:
        """Execute the single-drone baseline (for comparison)."""
        
        if not self.drone_a_capacity:
            return SerialExecutionResult(
                success=False, total_time=0, part_a_time=0,
                communication_time=0, part_b_time=0,
                total_samples=0, throughput=0
            )
            
        batch_size = input_tensor.shape[0]
        partition = self.partitioner.partition_at_layer(cut_layer)
        
        # Process using combined capacity
        combined_capacity = self.drone_a_capacity + self.drone_b_capacity
        total_flops = partition.total_flops * batch_size
        processing_time = total_flops / combined_capacity

        start_time = time.time()

        # Theoretical computation: remove the real sleep
        # actual_sleep = min(processing_time, 0.3)  # removed
        # time.sleep(actual_sleep)  # removed real delay

        # Generate the result
        final_result = torch.randn(batch_size, 1000)

        # Use the theoretical processing time
        end_time = start_time + processing_time
        total_time = processing_time

        return SerialExecutionResult(
            success=True,
            total_time=total_time,
            part_a_time=total_time,  # count everything as processing time
            communication_time=0.0,
            part_b_time=0.0,
            total_samples=batch_size,
            throughput=batch_size / total_time,
            final_result=final_result,
            method="single_drone"
        )
        
    def analyze_idle_time(self, input_tensor: torch.Tensor, 
                         cut_layer: ResNetLayer) -> Dict:
        """Analyze the idle time in serial execution."""

        if not self.drone_a_capacity or not self.drone_b_capacity:
            return {}

        batch_size = input_tensor.shape[0]
        partition = self.partitioner.partition_at_layer(cut_layer)

        # Compute the theoretical times
        part_a_time = (partition.part_a_flops * batch_size) / self.drone_a_capacity
        part_b_time = (partition.part_b_flops * batch_size) / self.drone_b_capacity
        comm_time = self.calculate_communication_time(
            batch_size * np.prod(partition.intermediate_shape) * 4
        )

        total_time = part_a_time + comm_time + part_b_time

        # Analyze the utilization of each drone
        drone_a_utilization = part_a_time / total_time
        drone_b_utilization = part_b_time / total_time

        # DroneB idle time = Part A time + communication time
        drone_b_idle_time = part_a_time + comm_time
        drone_b_idle_ratio = drone_b_idle_time / total_time
        
        return {
            'total_time': total_time,
            'part_a_time': part_a_time,
            'part_b_time': part_b_time,
            'communication_time': comm_time,
            'drone_a_utilization': drone_a_utilization,
            'drone_b_utilization': drone_b_utilization,
            'drone_b_idle_time': drone_b_idle_time,
            'drone_b_idle_ratio': drone_b_idle_ratio,
            'overall_efficiency': (drone_a_utilization + drone_b_utilization) / 2
        }
        
    def get_performance_stats(self) -> Dict:
        """Get performance statistics."""
        if self.total_executions == 0:
            return {}
            
        return {
            'total_executions': self.total_executions,
            'total_processing_time': self.total_processing_time,
            'average_execution_time': self.total_processing_time / self.total_executions,
            'registered_drones': {
                'drone_a_capacity': self.drone_a_capacity,
                'drone_b_capacity': self.drone_b_capacity
            }
        }


if __name__ == "__main__":
    # Test the serial inference engine
    print("Testing Serial Inference Engine...")
    print("=" * 60)

    # Create the engine
    engine = SerialInferenceEngine()
    engine.register_drones(1e10, 1e10)  # 10G FLOPS/s (10 GFLOPS) each

    # Get the best partition point
    partitioner = ResNetPartitioner()
    analysis = partitioner.analyze_all_partitions()
    best_cut = max(analysis, key=lambda x: x['load_balance_score'])['cut_layer']
    
    print(f"Using cut layer: {best_cut.name}")
    print()
    
    # Test different batch sizes
    batch_sizes = [8, 16, 32, 64]
    
    print("Serial Pipeline Performance:")
    print("-" * 80)
    print(f"{'Batch':<8} {'Total(s)':<10} {'PartA(s)':<10} {'Comm(s)':<10} {'PartB(s)':<10} {'Throughput':<12}")
    print("-" * 80)
    
    for batch_size in batch_sizes:
        test_input = torch.randn(batch_size, 3, 224, 224)
        
        result = engine.execute_serial_pipeline(test_input, best_cut)
        
        if result.success:
            print(f"{batch_size:<8} {result.total_time:<10.3f} {result.part_a_time:<10.3f} "
                  f"{result.communication_time:<10.3f} {result.part_b_time:<10.3f} {result.throughput:<12.2f}")
        else:
            print(f"{batch_size:<8} ERROR")
    
    print()
    
    # Analyze the idle time
    test_batch = 32
    test_input = torch.randn(test_batch, 3, 224, 224)
    idle_analysis = engine.analyze_idle_time(test_input, best_cut)
    
    if idle_analysis:
        print(f"Idle Time Analysis (batch size = {test_batch}):")
        print(f"  DroneA utilization: {idle_analysis['drone_a_utilization']:.1%}")
        print(f"  DroneB utilization: {idle_analysis['drone_b_utilization']:.1%}")
        print(f"  DroneB idle ratio: {idle_analysis['drone_b_idle_ratio']:.1%}")
        print(f"  Overall efficiency: {idle_analysis['overall_efficiency']:.1%}")
    
    print("\n" + "=" * 60)
    print("Serial inference engine demonstrates the traditional approach")
    print("with sequential execution and idle waiting time.")