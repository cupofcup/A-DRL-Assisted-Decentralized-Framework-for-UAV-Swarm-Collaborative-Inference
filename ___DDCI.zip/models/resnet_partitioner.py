"""
ResNet18 layer-wise partitioning implementation.
Compared with AlexNet, ResNet has a more even per-layer compute distribution,
making it better suited to pipeline collaboration.

ResNet18 structure:
- Initial Conv + BN + ReLU + MaxPool
- Layer1: 2 BasicBlocks (64 channels)
- Layer2: 2 BasicBlocks (128 channels)
- Layer3: 2 BasicBlocks (256 channels)
- Layer4: 2 BasicBlocks (512 channels)
- Global AvgPool + FC

About 18 layers total, with a relatively even compute distribution.
"""

import torch
import torch.nn as nn
from typing import Tuple, List, Optional, Callable
from dataclasses import dataclass
from enum import Enum
import numpy as np

class ResNetLayer(Enum):
    """Layer definitions for ResNet18."""
    INITIAL_CONV = 1    # Initial conv + bn + relu + maxpool
    LAYER1_BLOCK1 = 2   # Layer1 block 1
    LAYER1_BLOCK2 = 3   # Layer1 block 2
    LAYER2_BLOCK1 = 4   # Layer2 block 1
    LAYER2_BLOCK2 = 5   # Layer2 block 2
    LAYER3_BLOCK1 = 6   # Layer3 block 1
    LAYER3_BLOCK2 = 7   # Layer3 block 2
    LAYER4_BLOCK1 = 8   # Layer4 block 1
    LAYER4_BLOCK2 = 9   # Layer4 block 2
    FINAL_LAYERS = 10   # AvgPool + FC


@dataclass
class ResNetLayerSpec:
    """ResNet layer specification definition."""
    layer_name: str
    input_shape: Tuple[int, ...]  # (C, H, W)
    output_shape: Tuple[int, ...]  # (C, H, W)
    flops: int                     # FLOPS count for this layer
    params: int                    # number of parameters
    description: str


@dataclass 
class ResNetPartitionResult:
    """ResNet partition result."""
    cut_layer: ResNetLayer

    # The two parts after partitioning
    part_a_layers: List[ResNetLayer]
    part_b_layers: List[ResNetLayer]

    # Compute analysis
    part_a_flops: int
    part_b_flops: int
    total_flops: int
    flops_ratio_a_to_b: float

    # Intermediate data transfer
    intermediate_shape: Tuple[int, ...]  # (C, H, W)
    intermediate_data_size: int          # bytes

    # Load-balance analysis
    load_balance_score: float            # [0,1], 1 is perfectly balanced
    recommended: bool                    # whether this partition point is recommended


class ResNetPartitioner:
    """
    ResNet18 layer-wise partitioner.

    Advantages of ResNet over AlexNet:
    1. More even compute across layers
    2. Residual structure is easy to partition
    3. Several balanced partition points to choose from
    """
    
    def __init__(self, batch_size: int = 1, input_size: int = 224):
        self.batch_size = batch_size
        self.input_size = input_size
        
        # Define the spec of each ResNet18 layer
        self._define_layer_specs()

    def _define_layer_specs(self):
        """Define the detailed specs of each ResNet18 layer."""

        # Based on ImageNet input: (3, 224, 224)
        self.layer_specs = {
            ResNetLayer.INITIAL_CONV: ResNetLayerSpec(
                layer_name="Initial Conv+BN+ReLU+MaxPool",
                input_shape=(3, 224, 224),
                output_shape=(64, 56, 56),  # 224->112->56 (conv stride=2, pool stride=2)
                flops=self._calculate_conv_flops(3, 64, 7, 224, 224, 2) + \
                      self._calculate_pool_flops(64, 112, 112, 3, 2),  # conv + pool
                params=3 * 64 * 7 * 7 + 64,  # conv weights + bn params
                description="Initial convolution and downsampling"
            ),
            
            ResNetLayer.LAYER1_BLOCK1: ResNetLayerSpec(
                layer_name="Layer1 Block1",
                input_shape=(64, 56, 56),
                output_shape=(64, 56, 56),
                flops=self._calculate_resnet_block_flops(64, 64, 56, 56, stride=1),
                params=self._calculate_resnet_block_params(64, 64),
                description="First residual block in layer1"
            ),
            
            ResNetLayer.LAYER1_BLOCK2: ResNetLayerSpec(
                layer_name="Layer1 Block2", 
                input_shape=(64, 56, 56),
                output_shape=(64, 56, 56),
                flops=self._calculate_resnet_block_flops(64, 64, 56, 56, stride=1),
                params=self._calculate_resnet_block_params(64, 64),
                description="Second residual block in layer1"
            ),
            
            ResNetLayer.LAYER2_BLOCK1: ResNetLayerSpec(
                layer_name="Layer2 Block1",
                input_shape=(64, 56, 56),
                output_shape=(128, 28, 28),  # stride=2 downsampling
                flops=self._calculate_resnet_block_flops(64, 128, 56, 28, stride=2, downsample=True),
                params=self._calculate_resnet_block_params(64, 128, downsample=True),
                description="First block in layer2 with downsampling"
            ),
            
            ResNetLayer.LAYER2_BLOCK2: ResNetLayerSpec(
                layer_name="Layer2 Block2",
                input_shape=(128, 28, 28),
                output_shape=(128, 28, 28),
                flops=self._calculate_resnet_block_flops(128, 128, 28, 28, stride=1),
                params=self._calculate_resnet_block_params(128, 128),
                description="Second residual block in layer2"
            ),
            
            ResNetLayer.LAYER3_BLOCK1: ResNetLayerSpec(
                layer_name="Layer3 Block1",
                input_shape=(128, 28, 28),
                output_shape=(256, 14, 14),  # stride=2 downsampling
                flops=self._calculate_resnet_block_flops(128, 256, 28, 14, stride=2, downsample=True),
                params=self._calculate_resnet_block_params(128, 256, downsample=True), 
                description="First block in layer3 with downsampling"
            ),
            
            ResNetLayer.LAYER3_BLOCK2: ResNetLayerSpec(
                layer_name="Layer3 Block2",
                input_shape=(256, 14, 14),
                output_shape=(256, 14, 14),
                flops=self._calculate_resnet_block_flops(256, 256, 14, 14, stride=1),
                params=self._calculate_resnet_block_params(256, 256),
                description="Second residual block in layer3"
            ),
            
            ResNetLayer.LAYER4_BLOCK1: ResNetLayerSpec(
                layer_name="Layer4 Block1", 
                input_shape=(256, 14, 14),
                output_shape=(512, 7, 7),    # stride=2 downsampling
                flops=self._calculate_resnet_block_flops(256, 512, 14, 7, stride=2, downsample=True),
                params=self._calculate_resnet_block_params(256, 512, downsample=True),
                description="First block in layer4 with downsampling"
            ),
            
            ResNetLayer.LAYER4_BLOCK2: ResNetLayerSpec(
                layer_name="Layer4 Block2",
                input_shape=(512, 7, 7),
                output_shape=(512, 7, 7),
                flops=self._calculate_resnet_block_flops(512, 512, 7, 7, stride=1),
                params=self._calculate_resnet_block_params(512, 512),
                description="Second residual block in layer4"
            ),
            
            ResNetLayer.FINAL_LAYERS: ResNetLayerSpec(
                layer_name="AvgPool+FC",
                input_shape=(512, 7, 7),
                output_shape=(1000,),  # ImageNet classes
                flops=self._calculate_pool_flops(512, 7, 7, 7, 1) + 512 * 1000,  # global avgpool + fc
                params=512 * 1000 + 1000,  # fc weights + bias
                description="Global average pooling and final classification"
            )
        }
        
    def _calculate_conv_flops(self, in_channels: int, out_channels: int, 
                            kernel_size: int, input_h: int, input_w: int, 
                            stride: int = 1, padding: int = None) -> int:
        """Compute the FLOPS of a convolutional layer."""
        if padding is None:
            padding = kernel_size // 2
            
        output_h = (input_h + 2 * padding - kernel_size) // stride + 1
        output_w = (input_w + 2 * padding - kernel_size) // stride + 1
        
        # FLOPS = batch_size * output_h * output_w * out_channels * in_channels * kernel_size^2
        flops = (self.batch_size * output_h * output_w * out_channels * 
                in_channels * kernel_size * kernel_size)
        return flops
    
    def _calculate_pool_flops(self, channels: int, input_h: int, input_w: int,
                            kernel_size: int, stride: int) -> int:
        """Compute the FLOPS of a pooling layer (relatively small)."""
        output_h = (input_h - kernel_size) // stride + 1
        output_w = (input_w - kernel_size) // stride + 1

        # Pooling operations have relatively little compute
        flops = self.batch_size * channels * output_h * output_w * kernel_size * kernel_size
        return flops
    
    def _calculate_resnet_block_flops(self, in_channels: int, out_channels: int,
                                    input_h: int, output_h: int, stride: int = 1,
                                    downsample: bool = False) -> int:
        """Compute the FLOPS of a ResNet basic block."""
        # BasicBlock contains two 3x3 convolutions
        input_w = input_h  # assume square input
        output_w = output_h

        # First 3x3 convolution
        conv1_flops = self._calculate_conv_flops(in_channels, out_channels, 3,
                                               input_h, input_w, stride)

        # Second 3x3 convolution
        conv2_flops = self._calculate_conv_flops(out_channels, out_channels, 3,
                                               output_h, output_w, 1)

        # Downsample shortcut if needed
        downsample_flops = 0
        if downsample:
            downsample_flops = self._calculate_conv_flops(in_channels, out_channels, 1,
                                                        input_h, input_w, stride)

        # BN and ReLU have relatively little compute, handled approximately
        bn_relu_flops = self.batch_size * out_channels * output_h * output_w * 4  # approximation
        
        return conv1_flops + conv2_flops + downsample_flops + bn_relu_flops
    
    def _calculate_resnet_block_params(self, in_channels: int, out_channels: int,
                                     downsample: bool = False) -> int:
        """Compute the number of parameters of a ResNet basic block."""
        # Parameters of the two 3x3 convolutions
        conv_params = in_channels * out_channels * 3 * 3 + out_channels * out_channels * 3 * 3

        # BN parameters (gamma, beta for each conv)
        bn_params = out_channels * 4  # 2 BN layers

        # Downsample layer parameters
        downsample_params = 0
        if downsample:
            downsample_params = in_channels * out_channels + out_channels * 2  # 1x1 conv + BN
            
        return conv_params + bn_params + downsample_params

    def partition_at_layer(self, cut_layer: ResNetLayer) -> ResNetPartitionResult:
        """Partition the model at the given layer."""
        if not isinstance(cut_layer, ResNetLayer):
            raise ValueError(f"Cut layer must be ResNetLayer, got {type(cut_layer)}")

        if cut_layer == ResNetLayer.FINAL_LAYERS:
            raise ValueError("Cannot cut at final layers - no part B would remain")

        # Determine the partition point
        all_layers = list(ResNetLayer)
        cut_index = all_layers.index(cut_layer)

        part_a_layers = all_layers[:cut_index + 1]
        part_b_layers = all_layers[cut_index + 1:]

        # Compute the FLOPS of each part
        part_a_flops = sum(self.layer_specs[layer].flops for layer in part_a_layers)
        part_b_flops = sum(self.layer_specs[layer].flops for layer in part_b_layers)
        total_flops = part_a_flops + part_b_flops

        # Load ratio
        flops_ratio = part_a_flops / part_b_flops if part_b_flops > 0 else float('inf')

        # Intermediate data spec (output of Part A)
        intermediate_shape = self.layer_specs[cut_layer].output_shape

        # Compute the intermediate data size (bytes)
        if len(intermediate_shape) == 3:  # (C, H, W)
            data_elements = self.batch_size * intermediate_shape[0] * intermediate_shape[1] * intermediate_shape[2]
        else:  # (features,)
            data_elements = self.batch_size * intermediate_shape[0]

        intermediate_data_size = data_elements * 4  # float32 = 4 bytes

        # Load-balance score (1 is perfectly balanced)
        load_balance_score = min(part_a_flops, part_b_flops) / max(part_a_flops, part_b_flops)

        # Recommendation assessment (balance > 0.6 and moderate communication volume)
        reasonable_communication = intermediate_data_size < 50 * 1024 * 1024  # <50MB
        recommended = load_balance_score > 0.6 and reasonable_communication
        
        return ResNetPartitionResult(
            cut_layer=cut_layer,
            part_a_layers=part_a_layers,
            part_b_layers=part_b_layers,
            part_a_flops=part_a_flops,
            part_b_flops=part_b_flops,
            total_flops=total_flops,
            flops_ratio_a_to_b=flops_ratio,
            intermediate_shape=intermediate_shape,
            intermediate_data_size=intermediate_data_size,
            load_balance_score=load_balance_score,
            recommended=recommended
        )
    
    def find_optimal_partition(self, drone_a_capacity: float, drone_b_capacity: float,
                             communication_time_func: Callable[[int], float]) -> Tuple[ResNetLayer, ResNetPartitionResult, dict]:
        """Find the optimal partition point."""

        best_time = float('inf')
        best_cut = None
        best_partition = None
        results = {}

        # Test all possible partition points
        testable_cuts = [layer for layer in ResNetLayer if layer != ResNetLayer.FINAL_LAYERS]

        for cut_layer in testable_cuts:
            partition = self.partition_at_layer(cut_layer)

            # Compute the execution time
            part_a_time = partition.part_a_flops / drone_a_capacity
            part_b_time = partition.part_b_flops / drone_b_capacity
            comm_time = communication_time_func(partition.intermediate_data_size)

            # Total pipeline time (accounting for overlap)
            stage_time = max(part_a_time, part_b_time + comm_time)
            total_time = part_a_time + comm_time + part_b_time  # single-batch time

            # Independent execution time (baseline)
            independent_time = partition.total_flops / (drone_a_capacity + drone_b_capacity)
            speedup = independent_time / total_time

            # Efficiency assessment
            efficiency = min(drone_a_capacity, drone_b_capacity) / max(drone_a_capacity, drone_b_capacity)
            efficiency *= partition.load_balance_score
            
            results[cut_layer] = {
                'total_time': total_time,
                'part_a_time': part_a_time,
                'part_b_time': part_b_time,
                'comm_time': comm_time,
                'speedup': speedup,
                'efficiency': efficiency
            }
            
            if total_time < best_time and partition.recommended:
                best_time = total_time
                best_cut = cut_layer
                best_partition = partition
        
        if best_cut is None:
            # If none is recommended, choose the most balanced one
            best_cut = max(testable_cuts, key=lambda x: self.partition_at_layer(x).load_balance_score)
            best_partition = self.partition_at_layer(best_cut)
            
        return best_cut, best_partition, results[best_cut]
    
    def get_model_summary(self) -> dict:
        """Get the overall statistics of the ResNet18 model."""
        total_flops = sum(spec.flops for spec in self.layer_specs.values())
        total_params = sum(spec.params for spec in self.layer_specs.values())
        
        return {
            'model_name': 'ResNet18',
            'total_layers': len(self.layer_specs),
            'total_flops': total_flops,
            'total_params': total_params,
            'input_shape': (self.batch_size, 3, self.input_size, self.input_size),
            'output_shape': (self.batch_size, 1000),
            'batch_size': self.batch_size
        }
    
    def analyze_all_partitions(self) -> List[dict]:
        """Analyze all possible partition points."""
        results = []
        
        testable_cuts = [layer for layer in ResNetLayer if layer != ResNetLayer.FINAL_LAYERS]
        
        for cut_layer in testable_cuts:
            partition = self.partition_at_layer(cut_layer)
            
            results.append({
                'cut_layer': cut_layer,
                'layer_name': partition.cut_layer.name,
                'part_a_flops': partition.part_a_flops,
                'part_b_flops': partition.part_b_flops,
                'flops_ratio': partition.flops_ratio_a_to_b,
                'load_balance_score': partition.load_balance_score,
                'intermediate_data_mb': partition.intermediate_data_size / (1024 * 1024),
                'recommended': partition.recommended,
                'description': self.layer_specs[cut_layer].description
            })
        
        return results


if __name__ == "__main__":
    # Test the ResNet partitioner
    print("Testing ResNet18 Partitioner...")
    print("=" * 60)
    
    partitioner = ResNetPartitioner(batch_size=1)
    
    # Overall model info
    summary = partitioner.get_model_summary()
    print(f"Model Summary:")
    print(f"  Model: {summary['model_name']}")
    print(f"  Total FLOPS: {summary['total_flops']:,}")
    print(f"  Total Parameters: {summary['total_params']:,}")
    print(f"  Input Shape: {summary['input_shape']}")
    print()
    
    # Analyze all partition points
    print("All Partition Points Analysis:")
    print("-" * 110)
    print(f"{'Cut Layer':<18} {'PartA FLOPS':<15} {'PartB FLOPS':<15} {'Ratio':<8} {'Balance':<8} {'Data(MB)':<10} {'Recommended':<12}")
    print("-" * 110)
    
    analysis = partitioner.analyze_all_partitions()
    for result in analysis:
        recommended = "✓" if result['recommended'] else "✗"
        print(f"{result['layer_name']:<18} {result['part_a_flops']:<15,} {result['part_b_flops']:<15,} "
              f"{result['flops_ratio']:<8.2f} {result['load_balance_score']:<8.2f} {result['intermediate_data_mb']:<10.2f} "
              f"{recommended:<12}")
    
    print()
    
    # Find the optimal partition point
    def simple_comm_time(data_size):
        return data_size / (100 * 1024 * 1024)  # 100MB/s
    
    optimal_cut, optimal_partition, timing = partitioner.find_optimal_partition(
        1e10, 1e10, simple_comm_time  # 10G FLOPS/s (10 GFLOPS) each
    )
    
    print(f"Optimal Partition Analysis:")
    print(f"  Best Cut: {optimal_cut.name}")
    print(f"  Load Balance Score: {optimal_partition.load_balance_score:.3f}")
    print(f"  Expected Total Time: {timing['total_time']:.3f}s")
    print(f"  Expected Speedup: {timing['speedup']:.2f}x")
    print(f"  Efficiency: {timing['efficiency']:.2f}")
    
    print("\n" + "=" * 60)
    print("ResNet18 partitioner ready for pipeline testing!")