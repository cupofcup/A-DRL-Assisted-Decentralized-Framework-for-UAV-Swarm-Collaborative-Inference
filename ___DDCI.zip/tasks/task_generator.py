"""
Task generator implementing layered arrival models based on CLAUDE.md mathematical formulation.

Implements the following arrival processes:
- High Priority (p=3): Poisson(λ_3(t)) with environmental hazard factors
- Medium Priority (p=2): Compound Poisson(λ_2(t), B_2) with spatial correlation  
- Low Priority (p=1): Poisson(λ_1) with constant rate
- Background (p=0): Batch Arrival(T_batch, U_batch) with exponential intervals
"""

import numpy as np
import uuid
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass
from enum import IntEnum


class TaskPriority(IntEnum):
    """Task priority levels as defined in CLAUDE.md"""
    BACKGROUND = 0  # System maintenance, data synchronization
    LOW = 1        # Regular data analysis tasks  
    MEDIUM = 2     # Target identification, path planning (main DRL focus)
    HIGH = 3       # Emergency obstacle avoidance, threat detection


class TaskType(IntEnum):
    """Task types as defined in CLAUDE.md"""
    INFERENCE = 0
    TRAINING = 1
    DATA_PROCESSING = 2
    COMMUNICATION = 3


@dataclass
class Task:
    """
    Task representation (extended with AOI support):
    τ = (id, p, flops, D, loc, aoi_threshold)

    Where:
    - id: Global unique identifier
    - p ∈ {0,1,2,3}: Priority level
    - flops: Computational demand (FLOPS)
    - D: Deadline time
    - loc: Generation location coordinates
    - aoi_threshold: Maximum acceptable Age of Information (seconds)
    """
    id: str
    priority: TaskPriority
    flops: float
    deadline: float
    location: Tuple[float, float]
    task_type: TaskType
    arrival_time: float  # Task generation time, used to compute AOI
    data_size: int = 1024  # bytes
    aoi_threshold: float = 1.0  # AOI threshold (seconds); information becomes stale beyond this

    def calculate_aoi(self, current_time: float) -> float:
        """Compute current AOI"""
        return current_time - self.arrival_time

    def is_aoi_violated(self, current_time: float) -> bool:
        """Check whether AOI exceeds the threshold"""
        return self.calculate_aoi(current_time) > self.aoi_threshold


class TaskGenerator:
    """
    Task generator implementing the layered arrival models from CLAUDE.md Section 2.
    """
    
    def __init__(self,
                 lambda_3_base: float = 0.2,     # Base rate for high priority tasks (increased)
                 lambda_2_base: float = 1.5,     # Base rate for medium priority tasks (increased)
                 lambda_1: float = 2.0,          # Constant rate for low priority tasks (increased)
                 mu_batch: float = 0.3,          # Batch interval rate for background tasks
                 batch_size_range: Tuple[int, int] = (1, 5),  # Uniform batch size range [a, b]
                 max_flops_per_task: float = 1e10, # Maximum FLOPS per task (10 GFLOPS)
                 comm_radius: float = 100.0):     # Communication radius
        
        self.lambda_3_base = lambda_3_base
        self.lambda_2_base = lambda_2_base  
        self.lambda_1 = lambda_1
        self.mu_batch = mu_batch
        self.batch_size_range = batch_size_range
        self.max_flops_per_task = max_flops_per_task
        self.comm_radius = comm_radius
        
        # Environmental hazard factors for high priority tasks
        self.hazard_weights = [0.3, 0.4, 0.2, 0.1]  # ω_j weights
        
        # Spatial correlation coefficients for medium priority tasks
        self.spatial_coeffs = [0.2, 0.3, 0.5]  # β_k coefficients
        
        # Last batch time for background tasks
        self.last_batch_time = 0.0
        self.next_batch_time = 0.0
        
    def get_hazard_factors(self, t: float) -> List[float]:
        """
        Calculate environmental hazard factors h_j(t) for high priority task arrival.
        
        Returns list of hazard factors (weather, obstacle density, etc.)
        """
        # Simple sinusoidal hazard factors for simulation
        h1 = 0.5 + 0.3 * np.sin(0.1 * t)  # Weather factor
        h2 = 0.3 + 0.2 * np.cos(0.05 * t)  # Obstacle density
        h3 = np.random.exponential(0.1)     # Random events
        h4 = 0.1 * np.random.random()       # Other factors
        
        return [h1, h2, h3, h4]
    
    def get_spatial_density(self, location: Tuple[float, float], t: float) -> List[float]:
        """
        Calculate spatial task density ρ_k(loc, t) for medium priority tasks.
        
        Args:
            location: (x, y) coordinates
            t: Current time
            
        Returns:
            List of spatial density factors for different task types
        """
        x, y = location
        
        # Simple spatial correlation model
        rho1 = np.exp(-((x-50)**2 + (y-50)**2) / 1000)  # Hotspot at (50, 50)
        rho2 = 0.5 + 0.3 * np.sin(0.01 * t) * np.cos(x/100)  # Time-varying spatial pattern
        rho3 = np.random.exponential(0.2)  # Random spatial events
        
        return [rho1, rho2, rho3]
    
    def calculate_lambda_3(self, t: float) -> float:
        """
        Calculate arrival rate for high priority tasks (p=3):
        λ_3(t) = λ_3,base · (1 + Σ(ω_j · h_j(t)))
        """
        hazard_factors = self.get_hazard_factors(t)
        hazard_sum = sum(w * h for w, h in zip(self.hazard_weights, hazard_factors))
        return self.lambda_3_base * (1 + hazard_sum)
    
    def calculate_lambda_2(self, location: Tuple[float, float], t: float) -> float:
        """
        Calculate arrival rate for medium priority tasks (p=2):
        λ_2(t) = λ_2,base + Σ(β_k · ρ_k(loc, t))
        """
        spatial_densities = self.get_spatial_density(location, t)
        spatial_sum = sum(b * rho for b, rho in zip(self.spatial_coeffs, spatial_densities))
        return self.lambda_2_base + spatial_sum
    
    def generate_task_flops(self, priority: TaskPriority) -> float:
        """Generate FLOPS requirement based on task priority.

        Reduced task sizes to avoid task backlog and latency blow-up.
        Matched to a 10 GFLOPS drone capacity:
        - HIGH: 0.0005-0.05s processing time (emergency response)
        - MEDIUM: 0.05-1.0s processing time (main DRL optimization target)
        - LOW: 0.005-0.5s processing time (regular tasks)
        - BACKGROUND: 0.00005-0.005s processing time (background tasks)
        """
        if priority == TaskPriority.HIGH:
            # Emergency tasks: require fast response
            return np.random.uniform(5e6, 5e8)  # 5M-500M FLOPS
        elif priority == TaskPriority.MEDIUM:
            # Main inference tasks: core target of DRL collaborative optimization
            return np.random.uniform(5e8, self.max_flops_per_task)  # 500M-10G FLOPS
        elif priority == TaskPriority.LOW:
            # Regular tasks: moderate FLOPS
            return np.random.uniform(5e7, 5e9)  # 50M-5G FLOPS
        else:  # BACKGROUND
            # Background tasks: low FLOPS
            return np.random.uniform(5e5, 5e7)  # 500K-50M FLOPS
    
    def generate_deadline(self, priority: TaskPriority, arrival_time: float) -> float:
        """Generate task deadline based on priority."""
        if priority == TaskPriority.HIGH:
            # Critical tasks: very tight deadlines
            return arrival_time + np.random.uniform(1, 5)
        elif priority == TaskPriority.MEDIUM:
            # Medium tasks: moderate deadlines
            return arrival_time + np.random.uniform(5, 20)
        elif priority == TaskPriority.LOW:
            # Low tasks: relaxed deadlines
            return arrival_time + np.random.uniform(10, 50)
        else:  # BACKGROUND
            # Background: very relaxed deadlines
            return arrival_time + np.random.uniform(50, 200)

    def generate_aoi_threshold(self, priority: TaskPriority) -> float:
        """
        Generate AOI threshold based on priority.
        V2: tighter AOI thresholds to give the DRL more room to optimize
        """
        if priority == TaskPriority.HIGH:
            # Emergency tasks: very strict AOI requirement (0.2-0.5s)
            return np.random.uniform(0.2, 0.5)
        elif priority == TaskPriority.MEDIUM:
            # Medium tasks: moderate AOI requirement (0.5-1.2s)
            return np.random.uniform(0.5, 1.2)
        elif priority == TaskPriority.LOW:
            # Low priority: relatively tight AOI requirement (1.0-3.0s)
            return np.random.uniform(1.0, 3.0)
        else:  # BACKGROUND
            # Background tasks: relaxed AOI requirement
            return np.random.uniform(3.0, 10.0)
    
    def generate_high_priority_tasks(self, dt: float, t: float, location: Tuple[float, float]) -> List[Task]:
        """
        Generate high priority tasks using Poisson process:
        N_3(t) ~ Poisson(λ_3(t))
        """
        lambda_3 = self.calculate_lambda_3(t)
        num_tasks = np.random.poisson(lambda_3 * dt)
        
        tasks = []
        for _ in range(num_tasks):
            priority = TaskPriority.HIGH
            task = Task(
                id=str(uuid.uuid4()),
                priority=priority,
                flops=self.generate_task_flops(priority),
                deadline=self.generate_deadline(priority, t),
                location=location,
                task_type=TaskType(np.random.randint(0, 4)),
                arrival_time=t,
                data_size=np.random.randint(512, 2048),
                aoi_threshold=self.generate_aoi_threshold(priority)
            )
            tasks.append(task)
        
        return tasks
    
    def generate_medium_priority_tasks(self, dt: float, t: float, location: Tuple[float, float]) -> List[Task]:
        """
        Generate medium priority tasks using Compound Poisson process:
        N_2(t) ~ Compound Poisson(λ_2(t), B_2)
        """
        lambda_2 = self.calculate_lambda_2(location, t)
        
        # Compound Poisson: first generate number of batches, then batch sizes
        num_batches = np.random.poisson(lambda_2 * dt)
        
        tasks = []
        for _ in range(num_batches):
            # Batch size from geometric distribution (simple compound model)
            batch_size = np.random.geometric(0.7)  # B_2 distribution

            for _ in range(batch_size):
                priority = TaskPriority.MEDIUM
                task = Task(
                    id=str(uuid.uuid4()),
                    priority=priority,
                    flops=self.generate_task_flops(priority),
                    deadline=self.generate_deadline(priority, t),
                    location=location,
                    task_type=TaskType(np.random.randint(0, 4)),
                    arrival_time=t,
                    data_size=np.random.randint(1024, 4096),
                    aoi_threshold=self.generate_aoi_threshold(priority)
                )
                tasks.append(task)
        
        return tasks
    
    def generate_low_priority_tasks(self, dt: float, t: float, location: Tuple[float, float]) -> List[Task]:
        """
        Generate low priority tasks using simple Poisson process:
        N_1(t) ~ Poisson(λ_1)
        """
        num_tasks = np.random.poisson(self.lambda_1 * dt)
        
        tasks = []
        for _ in range(num_tasks):
            priority = TaskPriority.LOW
            task = Task(
                id=str(uuid.uuid4()),
                priority=priority,
                flops=self.generate_task_flops(priority),
                deadline=self.generate_deadline(priority, t),
                location=location,
                task_type=TaskType(np.random.randint(0, 4)),
                arrival_time=t,
                data_size=np.random.randint(512, 2048),
                aoi_threshold=self.generate_aoi_threshold(priority)
            )
            tasks.append(task)
        
        return tasks
    
    def generate_background_tasks(self, t: float, location: Tuple[float, float]) -> List[Task]:
        """
        Generate background tasks using Batch Arrival process:
        N_0(t) ~ Batch Arrival(T_batch, U_batch)
        
        Where:
        - T_batch ~ Exponential(μ_batch): batch interval time
        - U_batch ~ Uniform(a, b): number of tasks per batch
        """
        tasks = []
        
        # Initialize next batch time if not set
        if self.next_batch_time == 0:
            self.next_batch_time = np.random.exponential(1/self.mu_batch)
        
        # Check if it's time for a batch arrival
        if t >= self.next_batch_time:
            # Generate batch size from uniform distribution
            batch_size = np.random.randint(self.batch_size_range[0], self.batch_size_range[1] + 1)
            
            for _ in range(batch_size):
                priority = TaskPriority.BACKGROUND
                task = Task(
                    id=str(uuid.uuid4()),
                    priority=priority,
                    flops=self.generate_task_flops(priority),
                    deadline=self.generate_deadline(priority, t),
                    location=location,
                    task_type=TaskType(np.random.randint(0, 4)),
                    arrival_time=t,
                    data_size=np.random.randint(256, 1024),
                    aoi_threshold=self.generate_aoi_threshold(priority)
                )
                tasks.append(task)
            
            # Schedule next batch
            self.next_batch_time = t + np.random.exponential(1/self.mu_batch)
        
        return tasks
    
    def generate_tasks(self, dt: float, t: float, location: Tuple[float, float]) -> List[Task]:
        """
        Generate all types of tasks for a given time step and location.
        
        Args:
            dt: Time step size
            t: Current time
            location: (x, y) coordinates where tasks are generated
            
        Returns:
            List of generated tasks sorted by priority (highest first)
        """
        all_tasks = []
        
        # Generate tasks for each priority level
        all_tasks.extend(self.generate_high_priority_tasks(dt, t, location))
        all_tasks.extend(self.generate_medium_priority_tasks(dt, t, location))
        all_tasks.extend(self.generate_low_priority_tasks(dt, t, location))
        all_tasks.extend(self.generate_background_tasks(t, location))
        
        # Sort by priority (highest first) and then by arrival time
        all_tasks.sort(key=lambda task: (-task.priority, task.arrival_time))
        
        return all_tasks


if __name__ == "__main__":
    # Test the task generator
    generator = TaskGenerator()
    
    # Generate tasks for 10 time steps
    current_time = 0.0
    dt = 1.0
    location = (50.0, 50.0)
    
    for i in range(10):
        tasks = generator.generate_tasks(dt, current_time, location)
        print(f"Time {current_time:.1f}: Generated {len(tasks)} tasks")
        
        for task in tasks:
            print(f"  Task {task.id[:8]}: Priority={task.priority.name}, FLOPS={task.flops:.2e}, Deadline={task.deadline:.1f}")
        
        current_time += dt
        print()