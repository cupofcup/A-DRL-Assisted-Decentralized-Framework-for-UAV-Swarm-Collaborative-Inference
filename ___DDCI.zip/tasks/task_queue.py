"""
Hierarchical task queue management based on CLAUDE.md mathematical formulation.

Implements the queue dynamic equation:
Q_i(t+Δt) = Q_i(t) ∪ A_i(t,t+Δt) ∖ C_i(t,t+Δt) ∖ P_i(t,t+Δt)

Where:
- Q_i(t): Task queue state for drone i at time t
- A_i(t,t+Δt): New arriving tasks in time interval
- C_i(t,t+Δt): Completed tasks in time interval
- P_i(t,t+Δt): Preempted tasks in time interval
"""

import heapq
from typing import List, Dict, Optional, Tuple, Set
from collections import deque
from dataclasses import dataclass, field
import time

from .task_generator import Task, TaskPriority, TaskType


@dataclass
class TaskQueueEntry:
    """Task queue entry with timing information."""
    task: Task
    enqueue_time: float
    start_time: Optional[float] = None
    estimated_completion_time: Optional[float] = None
    
    def __lt__(self, other):
        """Comparison for priority queue ordering."""
        # Higher priority tasks come first, then by arrival time
        if self.task.priority != other.task.priority:
            return self.task.priority > other.task.priority
        return self.task.arrival_time < other.task.arrival_time


class HierarchicalTaskQueue:
    """
    Hierarchical task queue implementing the 4-level priority system from CLAUDE.md.
    
    Priority levels (highest to lowest):
    - Priority 3 (HIGH): Emergency tasks, preemptive execution
    - Priority 2 (MEDIUM): Main inference tasks (DRL focus)  
    - Priority 1 (LOW): Regular tasks
    - Priority 0 (BACKGROUND): System maintenance, idle execution
    """
    
    def __init__(self, drone_id: str, max_queue_size: int = 100, max_concurrent_tasks: int = 5, fifo_mode: bool = False, enable_preemption: bool = True):
        self.drone_id = drone_id
        self.max_queue_size = max_queue_size
        self.max_concurrent_tasks = max_concurrent_tasks
        self.fifo_mode = fifo_mode  # FIFO ablation: ignore priority if True
        self.enable_preemption = enable_preemption  # Preemption ablation: enable/disable preemption
        
        # Separate queues for each priority level: Q_i^(p)(t)
        self.priority_queues: Dict[TaskPriority, List[TaskQueueEntry]] = {
            TaskPriority.HIGH: [],
            TaskPriority.MEDIUM: [],
            TaskPriority.LOW: [], 
            TaskPriority.BACKGROUND: []
        }
        
        # Currently processing tasks
        self.processing_tasks: List[TaskQueueEntry] = []
        
        # Completed tasks history (for metrics)
        self.completed_tasks: List[TaskQueueEntry] = []
        
        # Preempted tasks (can be resumed later)
        self.preempted_tasks: List[TaskQueueEntry] = []
        
        # Statistics
        self.total_arrived = 0
        self.total_completed = 0
        self.total_preempted = 0
        self.total_dropped = 0
        
    def get_queue_state(self, t: float) -> Tuple[List[int], float, float]:
        """
        Get current queue state as defined in CLAUDE.md:
        q_i(t) = [|Q_i^(0)(t)|, |Q_i^(1)(t)|, |Q_i^(2)(t)|, |Q_i^(3)(t)|]
        
        Returns:
            queue_lengths: List of queue lengths for each priority level
            queue_load: Normalized total queue load
            busy_rate: Current busy rate
        """
        queue_lengths = [
            len(self.priority_queues[TaskPriority.BACKGROUND]),
            len(self.priority_queues[TaskPriority.LOW]),
            len(self.priority_queues[TaskPriority.MEDIUM]),
            len(self.priority_queues[TaskPriority.HIGH])
        ]
        
        total_queued = sum(queue_lengths)
        queue_load = min(1.0, total_queued / self.max_queue_size)
        
        processing_count = len(self.processing_tasks)
        busy_rate = processing_count / self.max_concurrent_tasks
        
        return queue_lengths, queue_load, busy_rate
    
    def calculate_total_flops_load(self) -> float:
        """Calculate total FLOPS load in queue and processing."""
        total_flops = 0.0
        
        # Add processing tasks FLOPS
        for entry in self.processing_tasks:
            total_flops += entry.task.flops
            
        # Add queued tasks FLOPS  
        for priority_queue in self.priority_queues.values():
            for entry in priority_queue:
                total_flops += entry.task.flops
        
        return total_flops
    
    def add_task(self, task: Task, current_time: float) -> bool:
        """
        Add new task to appropriate priority queue.
        Implements the A_i(t,t+Δt) component of queue dynamics.
        
        Returns:
            True if task was added successfully, False if queue is full
        """
        # Check if queue is full
        total_queued = sum(len(q) for q in self.priority_queues.values())
        if total_queued >= self.max_queue_size:
            # For high priority tasks, try to drop a lower priority task
            if task.priority == TaskPriority.HIGH and self._make_room_for_high_priority():
                pass  # Room made, continue with adding
            else:
                self.total_dropped += 1
                return False
        
        # Create queue entry
        entry = TaskQueueEntry(
            task=task,
            enqueue_time=current_time
        )
        
        # Add to appropriate priority queue
        heapq.heappush(self.priority_queues[task.priority], entry)
        self.total_arrived += 1
        
        # Try immediate processing if high priority
        if task.priority == TaskPriority.HIGH:
            self._try_immediate_processing(current_time)
        
        return True
    
    def _make_room_for_high_priority(self) -> bool:
        """Try to make room for high priority task by dropping background tasks."""
        if len(self.priority_queues[TaskPriority.BACKGROUND]) > 0:
            dropped_task = heapq.heappop(self.priority_queues[TaskPriority.BACKGROUND])
            self.total_dropped += 1
            return True
        return False
    
    def _try_immediate_processing(self, current_time: float):
        """Try immediate processing for high priority tasks (preemption)."""
        # Skip preemption if disabled (for ablation study)
        if not self.enable_preemption:
            return

        if len(self.processing_tasks) >= self.max_concurrent_tasks:
            # Find lowest priority processing task to preempt
            lowest_priority_idx = None
            lowest_priority = TaskPriority.HIGH

            for i, entry in enumerate(self.processing_tasks):
                if entry.task.priority < lowest_priority:
                    lowest_priority = entry.task.priority
                    lowest_priority_idx = i

            # Preempt if found a lower priority task
            if lowest_priority_idx is not None and lowest_priority < TaskPriority.HIGH:
                preempted_entry = self.processing_tasks.pop(lowest_priority_idx)
                self.preempted_tasks.append(preempted_entry)
                self.total_preempted += 1
    
    def get_next_task_for_processing(self, current_time: float) -> Optional[TaskQueueEntry]:
        """
        Get next highest priority task for processing.
        Implements preemptive priority scheduling as defined in CLAUDE.md.

        FIFO Ablation: If fifo_mode=True, ignores priority and selects by arrival time only.
        """
        if len(self.processing_tasks) >= self.max_concurrent_tasks:
            return None

        # FIFO Mode: Ignore priority, select earliest arrival time
        if self.fifo_mode:
            # Collect all pending tasks from all queues
            all_tasks = []
            for priority in [TaskPriority.HIGH, TaskPriority.MEDIUM, TaskPriority.LOW, TaskPriority.BACKGROUND]:
                all_tasks.extend(self.priority_queues[priority])
            all_tasks.extend(self.preempted_tasks)

            if not all_tasks:
                return None

            # Sort by arrival time (FIFO)
            all_tasks.sort(key=lambda x: x.task.arrival_time)
            earliest_entry = all_tasks[0]

            # Remove from original queue
            if earliest_entry in self.preempted_tasks:
                self.preempted_tasks.remove(earliest_entry)
            else:
                self.priority_queues[earliest_entry.task.priority].remove(earliest_entry)

            earliest_entry.start_time = current_time
            self.processing_tasks.append(earliest_entry)
            return earliest_entry

        # Priority Mode (Default): Check preempted tasks first (by priority)
        if self.preempted_tasks:
            self.preempted_tasks.sort(key=lambda x: (-x.task.priority, x.task.arrival_time))
            entry = self.preempted_tasks.pop(0)
            self.processing_tasks.append(entry)
            return entry

        # Check priority queues in order: HIGH -> MEDIUM -> LOW -> BACKGROUND
        for priority in [TaskPriority.HIGH, TaskPriority.MEDIUM, TaskPriority.LOW, TaskPriority.BACKGROUND]:
            if self.priority_queues[priority]:
                entry = heapq.heappop(self.priority_queues[priority])
                entry.start_time = current_time
                self.processing_tasks.append(entry)
                return entry

        return None

    def peek_next_task(self) -> Optional[TaskQueueEntry]:
        """
        Peek at the next highest priority task WITHOUT removing it from the queue.
        Used by _get_observation to read task info without side effects.
        """
        # Check preempted tasks first
        if self.preempted_tasks:
            sorted_preempted = sorted(self.preempted_tasks, key=lambda x: (-x.task.priority, x.task.arrival_time))
            return sorted_preempted[0]

        # Check priority queues in order
        for priority in [TaskPriority.HIGH, TaskPriority.MEDIUM, TaskPriority.LOW, TaskPriority.BACKGROUND]:
            if self.priority_queues[priority]:
                return self.priority_queues[priority][0]

        return None

    def complete_task(self, task_id: str, current_time: float) -> Optional[Task]:
        """
        Mark task as completed and remove from processing.
        Implements the C_i(t,t+Δt) component of queue dynamics.
        """
        for i, entry in enumerate(self.processing_tasks):
            if entry.task.id == task_id:
                completed_entry = self.processing_tasks.pop(i)
                # Preserve the original completion time; do not overwrite it with the current time
                if not hasattr(completed_entry, 'completion_time') or completed_entry.completion_time is None:
                    completed_entry.completion_time = completed_entry.estimated_completion_time or current_time
                self.completed_tasks.append(completed_entry)
                self.total_completed += 1
                return completed_entry.task
        
        return None
    
    def preempt_task(self, task_id: str, current_time: float) -> Optional[Task]:
        """
        Preempt a running task.
        Implements the P_i(t,t+Δt) component of queue dynamics.
        """
        for i, entry in enumerate(self.processing_tasks):
            if entry.task.id == task_id:
                preempted_entry = self.processing_tasks.pop(i)
                self.preempted_tasks.append(preempted_entry)
                self.total_preempted += 1
                return preempted_entry.task
        
        return None
    
    def check_expired_tasks(self, current_time: float) -> List[Task]:
        """Check and remove tasks that have exceeded their deadlines."""
        expired_tasks = []
        
        # Check all priority queues
        for priority in TaskPriority:
            queue = self.priority_queues[priority]
            valid_tasks = []
            
            for entry in queue:
                if current_time > entry.task.deadline:
                    expired_tasks.append(entry.task)
                else:
                    valid_tasks.append(entry)
            
            # Rebuild heap with valid tasks
            self.priority_queues[priority] = valid_tasks
            heapq.heapify(self.priority_queues[priority])
        
        # Check processing tasks (don't remove, just flag)
        for entry in self.processing_tasks:
            if current_time > entry.task.deadline:
                # Task is overdue but still processing
                pass
        
        return expired_tasks
    
    def get_queue_statistics(self, current_time: float) -> Dict:
        """Get comprehensive queue statistics."""
        queue_lengths, queue_load, busy_rate = self.get_queue_state(current_time)
        
        # Calculate average wait times by priority
        wait_times_by_priority = {priority.name: [] for priority in TaskPriority}
        
        for priority, queue in self.priority_queues.items():
            for entry in queue:
                wait_time = current_time - entry.enqueue_time
                wait_times_by_priority[priority.name].append(wait_time)
        
        avg_wait_times = {}
        for priority_name, wait_times in wait_times_by_priority.items():
            avg_wait_times[priority_name] = sum(wait_times) / len(wait_times) if wait_times else 0.0
        
        return {
            'drone_id': self.drone_id,
            'current_time': current_time,
            'queue_lengths': queue_lengths,
            'queue_load': queue_load,
            'busy_rate': busy_rate,
            'processing_count': len(self.processing_tasks),
            'total_flops_load': self.calculate_total_flops_load(),
            'total_arrived': self.total_arrived,
            'total_completed': self.total_completed,
            'total_preempted': self.total_preempted,
            'total_dropped': self.total_dropped,
            'avg_wait_times': avg_wait_times,
            'completion_rate': self.total_completed / max(1, self.total_arrived)
        }
    
    def __str__(self) -> str:
        """String representation of queue state."""
        queue_lengths = [len(self.priority_queues[p]) for p in TaskPriority]
        return f"TaskQueue(drone={self.drone_id}, queues={queue_lengths}, processing={len(self.processing_tasks)})"


if __name__ == "__main__":
    # Test the hierarchical task queue
    from .task_generator import TaskGenerator
    
    # Create queue and task generator
    queue = HierarchicalTaskQueue("test_drone")
    generator = TaskGenerator()
    
    current_time = 0.0
    dt = 1.0
    location = (50.0, 50.0)
    
    print("Testing Hierarchical Task Queue...")
    print()
    
    for step in range(10):
        print(f"=== Time {current_time:.1f} ===")
        
        # Generate new tasks
        new_tasks = generator.generate_tasks(dt, current_time, location)
        print(f"Generated {len(new_tasks)} new tasks")
        
        # Add tasks to queue
        for task in new_tasks:
            added = queue.add_task(task, current_time)
            if not added:
                print(f"  Failed to add task {task.id[:8]} (queue full)")
        
        # Process some tasks
        for _ in range(2):  # Try to start 2 tasks
            task_entry = queue.get_next_task_for_processing(current_time)
            if task_entry:
                print(f"  Started processing: {task_entry.task.id[:8]} (Priority: {task_entry.task.priority.name})")
        
        # Complete some tasks (simulate)
        if queue.processing_tasks:
            completed_task = queue.complete_task(queue.processing_tasks[0].task.id, current_time)
            if completed_task:
                print(f"  Completed task: {completed_task.id[:8]}")
        
        # Check expired tasks
        expired = queue.check_expired_tasks(current_time)
        if expired:
            print(f"  Expired {len(expired)} tasks")
        
        # Print statistics
        stats = queue.get_queue_statistics(current_time)
        print(f"  Queue state: {stats['queue_lengths']}, Load: {stats['queue_load']:.2f}, Busy: {stats['busy_rate']:.2f}")
        print(f"  Completion rate: {stats['completion_rate']:.2f}")
        print()
        
        current_time += dt