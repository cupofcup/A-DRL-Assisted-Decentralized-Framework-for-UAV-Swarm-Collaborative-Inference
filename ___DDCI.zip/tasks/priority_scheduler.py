"""
Priority scheduler implementing the mathematical formulation from CLAUDE.md.

Implements the task scheduling priority function:
π(τ, t) = w_p · p(τ) + w_d · (D(τ) - t)/(D(τ) - t_arrive(τ)) + w_c · c(τ)/c_max

And the preemption rule:
if ∃ τ_new with p(τ_new) > p(τ_current) then preempt τ_current
"""

import numpy as np
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

from .task_generator import Task, TaskPriority, TaskType
from .task_queue import TaskQueueEntry, HierarchicalTaskQueue


class SchedulingPolicy(Enum):
    """Scheduling policies supported by the scheduler."""
    PREEMPTIVE_PRIORITY = "preemptive_priority"  # Strict priority with preemption
    PRIORITY_WITH_DEADLINE = "priority_deadline"  # Priority with deadline consideration
    DYNAMIC_PRIORITY = "dynamic_priority"  # Dynamic priority using π(τ, t) function


@dataclass 
class SchedulerConfig:
    """Configuration for the priority scheduler."""
    # Weights for dynamic priority function π(τ, t)
    w_priority: float = 1.0      # w_p: Weight for priority level
    w_deadline: float = 0.5      # w_d: Weight for deadline urgency
    w_computation: float = 0.3   # w_c: Weight for computational load
    
    # Maximum values for normalization
    max_priority: int = 3        # Maximum priority level
    max_flops: float = 1e10      # Maximum FLOPS per task (10 GFLOPS)
    
    # Scheduling policy
    policy: SchedulingPolicy = SchedulingPolicy.PREEMPTIVE_PRIORITY
    
    # Minimum execution time before allowing preemption
    min_execution_time: float = 0.1
    
    # Time quantum for round-robin within same priority (if applicable)
    time_quantum: float = 1.0


class PriorityScheduler:
    """
    Priority scheduler implementing the mathematical models from CLAUDE.md.
    
    Handles:
    1. Preemptive priority scheduling: p=3 > p=2 > p=1 > p=0
    2. Dynamic priority calculation: π(τ, t) 
    3. Background task execution during idle periods
    4. Deadline-aware scheduling
    """
    
    def __init__(self, config: SchedulerConfig = None):
        self.config = config if config else SchedulerConfig()
        
        # Currently executing task information
        self.current_task: Optional[TaskQueueEntry] = None
        self.task_start_time: float = 0.0
        self.estimated_remaining_time: float = 0.0
        
        # Scheduling statistics
        self.total_preemptions = 0
        self.total_context_switches = 0
        self.scheduling_decisions = 0
    
    def calculate_dynamic_priority(self, task: Task, current_time: float) -> float:
        """
        Calculate dynamic priority using the formula from CLAUDE.md:
        π(τ, t) = w_p · p(τ) + w_d · (D(τ) - t)/(D(τ) - t_arrive(τ)) + w_c · c(τ)/c_max
        
        Args:
            task: Task to calculate priority for
            current_time: Current simulation time
            
        Returns:
            Dynamic priority score (higher = more urgent)
        """
        # Priority component: w_p · p(τ)
        priority_component = self.config.w_priority * (task.priority / self.config.max_priority)
        
        # Deadline component: w_d · (D(τ) - t)/(D(τ) - t_arrive(τ))
        time_until_deadline = max(0.1, task.deadline - current_time)
        total_task_lifetime = max(0.1, task.deadline - task.arrival_time)
        deadline_component = self.config.w_deadline * (time_until_deadline / total_task_lifetime)
        
        # Computation component: w_c · c(τ)/c_max  
        computation_component = self.config.w_computation * (task.flops / self.config.max_flops)
        
        # Combined dynamic priority
        dynamic_priority = priority_component + deadline_component + computation_component
        
        return dynamic_priority
    
    def should_preempt(self, current_task: TaskQueueEntry, new_task: TaskQueueEntry, current_time: float) -> bool:
        """
        Determine if current task should be preempted by new task.
        
        Implements the preemption rule from CLAUDE.md:
        if ∃ τ_new with p(τ_new) > p(τ_current) then preempt τ_current
        """
        if current_task is None:
            return True
        
        # Check minimum execution time to avoid thrashing
        execution_time = current_time - self.task_start_time
        if execution_time < self.config.min_execution_time:
            # Only allow preemption for emergency tasks
            if new_task.task.priority == TaskPriority.HIGH and current_task.task.priority < TaskPriority.HIGH:
                return True
            return False
        
        if self.config.policy == SchedulingPolicy.PREEMPTIVE_PRIORITY:
            # Strict priority preemption
            return new_task.task.priority > current_task.task.priority
        
        elif self.config.policy == SchedulingPolicy.PRIORITY_WITH_DEADLINE:
            # Consider both priority and deadline
            if new_task.task.priority > current_task.task.priority:
                return True
            elif new_task.task.priority == current_task.task.priority:
                # Same priority: check deadline urgency
                new_urgency = (new_task.task.deadline - current_time)
                current_urgency = (current_task.task.deadline - current_time)
                return new_urgency < current_urgency
            return False
        
        elif self.config.policy == SchedulingPolicy.DYNAMIC_PRIORITY:
            # Use dynamic priority function
            new_priority = self.calculate_dynamic_priority(new_task.task, current_time)
            current_priority = self.calculate_dynamic_priority(current_task.task, current_time)
            return new_priority > current_priority
        
        return False
    
    def select_next_task(self, task_queue: HierarchicalTaskQueue, current_time: float) -> Optional[TaskQueueEntry]:
        """
        Select the next task to execute based on scheduling policy.
        
        Args:
            task_queue: Queue containing available tasks
            current_time: Current simulation time
            
        Returns:
            Selected task entry or None if no tasks available
        """
        self.scheduling_decisions += 1
        
        if self.config.policy == SchedulingPolicy.PREEMPTIVE_PRIORITY:
            # Strict priority order: HIGH -> MEDIUM -> LOW -> BACKGROUND
            return task_queue.get_next_task_for_processing(current_time)
        
        elif self.config.policy == SchedulingPolicy.PRIORITY_WITH_DEADLINE:
            # Priority with deadline consideration
            return self._select_by_priority_and_deadline(task_queue, current_time)
        
        elif self.config.policy == SchedulingPolicy.DYNAMIC_PRIORITY:
            # Dynamic priority using π(τ, t) function
            return self._select_by_dynamic_priority(task_queue, current_time)
        
        return task_queue.get_next_task_for_processing(current_time)
    
    def _select_by_priority_and_deadline(self, task_queue: HierarchicalTaskQueue, current_time: float) -> Optional[TaskQueueEntry]:
        """Select task considering both priority and deadline."""
        candidate_tasks = []
        
        # Collect all available tasks from all priority queues
        for priority in TaskPriority:
            queue = task_queue.priority_queues[priority]
            for entry in queue:
                candidate_tasks.append(entry)
        
        if not candidate_tasks:
            return None
        
        # Sort by priority first, then by deadline urgency
        def priority_deadline_key(entry: TaskQueueEntry):
            priority_score = entry.task.priority
            deadline_urgency = 1.0 / max(0.1, entry.task.deadline - current_time)
            return (-priority_score, -deadline_urgency)  # Negative for descending order
        
        candidate_tasks.sort(key=priority_deadline_key)
        
        # Remove selected task from its queue and return
        selected_entry = candidate_tasks[0]
        task_queue.priority_queues[selected_entry.task.priority].remove(selected_entry)
        selected_entry.start_time = current_time
        task_queue.processing_tasks.append(selected_entry)
        
        return selected_entry
    
    def _select_by_dynamic_priority(self, task_queue: HierarchicalTaskQueue, current_time: float) -> Optional[TaskQueueEntry]:
        """Select task using dynamic priority function π(τ, t)."""
        candidate_tasks = []
        
        # Collect all available tasks with their dynamic priorities
        for priority in TaskPriority:
            queue = task_queue.priority_queues[priority]
            for entry in queue:
                dynamic_priority = self.calculate_dynamic_priority(entry.task, current_time)
                candidate_tasks.append((dynamic_priority, entry))
        
        if not candidate_tasks:
            return None
        
        # Sort by dynamic priority (highest first)
        candidate_tasks.sort(key=lambda x: -x[0])
        
        # Remove selected task from its queue and return
        _, selected_entry = candidate_tasks[0]
        task_queue.priority_queues[selected_entry.task.priority].remove(selected_entry)
        selected_entry.start_time = current_time
        task_queue.processing_tasks.append(selected_entry)
        
        return selected_entry
    
    def schedule_tasks(self, task_queue: HierarchicalTaskQueue, current_time: float) -> List[TaskQueueEntry]:
        """
        Main scheduling function that handles task selection and preemption.
        
        Returns:
            List of tasks that should be executed (in priority order)
        """
        scheduled_tasks = []
        
        # Handle preemption checks for currently running tasks
        for i, running_entry in enumerate(task_queue.processing_tasks):
            # Check if any waiting task should preempt this running task
            should_preempt_current = False
            preempting_task = None
            
            for priority in [TaskPriority.HIGH, TaskPriority.MEDIUM, TaskPriority.LOW, TaskPriority.BACKGROUND]:
                queue = task_queue.priority_queues[priority]
                if queue:
                    candidate_entry = queue[0]  # Highest priority task in this queue
                    if self.should_preempt(running_entry, candidate_entry, current_time):
                        should_preempt_current = True
                        preempting_task = candidate_entry
                        break
            
            if should_preempt_current and preempting_task:
                # Preempt current task
                task_queue.preempt_task(running_entry.task.id, current_time)
                self.total_preemptions += 1
                
                # Start the preempting task
                task_queue.priority_queues[preempting_task.task.priority].remove(preempting_task)
                preempting_task.start_time = current_time
                task_queue.processing_tasks.append(preempting_task)
                scheduled_tasks.append(preempting_task)
            else:
                # Keep current task running
                scheduled_tasks.append(running_entry)
        
        # Fill remaining processing slots with new tasks
        while len(task_queue.processing_tasks) < task_queue.max_concurrent_tasks:
            next_task = self.select_next_task(task_queue, current_time)
            if next_task:
                scheduled_tasks.append(next_task)
                self.total_context_switches += 1
            else:
                break
        
        return scheduled_tasks
    
    def estimate_completion_time(self, task: Task, processing_capacity: float) -> float:
        """
        Estimate task completion time based on FLOPS and processing capacity.
        
        Args:
            task: Task to estimate completion time for
            processing_capacity: Available FLOPS per second
            
        Returns:
            Estimated completion time in time units
        """
        if processing_capacity <= 0:
            return float('inf')
        
        return task.flops / processing_capacity
    
    def get_scheduler_statistics(self) -> Dict:
        """Get comprehensive scheduler statistics."""
        return {
            'total_preemptions': self.total_preemptions,
            'total_context_switches': self.total_context_switches,
            'scheduling_decisions': self.scheduling_decisions,
            'current_policy': self.config.policy.value,
            'config': {
                'w_priority': self.config.w_priority,
                'w_deadline': self.config.w_deadline,
                'w_computation': self.config.w_computation,
                'min_execution_time': self.config.min_execution_time
            }
        }
    
    def update_config(self, **kwargs):
        """Update scheduler configuration parameters."""
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)


if __name__ == "__main__":
    # Test the priority scheduler
    from .task_generator import TaskGenerator
    
    # Create scheduler, queue, and task generator
    scheduler = PriorityScheduler(SchedulerConfig(policy=SchedulingPolicy.DYNAMIC_PRIORITY))
    task_queue = HierarchicalTaskQueue("test_drone", max_concurrent_tasks=2)
    generator = TaskGenerator()
    
    current_time = 0.0
    dt = 1.0
    location = (50.0, 50.0)
    processing_capacity = 1e10  # 10 GFLOPS per second
    
    print("Testing Priority Scheduler...")
    print(f"Policy: {scheduler.config.policy.value}")
    print()
    
    for step in range(8):
        print(f"=== Time {current_time:.1f} ===")
        
        # Generate new tasks
        new_tasks = generator.generate_tasks(dt, current_time, location)
        print(f"Generated {len(new_tasks)} new tasks")
        
        # Add tasks to queue
        for task in new_tasks:
            added = task_queue.add_task(task, current_time)
            if added:
                priority_score = scheduler.calculate_dynamic_priority(task, current_time)
                print(f"  Added task {task.id[:8]}: Priority={task.priority.name}, Score={priority_score:.3f}")
        
        # Schedule tasks
        scheduled_tasks = scheduler.schedule_tasks(task_queue, current_time)
        print(f"Scheduled {len(scheduled_tasks)} tasks for execution:")
        
        for i, entry in enumerate(scheduled_tasks):
            completion_time = scheduler.estimate_completion_time(entry.task, processing_capacity)
            print(f"  {i+1}. Task {entry.task.id[:8]} (Priority: {entry.task.priority.name}, Est. completion: {completion_time:.2f}s)")
        
        # Simulate task completion (complete first scheduled task)
        if scheduled_tasks:
            completed_task = task_queue.complete_task(scheduled_tasks[0].task.id, current_time)
            if completed_task:
                print(f"  Completed: {completed_task.id[:8]}")
        
        # Print queue state and scheduler stats
        queue_stats = task_queue.get_queue_statistics(current_time)
        scheduler_stats = scheduler.get_scheduler_statistics()
        print(f"  Queue: {queue_stats['queue_lengths']}, Load: {queue_stats['queue_load']:.2f}")
        print(f"  Preemptions: {scheduler_stats['total_preemptions']}, Context switches: {scheduler_stats['total_context_switches']}")
        print()
        
        current_time += dt