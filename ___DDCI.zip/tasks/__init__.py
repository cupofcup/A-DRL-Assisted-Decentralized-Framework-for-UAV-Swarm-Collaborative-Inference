"""
Tasks module implementing 4-level hierarchical task system based on CLAUDE.md.

This module provides:
- TaskGenerator: Layered arrival models (Poisson, Compound Poisson, Batch Arrival)
- HierarchicalTaskQueue: 4-priority queue with preemption support
- PriorityScheduler: Dynamic priority scheduling with π(τ, t) function
- Task data structures: Task, TaskPriority, TaskType enums
"""

from .task_generator import (
    Task,
    TaskPriority, 
    TaskType,
    TaskGenerator
)

from .task_queue import (
    TaskQueueEntry,
    HierarchicalTaskQueue
)

from .priority_scheduler import (
    SchedulingPolicy,
    SchedulerConfig,
    PriorityScheduler
)

__all__ = [
    # Core data structures
    'Task',
    'TaskPriority',
    'TaskType',
    'TaskQueueEntry',
    
    # Main classes
    'TaskGenerator',
    'HierarchicalTaskQueue', 
    'PriorityScheduler',
    
    # Configuration
    'SchedulingPolicy',
    'SchedulerConfig',
]