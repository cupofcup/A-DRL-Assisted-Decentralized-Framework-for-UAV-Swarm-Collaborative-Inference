"""
Baseline algorithm module

Includes multiple baseline strategies:
- Random: random selection strategy
- Greedy-Load: greedy load-balancing strategy
- Heuristic: heuristic strategy
- Local-Only: local-only processing strategy
- Comm-Min: minimum communication distance strategy
- Cal-Avg: compute-average allocation strategy
- Layer-Avg: layer-average strategy
- CoDNN: PSO-optimized DNN partitioning strategy

Based on papers:
- Pipeline DNN Inference (Comm-Min, Cal-Avg, Layer-Avg)
- CoDNN (PSO-based optimization)
"""

from .random_policy import random_strategy
from .greedy_load_policy import greedy_load_strategy
from .local_only_policy import local_only_strategy
from .comm_min_policy import comm_min_strategy
from .cal_avg_policy import cal_avg_strategy
from .layer_avg_policy import layer_avg_strategy
from .codnn_policy import codnn_strategy
from .epcta_policy import epcta_strategy

__all__ = [
    'random_strategy',
    'greedy_load_strategy',
    'local_only_strategy',
    'comm_min_strategy',
    'cal_avg_strategy',
    'layer_avg_strategy',
    'codnn_strategy',
    'epcta_strategy',
]
