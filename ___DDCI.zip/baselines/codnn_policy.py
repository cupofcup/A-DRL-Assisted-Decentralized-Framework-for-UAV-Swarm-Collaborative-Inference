"""
CoDNN strategy: PSO-optimized DNN partitioning strategy

Based on paper: "A Novel Adaptive Computation Offloading Strategy for
Collaborative DNN Inference over Edge Devices"

Core idea:
1. Use particle swarm optimization (PSO) to find the optimal partition point
2. Fitness function: F(Si) = d1*Tmax + d2*100*(Tmax^2/td) + td*n'
3. Consider the trade-off between communication latency and computation latency

Simplified implementation:
- Uses a lightweight PSO (5 particles, 10 iterations)
- Estimates latency based on the observed state
- Suitable for online decision-making scenarios
"""
import numpy as np


class SimplePSO:
    """Simplified particle swarm optimization algorithm"""

    def __init__(self, n_particles=5, n_iterations=10, w=0.5, c1=1.5, c2=1.5):
        """
        Args:
            n_particles: number of particles
            n_iterations: number of iterations
            w: inertia weight
            c1: cognitive (individual) learning factor
            c2: social learning factor
        """
        self.n_particles = n_particles
        self.n_iterations = n_iterations
        self.w = w
        self.c1 = c1
        self.c2 = c2

    def optimize(self, fitness_func, bounds, dim=2):
        """
        PSO optimization

        Args:
            fitness_func: fitness function (lower is better)
            bounds: variable bounds [(min1, max1), (min2, max2), ...]
            dim: dimensionality

        Returns:
            best_position: best position
            best_fitness: best fitness
        """
        # Initialize particle positions and velocities
        positions = np.random.uniform(
            low=[b[0] for b in bounds],
            high=[b[1] for b in bounds],
            size=(self.n_particles, dim)
        )

        velocities = np.zeros((self.n_particles, dim))

        # Personal best
        personal_best_positions = positions.copy()
        personal_best_fitness = np.array([fitness_func(p) for p in positions])

        # Global best
        global_best_idx = np.argmin(personal_best_fitness)
        global_best_position = personal_best_positions[global_best_idx].copy()
        global_best_fitness = personal_best_fitness[global_best_idx]

        # PSO iterations
        for iteration in range(self.n_iterations):
            for i in range(self.n_particles):
                # Update velocity
                r1, r2 = np.random.rand(2)
                velocities[i] = (
                    self.w * velocities[i] +
                    self.c1 * r1 * (personal_best_positions[i] - positions[i]) +
                    self.c2 * r2 * (global_best_position - positions[i])
                )

                # Update position
                positions[i] += velocities[i]

                # Boundary handling
                for d in range(dim):
                    positions[i][d] = np.clip(positions[i][d], bounds[d][0], bounds[d][1])

                # Evaluate fitness
                fitness = fitness_func(positions[i])

                # Update personal best
                if fitness < personal_best_fitness[i]:
                    personal_best_fitness[i] = fitness
                    personal_best_positions[i] = positions[i].copy()

                    # Update global best
                    if fitness < global_best_fitness:
                        global_best_fitness = fitness
                        global_best_position = positions[i].copy()

        return global_best_position, global_best_fitness


class CoDNNDecisionMaker:
    """CoDNN decision maker"""

    def __init__(self):
        self.pso = SimplePSO(n_particles=5, n_iterations=10)

        # Fitness function weights (paper parameters)
        self.d1 = 0.5  # maximum-latency weight
        self.d2 = 0.5  # fairness weight

    def estimate_computation_time(self, flops_norm, layer_ratio, device_load):
        """
        Estimate computation latency

        Args:
            flops_norm: normalized FLOPS demand [0, 1]
            layer_ratio: fraction of layers processed locally [0, 1]
            device_load: device load [0, 1]

        Returns:
            computation_time: estimated computation latency (seconds)
        """
        # Base computation time (accounting for load impact)
        base_time = 0.3 * flops_norm * layer_ratio
        load_penalty = 1.0 + device_load * 0.5
        return base_time * load_penalty

    def estimate_communication_time(self, layer_cut, distance_norm):
        """
        Estimate communication latency

        Args:
            layer_cut: partition point (0-8)
            distance_norm: normalized distance [0, 1]

        Returns:
            communication_time: estimated communication latency (seconds)
        """
        # The transmitted intermediate-feature data volume depends on the partition point: real DNNs have large shallow feature maps and small deep ones (monotonically decreasing)
        # (Corrects the original inverted-V model, which wrongly assumed the middle layers were largest, contrary to real feature-map sizes)
        data_ratio = 1.0 - layer_cut / 8.0  # deeper cut -> less transmitted data

        # Base communication time
        base_comm_time = 0.1 * data_ratio * distance_norm
        return base_comm_time

    def fitness_function(self, solution, obs):
        """
        CoDNN fitness function

        F(Si) = d1 * Tmax + d2 * 100 * (Tmax^2 / td) + td * n'

        Simplified version:
        F = d1 * max_latency + d2 * latency_variance + total_latency

        Args:
            solution: [partner_idx_float, layer_cut_float]
            obs: observed state

        Returns:
            fitness: fitness value (lower is better)
        """
        partner_idx = int(solution[0])
        layer_cut = int(solution[1])

        # Extract observation info
        flops_norm = obs[0]
        self_load = obs[2]

        # Neighbor info (new layout: self is 7-dim, each neighbor has 3 features [distance, load, compute], starting at index 7)
        partner_dist = obs[7 + partner_idx * 3]
        partner_load = obs[8 + partner_idx * 3]

        # Estimate local computation latency
        local_comp_time = self.estimate_computation_time(
            flops_norm,
            layer_cut / 8.0,
            self_load
        )

        # Estimate communication latency
        comm_time = self.estimate_communication_time(layer_cut, partner_dist)

        # Estimate collaborator computation latency
        remote_comp_time = self.estimate_computation_time(
            flops_norm,
            1.0 - layer_cut / 8.0,
            partner_load
        )

        # Total latency (pipeline model: max(local compute, communication + remote compute))
        total_latency = max(local_comp_time, comm_time + remote_comp_time)

        # Maximum latency (considering load balancing)
        max_latency = max(
            local_comp_time + comm_time,
            remote_comp_time
        )

        # Latency variance (fairness)
        latency_variance = abs(local_comp_time - remote_comp_time)

        # Fitness function
        fitness = (
            self.d1 * max_latency +
            self.d2 * latency_variance +
            total_latency
        )

        return fitness

    def make_decision(self, obs):
        """
        Make a decision based on PSO optimization

        Args:
            obs: observed state

        Returns:
            action: action (0-27)
        """
        # Adaptive K: observation dim = 7 + 3K -> solve for K, supporting K in {2,3,4,5}.
        # Action space = K*9 + 1, local action = K*9, partner_idx in [0,K-1].
        K = max(1, (len(obs) - 7) // 3)

        # Define optimization bounds
        bounds = [
            (0, K - 1),  # partner_idx: 0..K-1
            (0, 8)       # layer_cut: 0-8
        ]

        # Define the fitness function (closure)
        def fitness(solution):
            return self.fitness_function(solution, obs)

        # PSO optimization
        best_solution, best_fitness = self.pso.optimize(
            fitness_func=fitness,
            bounds=bounds,
            dim=2
        )

        # Decode the best solution
        partner_idx = int(np.round(best_solution[0]))
        layer_cut = int(np.round(best_solution[1]))

        # Boundary check
        partner_idx = int(np.clip(partner_idx, 0, K - 1))
        layer_cut = int(np.clip(layer_cut, 0, 8))

        # Convert to the action space
        if layer_cut == 0:
            # All layers processed locally (equivalent to local processing)
            action = K * 9
        else:
            action = partner_idx * 9 + layer_cut

        return action


# Global decision maker (avoids re-initializing PSO on every call)
_codnn_decision_maker = CoDNNDecisionMaker()


def codnn_strategy(obs):
    """
    CoDNN strategy function

    Uses PSO optimization to find the optimal collaborator and partition point

    Args:
        obs: observation vector [flops_norm, queue_load, busy_rate,
                      dist1, load1, dist2, load2, dist3, load3]

    Returns:
        action: integer action in the range 0-27
    """
    global _codnn_decision_maker
    return _codnn_decision_maker.make_decision(obs)


def codnn_strategy_fast(obs):
    """
    CoDNN fast version (reduced PSO iterations)

    Suitable for scenarios requiring fast decision-making
    """
    decision_maker = CoDNNDecisionMaker()
    decision_maker.pso.n_iterations = 5  # reduce iterations
    decision_maker.pso.n_particles = 3   # reduce number of particles

    return decision_maker.make_decision(obs)
