"""
Comm-Min strategy: minimum communication distance strategy

Selects the neighbor with the smallest communication distance (the nearest neighbor) for collaboration

Based on paper: Efficient Pipeline Collaborative DNN Inference - Comm-Min baseline
"""
import numpy as np


def comm_min_strategy(obs):
    """
    Minimum communication distance strategy: select the nearest neighbor

    Strategy logic:
    - Select the nearest neighbor for collaboration
    - Use a fixed middle partition point layer_cut=4
    - Goal: minimize communication latency

    Args:
        obs: observation vector (16-dim) [flops_norm, queue_load, busy_rate, priority, urgency, self_cap, battery,
                      d1,load1,cap1, d2,load2,cap2, d3,load3,cap3]

    Returns:
        action: integer action in the range 0-27
    """
    # Infer neighbor count K from obs length (self is 7-dim, each neighbor is [distance, load, compute])
    K = (len(obs) - 7) // 3
    distances = [obs[7 + i*3] for i in range(K)]

    # Minimize communication: pick the nearest neighbor + the partition point with the smallest transmitted data volume (deepest layer, smallest intermediate feature map)
    # layer_cut=8 -> maps to the deepest candidate layer, smallest intermediate feature, faithfully reflecting the "minimize communication" semantics
    partner_idx = int(np.argmin(distances))
    layer_cut = 8

    return partner_idx * 9 + layer_cut
