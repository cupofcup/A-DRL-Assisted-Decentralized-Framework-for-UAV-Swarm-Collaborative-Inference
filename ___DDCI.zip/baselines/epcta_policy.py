"""
EPCTA (common-substrate variant)

Based on paper: Efficient Pipeline Collaborative DNN Inference in
Resource-Constrained UAV Swarm (ren2024pipeline, WCNC 2024)

Core idea of the original paper:
- N UAVs form a chain pipeline (N>=5)
- Uses DRL to optimize layer allocation
- Goal: minimize total completion latency

Version note: this file is the **common-substrate variant** that ports the
original paper's "capacity-proportional allocation (Cal-Avg)" idea onto DDCI's
2-UAV pairwise collaboration substrate, used for a "same-paradigm, decision-maker-only"
comparison (it shares exactly the same environment, task generation, and latency
computation as DDCI; only the decision strategy differs: DDCI uses DRL, this variant
uses a heuristic).

The **faithful original** (N-UAV chain pipeline + the paper's documented Layer-Avg/Cal-Avg
allocation) is in `baselines/epcta_chain_pipeline.py` + `baselines/epcta_chain_eval.py`,
reported in the paper as "EPCTA-LayerAvg / EPCTA-CalAvg (chain, N=5)".

Logic of this variant:
- Load-aware neighbor selection: select the neighbor with the highest effective processing capacity
- Compute-balanced model partition: dynamically select the partition point based on the capacity ratio of self and neighbor
- Uses pipeline mode (enable_pipeline=True)
"""
import numpy as np


def epcta_strategy(obs):
    """
    EPCTA strategy (adapted to the 2-UAV collaboration framework, pipeline mode)

    Strategy logic (based on the paper's idea):
    1. Load-aware: select the neighbor with the highest effective processing capacity (capacity * (1-load))
    2. Compute-balanced partition: select the partition point based on the capacity ratio of the two ends, so their processing times are close

    Args:
        obs: observation vector (16-dim)
             [flops_norm, queue_load, busy_rate, task_priority_norm,
              deadline_urgency, self_capacity_norm, battery_pct,
              d1,load1,cap1, d2,load2,cap2, d3,load3,cap3]

    Returns:
        action: integer action in the range 0-27
    """
    self_capacity = obs[5]   # normalized self compute capacity
    self_load = obs[2]       # self busy rate

    # Infer neighbor count K from obs length (self is 7-dim, each neighbor has 3 features [distance, load, compute])
    K = (len(obs) - 7) // 3
    neighbors = [
        {'cap': obs[7 + i*3 + 2], 'load': obs[7 + i*3 + 1]}
        for i in range(K)
    ]

    # Effective processing capacity = capacity * (1 - load)
    effective_caps = [n['cap'] * (1 - n['load']) for n in neighbors]

    # Select the neighbor with the highest effective processing capacity
    partner_idx = int(np.argmax(effective_caps))

    # Compute-balanced partition: based on the capacity ratio of self and neighbor
    self_eff = self_capacity * (1 - self_load)
    partner_eff = effective_caps[partner_idx]
    total_eff = self_eff + partner_eff + 1e-8

    # Proportion self should process
    self_ratio = self_eff / total_eff

    # Map by capacity ratio to the feasible partition range [4,8] (deep layers have small features), same starting line as DDCI/greedy,
    # covering the entire feasible interval rather than collapsing to the lower bound (the original round(ratio*8) would clamp all ratio<0.56 to 4)
    layer_cut = int(np.clip(round(4 + self_ratio * 4), 4, 8))

    return partner_idx * 9 + layer_cut
