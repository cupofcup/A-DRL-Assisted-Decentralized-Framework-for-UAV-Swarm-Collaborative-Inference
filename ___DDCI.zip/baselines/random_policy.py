"""
Random strategy: randomly selects the collaborator and the partition point

Serves as the most basic baseline to validate the learning effect of DRL
"""
import numpy as np


def random_strategy(obs):
    """
    Random strategy: randomly select from 28 actions (k*9+1=28)

    Args:
        obs: observation vector (16-dim) [flops_norm, queue_load, busy_rate, priority, urgency, self_cap, battery,
                      d1,load1,cap1, d2,load2,cap2, d3,load3,cap3]

    Returns:
        action: integer action in the range 0-27
    """
    # Adaptive K: observation dim = 7 + 3K -> action space = K*9 + 1. K in {2,3,4,5}.
    K = max(1, (len(obs) - 7) // 3)
    return np.random.randint(0, K * 9 + 1)
