"""
Cal-Avg strategy: compute-average allocation strategy

Uses a fixed middle partition point and selects the least-loaded neighbor

Based on paper: Efficient Pipeline Collaborative DNN Inference - Cal-Avg baseline
"""
import numpy as np


def cal_avg_strategy(obs):
    """
    Compute-average allocation strategy: fixed partition point, evenly split computation

    Strategy logic:
    - Use a fixed layer_cut=4, i.e. the first 4 layers are processed locally and the last 4 layers are processed collaboratively
    - Select the least-loaded neighbor
    - Equivalent to the "evenly split computation" strategy

    Args:
        obs: observation vector [flops_norm, queue_load, busy_rate,
                      dist1, load1, dist2, load2, dist3, load3]

    Returns:
        action: integer action in the range 0-27
    """
    loads = [obs[4], obs[6], obs[8]]  # load1, load2, load3

    partner_idx = int(np.argmin(loads))
    layer_cut = 4  # fixed even partition

    return partner_idx * 9 + layer_cut
