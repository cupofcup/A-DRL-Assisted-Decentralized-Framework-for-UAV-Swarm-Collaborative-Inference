"""
Layer-Avg strategy: layer-average strategy

Selects the neighbor by jointly considering distance and load, using a fixed even layer allocation

Based on paper: Efficient Pipeline Collaborative DNN Inference - Layer-Avg baseline
"""
import numpy as np


def layer_avg_strategy(obs):
    """
    Layer-average strategy: fixed layer allocation combining distance and load

    Strategy logic:
    - Use a fixed even layer allocation (layer_cut=4)
    - Select the neighbor by jointly considering distance and load: prefer low load and short distance
    - Use a weighted utility function: utility = -0.5*load - 0.5*dist

    Args:
        obs: observation vector [flops_norm, queue_load, busy_rate,
                      dist1, load1, dist2, load2, dist3, load3]

    Returns:
        action: integer action in the range 0-27
    """
    neighbors = [
        {'dist': obs[3], 'load': obs[4]},
        {'dist': obs[5], 'load': obs[6]},
        {'dist': obs[7], 'load': obs[8]}
    ]

    # Compute utility: smaller load and distance are both preferred
    utilities = []
    for n in neighbors:
        utility = -0.5 * n['load'] - 0.5 * n['dist']
        utilities.append(utility)

    partner_idx = int(np.argmax(utilities))  # select the highest-utility neighbor
    layer_cut = 4  # even layer allocation

    return partner_idx * 9 + layer_cut
