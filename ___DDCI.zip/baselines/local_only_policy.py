"""
Local-Only strategy: local processing only, no collaboration

Serves as the most conservative baseline; all tasks are completed locally
"""


def local_only_strategy(obs):
    """
    Local processing strategy: does not use collaboration

    Strategy logic:
    - Always select action=27 (local processing)
    - All computation is completed on the local drone

    Args:
        obs: observation vector [flops_norm, queue_load, busy_rate,
                      dist1, load1, dist2, load2, dist3, load3]

    Returns:
        action: 27 (local processing action)
    """
    return 27
