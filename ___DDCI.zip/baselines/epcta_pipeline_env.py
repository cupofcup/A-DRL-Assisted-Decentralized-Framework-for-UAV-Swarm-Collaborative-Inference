"""
EPCTA Pipeline Environment

N-UAV chain pipeline collaboration environment, supporting minibatch pipeline parallelism.

Core features:
1. Multiple parallel pipelines (10 UAVs -> 5 x 2-UAV pipelines)
2. Each pipeline uses minibatch pipeline parallelism internally:
   - A task is split into M mini-batches
   - Different mini-batches are processed at different stages simultaneously (compute-communication overlap)
3. Uses a fixed even-split strategy (no DRL optimization)
"""

import numpy as np
from typing import List, Tuple, Dict
from dataclasses import dataclass, field
from collections import deque
from models.configurable_partitioner import create_partitioner


@dataclass
class MinibatchTask:
    """A task in the pipeline (supports minibatch splitting)"""
    task_id: int
    flops: float
    arrival_time: float
    num_batches: int  # number of mini-batches
    batches_completed: int = 0  # number of completed batches
    pure_processing_time: float = 0.0  # pure processing time (equivalent latency after the pipeline)


class MinibatchPipelineEnv:
    """
    2-UAV pipeline environment supporting minibatch pipeline parallelism

    2 UAVs form a pipeline:
    - UAV_A processes the first half of the layers (stage 0)
    - UAV_B processes the second half of the layers (stage 1)

    Minibatch pipeline parallelism:
    - A task is split into M mini-batches
    - After batch_0 completes at stage_0 it is passed to stage_1, while batch_1 starts processing at stage_0
    - Achieves compute-communication overlap, greatly improving throughput

    Pipeline latency formula (M batches, 2 stages):
    T_pipeline = T_stage0 + (M-1) * max(T_stage0, T_comm, T_stage1) + T_comm + T_stage1
    Equivalent per-task latency ~= T_stage0 + T_comm + T_stage1 (the startup overhead is amortized when M is large enough)
    """

    def __init__(self,
                 network_layers: int = 8,
                 network_type: str = 'resnet-8',
                 cut_layer: int = 4,
                 uav_capacities: Tuple[float, float] = (10e9, 10e9),
                 bandwidth_mbps: float = 100.0,
                 comm_radius: float = 200.0,
                 simulation_time: float = 40.0,
                 num_minibatches: int = 4):
        """
        Args:
            network_layers: total number of DNN layers
            network_type: network type
            cut_layer: partition point (the first cut_layer layers go to UAV_A)
            uav_capacities: (UAV_A capacity, UAV_B capacity) FLOPS/s
            bandwidth_mbps: communication bandwidth
            comm_radius: communication range
            simulation_time: simulation time
            num_minibatches: how many mini-batches each task is split into
        """
        self.network_layers = network_layers
        self.cut_layer = cut_layer
        self.uav_capacities = uav_capacities
        self.bandwidth_mbps = bandwidth_mbps
        self.comm_radius = comm_radius
        self.simulation_time = simulation_time
        self.num_minibatches = num_minibatches

        # Get the real layer specs
        self.partitioner = create_partitioner(network_type)
        self.layer_specs = self.partitioner.layer_specs

        # Statistics
        self.stats = {
            'tasks_generated': 0,
            'tasks_completed': 0,
            'total_latency': 0.0,
            'total_flops': 0.0,
        }

    def _get_part_flops(self, task_flops: float, part: int) -> float:
        """Get the FLOPS of the first/second half"""
        if part == 0:  # stage A: layer [0, cut_layer)
            return task_flops * (self.cut_layer / self.network_layers)
        else:  # stage B: layer [cut_layer, network_layers)
            return task_flops * ((self.network_layers - self.cut_layer) / self.network_layers)

    def _get_comm_data_size_mb(self) -> float:
        """Get the intermediate data size (MB) at the partition point"""
        if self.cut_layer - 1 < len(self.layer_specs):
            return self.layer_specs[self.cut_layer - 1].data_size_bytes / (1024 * 1024)
        ratio = 1.0 - (self.cut_layer / self.network_layers)
        return 0.5 * (1.0 + ratio)

    def _calculate_pipeline_latency(self, task_flops: float) -> float:
        """
        Compute the minibatch pipeline latency of a single task

        Latency of M mini-batches in a 2-stage pipeline:
        T = T_a + (M-1) * max(T_a, T_comm, T_b) + T_comm + T_b

        where each mini-batch's compute = task_flops / M
        """
        M = self.num_minibatches
        batch_flops = task_flops / M

        # Compute time of each mini-batch at stage A
        part_a_flops = self._get_part_flops(batch_flops, 0)
        T_a = part_a_flops / self.uav_capacities[0]

        # Compute time of each mini-batch at stage B
        part_b_flops = self._get_part_flops(batch_flops, 1)
        T_b = part_b_flops / self.uav_capacities[1]

        # Communication time (each mini-batch's intermediate data = total data / M)
        data_size_mb = self._get_comm_data_size_mb() / M
        bandwidth_mb_s = self.bandwidth_mbps / 8
        T_comm = data_size_mb / bandwidth_mb_s

        # Fixed overhead
        uav_distance = self.comm_radius * 0.5
        propagation_delay = uav_distance / 3e8
        processing_overhead = 0.002
        T_comm += propagation_delay + processing_overhead

        # Pipeline formula: the first batch traverses the whole pipeline + subsequent batches only wait for the bottleneck stage
        bottleneck = max(T_a, T_comm, T_b)
        T_pipeline = T_a + T_comm + T_b + (M - 1) * bottleneck

        return T_pipeline

    def _calculate_max_throughput(self) -> float:
        """Compute the maximum throughput of a single pipeline (tasks/s)"""
        avg_flops = 10e9
        M = self.num_minibatches
        batch_flops = avg_flops / M

        part_a_flops = self._get_part_flops(batch_flops, 0)
        T_a = part_a_flops / self.uav_capacities[0]

        part_b_flops = self._get_part_flops(batch_flops, 1)
        T_b = part_b_flops / self.uav_capacities[1]

        data_size_mb = self._get_comm_data_size_mb() / M
        bandwidth_mb_s = self.bandwidth_mbps / 8
        T_comm = data_size_mb / bandwidth_mb_s + self.comm_radius * 0.5 / 3e8 + 0.002

        # Steady-state throughput: each bottleneck cycle completes one of a task's M batches
        # But a task requires all M batches to complete, so:
        # In steady state, 1/M of a task (one batch) completes per bottleneck period
        # But at full pipeline load, one task completes every M*bottleneck
        # In practice: once the pipeline is fully loaded, one batch emerges from the last stage per bottleneck period
        # A task's M batches emerge consecutively, so one task completes every M*bottleneck
        bottleneck = max(T_a, T_comm, T_b)
        # The time a task occupies the pipeline = M * bottleneck (in steady state)
        return 1.0 / (M * bottleneck)

    def run_simulation(self, task_flops_list: List[float],
                       task_arrival_interval: float) -> Dict:
        """
        Run the simulation

        Uses event-driven simulation: each task computes its pipeline latency,
        accounting for pipeline occupancy (the next task must wait while the previous task is not finished)
        """
        self.stats = {
            'tasks_generated': 0,
            'tasks_completed': 0,
            'total_latency': 0.0,
            'total_flops': 0.0,
        }

        # Pipeline availability time (until when the previous task occupies the pipeline)
        pipeline_free_at = 0.0

        for i, flops in enumerate(task_flops_list):
            arrival_time = i * task_arrival_interval
            if arrival_time > self.simulation_time:
                break

            self.stats['tasks_generated'] += 1
            self.stats['total_flops'] += flops

            # Compute this task's pipeline latency
            pipeline_latency = self._calculate_pipeline_latency(flops)

            # Task start time: max(arrival time, pipeline free time)
            start_time = max(arrival_time, pipeline_free_at)

            # Compute the pipeline occupancy time (time a task occupies in steady state)
            M = self.num_minibatches
            batch_flops = flops / M
            part_a_flops = self._get_part_flops(batch_flops, 0)
            T_a = part_a_flops / self.uav_capacities[0]
            part_b_flops = self._get_part_flops(batch_flops, 1)
            T_b = part_b_flops / self.uav_capacities[1]
            data_size_mb = self._get_comm_data_size_mb() / M
            bandwidth_mb_s = self.bandwidth_mbps / 8
            T_comm = data_size_mb / bandwidth_mb_s + self.comm_radius * 0.5 / 3e8 + 0.002
            bottleneck = max(T_a, T_comm, T_b)

            # Pipeline occupancy time = M * bottleneck (time for all batches to pass the bottleneck stage)
            pipeline_occupy_time = M * bottleneck

            # Update the pipeline free time
            pipeline_free_at = start_time + pipeline_occupy_time

            completion_time = start_time + pipeline_latency

            if completion_time <= self.simulation_time * 2:  # allow delayed completion
                self.stats['tasks_completed'] += 1
                # End-to-end latency (including queue waiting, aligned with the main environment)
                self.stats['total_latency'] += (completion_time - arrival_time)

        tc = max(1, self.stats['tasks_completed'])
        return {
            'tasks_generated': self.stats['tasks_generated'],
            'tasks_completed': self.stats['tasks_completed'],
            'completion_rate': self.stats['tasks_completed'] / max(1, self.stats['tasks_generated']),
            'avg_latency': self.stats['total_latency'] / tc,
            'task_throughput': self.stats['tasks_completed'] / self.simulation_time,
            'total_reward': 0.0,
            'avg_aoi': self.stats['total_latency'] / tc,
            'collab_rate': 1.0,
        }


def evaluate_epcta_pipeline(num_drones: int = 10,
                           comm_radius: float = 200.0,
                           network_layers: int = 8,
                           simulation_time: float = 40.0,
                           seed: int = 42,
                           task_rate_multiplier: float = 1.0,
                           override_num_tasks: int = None,
                           override_task_interval: float = None) -> Dict:
    """
    Evaluate EPCTA Pipeline performance

    Architecture: num_drones UAVs -> num_pipelines parallel 2-UAV pipelines
    Each pipeline uses minibatch pipeline parallelism internally (M=4)

    10 UAVs -> 5 pipelines, each with 2 UAVs
    On par with DDCI's 2-UAV collaboration mode

    Communication-range effect:
    - R <= 100m: UAVs in each pipeline are close, communication is fast
    - R >= 200m: fully connected, pipelines can be formed flexibly
    """
    # Each pipeline has a fixed 2 UAVs (on par with DDCI)
    num_pipelines = num_drones // 2

    # Heterogeneous compute capacity (consistent with the main environment)
    capacity_pool = [4e9, 4e9, 8e9, 8e9, 10e9, 15e9, 15e9, 15e9, 20e9, 20e9]

    # Allocate UAV capacities to each pipeline (round-robin)
    pipeline_capacities = []
    for p in range(num_pipelines):
        cap_a = capacity_pool[(p * 2) % len(capacity_pool)]
        cap_b = capacity_pool[(p * 2 + 1) % len(capacity_pool)]
        pipeline_capacities.append((cap_a, cap_b))

    # Partition point: even split (layer 4, first 4 layers to A, last 4 layers to B)
    cut_layer = network_layers // 2

    # Create multiple parallel pipelines
    pipelines = []
    for p in range(num_pipelines):
        env = MinibatchPipelineEnv(
            network_layers=network_layers,
            network_type='resnet-8',
            cut_layer=cut_layer,
            uav_capacities=pipeline_capacities[p],
            bandwidth_mbps=100.0,
            comm_radius=comm_radius,
            simulation_time=simulation_time,
            num_minibatches=4,
        )
        pipelines.append(env)

    # Determine the total number of tasks and the arrival interval
    if override_num_tasks is not None and override_task_interval is not None:
        num_tasks = override_num_tasks
        task_arrival_interval = override_task_interval
    else:
        # Compute the total throughput ceiling
        total_max_rate = sum(p._calculate_max_throughput() for p in pipelines)
        task_rate = total_max_rate * 0.8 * task_rate_multiplier
        num_tasks = int(simulation_time * task_rate)
        task_arrival_interval = 1.0 / task_rate if task_rate > 0 else 1.0

    # Generate tasks (matching the main environment's FLOPS distribution)
    # Main-environment task proportions: HIGH 10%, MEDIUM 80%, LOW 6%, BG 4%
    np.random.seed(seed)
    task_flops_list = []
    for _ in range(num_tasks):
        r = np.random.random()
        if r < 0.10:       # HIGH: 5M-500M
            flops = np.random.uniform(5e6, 5e8)
        elif r < 0.90:     # MEDIUM: 8G-20G (main tasks)
            flops = np.random.uniform(8e9, 20e9)
        elif r < 0.96:     # LOW: 100M-1G
            flops = np.random.uniform(1e8, 1e9)
        else:              # BG: 500K-50M
            flops = np.random.uniform(5e5, 5e7)
        task_flops_list.append(flops)

    # Distribute tasks to the pipelines in round-robin
    pipeline_tasks = [[] for _ in range(num_pipelines)]
    for i, flops in enumerate(task_flops_list):
        pipeline_tasks[i % num_pipelines].append(flops)

    # Task arrival interval per pipeline
    per_pipeline_interval = task_arrival_interval * num_pipelines

    # Run all pipelines in parallel
    all_completed = 0
    all_generated = 0
    all_latency = 0.0

    for p_idx, (env, tasks) in enumerate(zip(pipelines, pipeline_tasks)):
        if len(tasks) == 0:
            continue
        results = env.run_simulation(tasks, per_pipeline_interval)
        all_completed += results['tasks_completed']
        all_generated += results['tasks_generated']
        all_latency += results['avg_latency'] * results['tasks_completed']

    tc = max(1, all_completed)
    return {
        'tasks_generated': all_generated,
        'tasks_completed': all_completed,
        'completion_rate': all_completed / max(1, all_generated),
        'avg_latency': all_latency / tc,
        'task_throughput': all_completed / simulation_time,
        'total_reward': 0.0,
        'avg_aoi': all_latency / tc,
        'collab_rate': 1.0,
    }
