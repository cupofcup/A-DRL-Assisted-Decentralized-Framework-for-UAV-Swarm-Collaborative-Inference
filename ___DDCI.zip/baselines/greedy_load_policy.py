"""
Greedy-Load strategy: greedy load-balancing strategy

Selects the least-loaded neighbor for collaboration, using a fixed middle partition point
"""
import numpy as np


def greedy_load_strategy(obs):
    """
    Greedy load strategy: select the least-loaded neighbor

    Strategy logic:
    - Select the least-loaded neighbor
    - Use a fixed layer_cut=4 (middle partition point)

    Args:
        obs: observation vector (16-dim) [flops_norm, queue_load, busy_rate, priority, urgency, self_cap, battery,
                      d1,load1,cap1, d2,load2,cap2, d3,load3,cap3]

    Returns:
        action: integer action in the range 0-27
    """
    # Infer neighbor count K from obs length (self is 7-dim, each neighbor is [distance, load, compute])
    K = (len(obs) - 7) // 3
    neighbors = [
        {'dist': obs[7 + i*3], 'load': obs[7 + i*3 + 1], 'cap': obs[7 + i*3 + 2]}
        for i in range(K)
    ]

    # Select the least-loaded neighbor (core heuristic of greedy load balancing)
    partner_idx = int(np.argmin([n['load'] for n in neighbors]))

    # Partition point: based on the self/partner effective-compute ratio, mapped to the feasible partition range [4,8] (deep layers have small features, avoiding the communication blowup of large shallow-layer features)
    # Same starting line as DDCI: the baseline can also pick a physically feasible partition point, so the difference lies only in decision intelligence rather than being stuck at a bad partition point
    self_eff = obs[5] * (1 - obs[2])
    p_eff = neighbors[partner_idx]['cap'] * (1 - neighbors[partner_idx]['load'])
    self_ratio = self_eff / (self_eff + p_eff + 1e-8)
    layer_cut = int(np.clip(round(4 + self_ratio * 4), 4, 8))

    return partner_idx * 9 + layer_cut
