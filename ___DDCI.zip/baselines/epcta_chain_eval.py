"""
Evaluation entry point for the faithful chain version of EPCTA

Evaluates the faithful chain EPCTA (two 5-UAV chains, Layer-Avg / Cal-Avg allocation) on
**exactly the same task stream** as DDCI, and outputs metrics using the same conventions as
___v3/evidence/eval_full_metrics.py, for inclusion in the main table.

Fairness guarantees:
- Uses the same DynamicTopologyEnv + same seed to generate the task stream (same flops=total_flops*M,
  same priority proportions 8/64/5/8, same Poisson rate, same deadline derivation), advancing the
  simulation step by step and intercepting the tasks generated each step to replay them into the
  chain pipeline.
- Same heterogeneous compute tiers, same channel model (SignalAttenuationModel), same energy model,
  same 30 episodes / same seed sequence.
- The only difference = collaboration paradigm: chain N=5 multi-hop pipeline vs DDCI pairwise single-hop.

Metric convention: deadline_sat_all denominator = all arriving tasks; failure/drop reported separately.

Usage:
    python -m baselines.epcta_chain_eval --network vgg-16 --bandwidth 400 --split cal_avg
    python -m baselines.epcta_chain_eval --network vgg-16 --bandwidth 400 --split layer_avg
"""
import sys, os, json, argparse
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import numpy as np
from config import ConfigManager
from experiments.bandwidth_adaptive_training.dynamic_topology_env import DynamicTopologyEnv
from baselines.epcta_chain_pipeline import ChainPipeline, layer_avg_split, cal_avg_split

# Consistent with eval_full_metrics.py
N_EP = 30
SEED0 = 30000
W = {'HIGH': 4, 'MEDIUM': 2, 'LOW': 1, 'BACKGROUND': 0.5}

# Main-environment heterogeneous compute tiers (drone_collaboration_env.py:402, exactly the same as DDCI)
CAPACITY_LEVELS = [160e9, 160e9, 320e9, 320e9, 400e9, 600e9, 600e9, 600e9, 800e9, 800e9]


def build_chains(num_drones=10, n_per_chain=5, positions=None):
    """Split num_drones UAVs into several n_per_chain-UAV chains.

    Fairness fix: **greedily form chains by geographic proximity**, so that adjacent stages within
    a chain are physically close -> high bandwidth -> reasonable communication overhead (a real
    pipeline deployment keeps chain members adjacent, rather than forcing them together by compute
    which would make a chain span the entire region).
    Degenerate case (no positions): fall back to snake allocation by compute.

    n_per_chain is tunable: shorter chains -> more parallel pipelines -> closer to DDCI's parallelism
    (mitigating the throughput disadvantage of 2 chains absorbing 10 sources). Members within a chain
    are ordered by nearest-neighbor chaining.

    Returns: [[drone_idx...], ...].
    """
    n_chains = num_drones // n_per_chain
    if positions is None:
        # Fallback: snake by compute (old behavior)
        order = sorted(range(num_drones), key=lambda i: -CAPACITY_LEVELS[i])
        chains = [[] for _ in range(n_chains)]
        for rank, idx in enumerate(order):
            c = rank % n_chains
            if (rank // n_chains) % 2 == 1:
                c = n_chains - 1 - c
            chains[c].append(idx)
        for c in range(n_chains):
            chains[c].sort(key=lambda i: CAPACITY_LEVELS[i])
        return chains

    # Geographic-proximity greedy chaining: repeatedly take an unassigned UAV as the chain head, each time appending the nearest unassigned UAV
    pos = {i: np.array(positions[i]) for i in range(num_drones)}
    unassigned = set(range(num_drones))
    chains = []
    while unassigned:
        # Chain head: take the unassigned point farthest from the overall centroid (tends to start chains from the edge, reducing cross-region spans)
        centroid = np.mean([pos[i] for i in unassigned], axis=0)
        head = max(unassigned, key=lambda i: np.linalg.norm(pos[i] - centroid))
        chain = [head]; unassigned.discard(head)
        while len(chain) < n_per_chain and unassigned:
            last = chain[-1]
            nxt = min(unassigned, key=lambda i: np.linalg.norm(pos[i] - pos[last]))
            chain.append(nxt); unassigned.discard(nxt)
        chains.append(chain)
    return chains


def collect_task_stream(net, seed, sim_time=40.0, task_rate_multiplier=1.0):
    """Drive DynamicTopologyEnv to generate exactly the same task stream as DDCI.

    Using action=27 (all-local) to advance step by step only triggers _generate_tasks and current_time;
    each step intercepts the **newly added** tasks in each UAV's queue, recording
    (arrival_time, origin_drone_idx, flops, priority, deadline).

    task_rate_multiplier: task arrival rate multiplier (for load sweeps; 1.0 = same load as the DDCI main table).
    """
    env = DynamicTopologyEnv(config_manager=ConfigManager(), num_drones=10, k_neighbors=3,
                             network_type=net, simulation_time=sim_time, enable_mobility=True,
                             move_every_n_steps=15, move_distance=50.0, move_probability=0.9,
                             task_rate_multiplier=task_rate_multiplier)
    obs, _ = env.reset(seed=seed)

    seen = set()
    tasks = []

    def scan():
        for did, q in env.task_queues.items():
            didx = int(did.split('_')[1])
            for p in q.priority_queues:
                for e in q.priority_queues[p]:
                    if not hasattr(e, 'task'):
                        continue
                    tk = e.task
                    if tk.id in seen:
                        continue
                    seen.add(tk.id)
                    tasks.append({
                        'arrival': tk.arrival_time,
                        'origin': didx,
                        'flops': tk.flops,
                        'priority': tk.priority.name,
                        'deadline': tk.deadline,
                    })

    scan()  # one round already generated at reset
    done = False
    while not done:
        obs, r, t, tr, info = env.step(27)
        scan()
        done = t or tr
    # Positions (use final positions as the reference for intra-chain distance; initial positions also work)
    positions = {}
    for did in env.task_queues.keys():
        st = env.spatial_manager.get_drone_state(did)
        positions[int(did.split('_')[1])] = st.position if st else (0.0, 0.0)
    return tasks, positions, env.total_flops


def eval_one_episode(net, seed, split, bandwidth_mbps, task_rate_multiplier=1.0,
                     n_per_chain=5, allow_local_fallback=True):
    """Run chain EPCTA on one episode's task stream and return metrics.

    Fairness fixes:
    - Form chains by geographic proximity (build_chains with positions).
    - n_per_chain is tunable (shorter chains -> more parallel pipelines, mitigating the throughput disadvantage).
    - allow_local_fallback: if a small task can meet its deadline locally at the originator, process it
      directly on-device (not through the chain), matching DDCI's "action=27 local" option. The original
      chain version has no such adaptivity, but it is granted the same capability here for a fair comparison.
    """
    tasks, positions, total_flops = collect_task_stream(net, seed, task_rate_multiplier=task_rate_multiplier)
    chains = build_chains(10, n_per_chain, positions=positions)

    # Per-chain UAV compute and adjacent-stage distances
    chain_infos = []
    for chain in chains:
        caps = [CAPACITY_LEVELS[i] for i in chain]
        dists = []
        for k in range(len(chain) - 1):
            p1 = np.array(positions[chain[k]]); p2 = np.array(positions[chain[k + 1]])
            d = float(np.linalg.norm(p1 - p2))
            dists.append(min(max(d, 1.0), 200.0))  # clamp to [1m, R_comm]
        chain_infos.append({'members': chain, 'caps': caps, 'dists': dists})

    # Which chain each origin drone belongs to
    drone2chain = {}
    for ci, info in enumerate(chain_infos):
        for m in info['members']:
            drone2chain[m] = ci

    # Partitioner layer data (network is the same across each episode, build once)
    from models.configurable_partitioner import create_partitioner
    part = create_partitioner(net)
    minfo = part.get_model_info()
    layer_flops = [s.flops for s in minfo['layer_specs']]
    layer_data_mb = [s.data_size_bytes / (1024 * 1024) for s in minfo['layer_specs']]
    num_layers = minfo['num_layers']

    # Allocation scheme for each chain (fixed strategy, does not vary per task -- the faithful original allocation is a static layer allocation)
    chain_seg = []
    for info in chain_infos:
        n = len(info['members'])
        if split == 'layer_avg':
            seg = layer_avg_split(num_layers, n)
        else:
            seg = cal_avg_split(num_layers, n, info['caps'])
        chain_seg.append(seg)

    # Chain pipeline occupancy modeling (consistent with epcta_pipeline_env: a chain is a shared resource with occupancy/queuing)
    pipelines = {ci: ChainPipeline(layer_flops, layer_data_mb, bandwidth_mbps, num_micro=8)
                 for ci in range(len(chain_infos))}
    chain_free_at = {ci: 0.0 for ci in range(len(chain_infos))}

    # Statistics (convention: denominator = all arriving tasks; both timeouts and drops count as unmet)
    met = 0
    total = 0
    prio_tot = {p: 0 for p in W}; prio_met = {p: 0 for p in W}
    energy_sum = 0.0
    lat_list = []           # end-to-end latency (including queuing)
    pure_lat_list = []      # pure processing latency (no queuing, reflects the paradigm's own efficiency, not contaminated by the 2-chain throughput bottleneck)
    dropped = 0
    completed = 0
    local_done = 0
    SIM_TIME = 40.0
    # Local-processor free time for each source UAV (local fallback occupies the originator's own compute, 10 parallel processors)
    drone_free_at = {i: 0.0 for i in range(10)}
    energy_model = pipelines[0].energy_model

    # Queue cap: drop the oldest task when a single chain's backlog gets too deep (aligns with DDCI drop semantics, avoiding unbounded queuing)
    # In DDCI, pending tasks past their deadline are dropped by _cleanup_expired_pending_tasks.
    for tk in sorted(tasks, key=lambda x: x['arrival']):
        ci = drone2chain[tk['origin']]
        info = chain_infos[ci]
        seg = chain_seg[ci]
        M = max(1, round(tk['flops'] / max(total_flops, 1)))
        cp = pipelines[ci]
        cp.num_micro = M  # number of micro-batches = number of images (consistent with DDCI)

        pn = tk['priority']
        total += 1
        prio_tot[pn] += 1

        # === Local fallback (fairness): if a small task can complete on time locally at the originator, do not use the chain ===
        # Matches DDCI's action=27 local option; processes independently with the originator's own compute (does not occupy the chain).
        origin = tk['origin']
        origin_cap = CAPACITY_LEVELS[origin]
        t_local = tk['flops'] / origin_cap
        if allow_local_fallback:
            lstart = max(tk['arrival'], drone_free_at[origin])
            lcompletion = lstart + t_local
            if lcompletion <= tk['deadline']:
                # Can be satisfied locally -> process locally
                drone_free_at[origin] = lstart + t_local
                pure_lat_list.append(t_local)
                lat_list.append(lcompletion - tk['arrival'])
                energy_sum += energy_model.calculate_compute_energy(tk['flops'], origin_cap / 1e9)
                completed += 1; local_done += 1
                met += 1; prio_met[pn] += 1
                continue

        # Pure processing latency (no queuing): each task's end-to-end pipeline latency on an idle chain -- reflects the paradigm's own efficiency,
        # comparable to the DDCI main table's lat_p50 (per-collaboration batch processing latency, also excluding queue waiting).
        lat, energy, occupy = cp.compute(tk['flops'], seg, info['caps'], info['dists'])
        pure_lat_list.append(lat)
        energy_sum += energy

        # Chain occupancy queuing: a task must wait for the previous task to free the pipeline
        start = max(tk['arrival'], chain_free_at[ci])
        # If already past the deadline when processing would start -> drop (does not occupy the pipeline, counts as unmet)
        if start > tk['deadline']:
            dropped += 1
            continue

        chain_free_at[ci] = start + occupy  # steady-state occupancy (not full end-to-end latency)
        completion = start + lat
        end_to_end = completion - tk['arrival']
        lat_list.append(end_to_end)
        completed += 1

        if completion <= tk['deadline']:
            met += 1
            prio_met[pn] += 1

    deadline_sat_all = met / max(1, total) * 100
    drop_rate = dropped / max(1, total) * 100
    rates = {p: (prio_met[p] / prio_tot[p] * 100 if prio_tot[p] else 0) for p in W}
    gamma = sum(W[p] * rates[p] for p in W) / sum(W.values())
    return {
        'deadline': deadline_sat_all,
        'high': rates['HIGH'],
        'gamma': gamma,
        'energy': energy_sum,
        'drop': drop_rate,
        'throughput': completed / SIM_TIME,   # completed-task throughput (tasks/s)
        'local_frac': local_done / max(1, total) * 100,  # local-fallback fraction
        'lat_samples': lat_list,
        'pure_lat_samples': pure_lat_list,     # pure processing latency (excluding queuing), a neutral absolute performance metric
    }


def evaluate_epcta_chain(net='vgg-16', bandwidth_mbps=400.0, split='cal_avg', n_ep=N_EP,
                         task_rate_multiplier=1.0, n_per_chain=5, allow_local_fallback=True):
    ep_deadline = []; ep_high = []; ep_gamma = []; ep_energy = []; ep_drop = []; ep_thru = []
    ep_local = []
    all_lat = []; all_pure_lat = []
    for ep in range(n_ep):
        r = eval_one_episode(net, SEED0 + ep, split, bandwidth_mbps, task_rate_multiplier,
                             n_per_chain=n_per_chain, allow_local_fallback=allow_local_fallback)
        ep_deadline.append(r['deadline'])
        ep_high.append(r['high'])
        ep_gamma.append(r['gamma'])
        ep_energy.append(r['energy'])
        ep_drop.append(r['drop'])
        ep_thru.append(r['throughput'])
        ep_local.append(r['local_frac'])
        all_lat.extend(r['lat_samples'])
        all_pure_lat.extend(r['pure_lat_samples'])
    return {
        'split': split,
        'task_rate_multiplier': task_rate_multiplier,
        'n_per_chain': n_per_chain,
        'allow_local_fallback': allow_local_fallback,
        'local_frac_mean': float(np.mean(ep_local)),
        'pure_lat_p50': float(np.median(all_pure_lat)) if all_pure_lat else 0,
        'pure_lat_p95': float(np.percentile(all_pure_lat, 95)) if all_pure_lat else 0,
        'throughput_mean': float(np.mean(ep_thru)),
        'lat_p50': float(np.median(all_lat)) if all_lat else 0,
        'lat_p95': float(np.percentile(all_lat, 95)) if all_lat else 0,
        'deadline_mean': float(np.mean(ep_deadline)), 'deadline_std': float(np.std(ep_deadline, ddof=1)),
        'high_mean': float(np.mean(ep_high)), 'high_std': float(np.std(ep_high, ddof=1)),
        'gamma_mean': float(np.mean(ep_gamma)), 'gamma_std': float(np.std(ep_gamma, ddof=1)),
        'energy_mean': float(np.mean(ep_energy)), 'energy_std': float(np.std(ep_energy, ddof=1)),
        'drop_rate_mean': float(np.mean(ep_drop)),
        '_deadline_samples': ep_deadline, '_high_samples': ep_high,
        '_gamma_samples': ep_gamma, '_energy_samples': ep_energy,
    }


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--network', default='vgg-16')
    ap.add_argument('--bandwidth', type=float, default=400.0)
    ap.add_argument('--split', default='both', choices=['layer_avg', 'cal_avg', 'both'])
    ap.add_argument('--n_ep', type=int, default=N_EP)
    ap.add_argument('--load_sweep', default=None,
                    help='comma-separated task-rate multipliers (e.g. 0.2,0.4,0.6,0.8,1.0), to show the chain performance gradient across load')
    ap.add_argument('--n_per_chain', type=int, default=5, help='number of UAVs per chain (shorter chains -> more parallel pipelines)')
    ap.add_argument('--no_local_fallback', action='store_true', help='disable local fallback (pure original chain)')
    ap.add_argument('--out', default='___v3/evidence/epcta_chain_results.json')
    args = ap.parse_args()

    splits = ['layer_avg', 'cal_avg'] if args.split == 'both' else [args.split]
    rates = [float(x) for x in args.load_sweep.split(',')] if args.load_sweep else [1.0]
    fallback = not args.no_local_fallback
    out = {}
    for sp in splits:
        for rate in rates:
            res = evaluate_epcta_chain(args.network, args.bandwidth, sp, args.n_ep, rate,
                                       n_per_chain=args.n_per_chain, allow_local_fallback=fallback)
            key = f'epcta_chain_{sp}' if rate == 1.0 and not args.load_sweep else f'epcta_chain_{sp}_load{rate}'
            out[key] = res
            print(f"[{sp} L={args.n_per_chain} fb={fallback} load={rate}] "
                  f"deadline={res['deadline_mean']:.1f}% local={res['local_frac_mean']:.1f}% "
                  f"pure_lat50={res['pure_lat_p50']:.3f}s thru={res['throughput_mean']:.2f}/s "
                  f"drop={res['drop_rate_mean']:.1f}% gamma={res['gamma_mean']:.1f}%")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print('saved to', args.out)
