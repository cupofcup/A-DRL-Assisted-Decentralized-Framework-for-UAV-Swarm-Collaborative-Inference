"""
EPCTA (Efficient Pipeline Collaborative DNN Inference) evaluation module

Based on paper: Efficient Pipeline Collaborative DNN Inference in
Resource-Constrained UAV Swarm (ren2024pipeline, WCNC 2024)

Core features:
1. N UAVs form a pipeline chain (N>=5)
2. The DNN model is split into N segments, each UAV processing one segment
3. Multiple tasks are processed in parallel at different pipeline stages simultaneously
4. Uses DRL (DQN) to optimize the layer-allocation strategy

Pipeline latency model (paper equations 2-5):
- T_{1,1} = t_{1,1}
- T_{1,n} = T_{1,n-1} + t_{1,n}
- T_{i,1} = max(T_{i-1,1}, (i-1)*td) + t_{i,1}
- T_{i,n} = max(T_{i-1,n}, T_{i,n-1}) + t_{i,n}
where t_{i,n} = t_{i,n,comp} + t_{i,n,trans}
"""
import numpy as np
from typing import List, Tuple
from models.configurable_partitioner import create_partitioner


class EPCTAEvaluator:
    """
    EPCTA evaluator

    Implements the latency computation of an N-UAV chain pipeline (paper equations 2-5)
    """

    def __init__(self,
                 num_uavs: int = 5,
                 network_type: str = 'resnet-8',
                 uav_capacities: List[float] = None,
                 bandwidth_mbps: float = 100.0,
                 comm_radius: float = 200.0):
        """
        Args:
            num_uavs: number of UAVs in the pipeline (>=5)
            network_type: network type
            uav_capacities: list of each UAV's compute capacity (FLOPS/s); None uses the heterogeneous defaults
            bandwidth_mbps: communication bandwidth (Mbps)
            comm_radius: communication range (meters), affecting inter-UAV distance and communication latency
        """
        self.num_uavs = max(5, num_uavs)
        self.network_type = network_type
        self.bandwidth_mbps = bandwidth_mbps
        self.comm_radius = comm_radius

        # Heterogeneous compute capacity (consistent with the main environment)
        capacity_pool = [4e9, 4e9, 8e9, 8e9, 10e9, 15e9, 15e9, 15e9, 20e9, 20e9]
        if uav_capacities is not None:
            self.uav_capacities = uav_capacities[:self.num_uavs]
        else:
            self.uav_capacities = [capacity_pool[i % len(capacity_pool)]
                                   for i in range(self.num_uavs)]

        # Create the model partitioner to obtain layer info
        self.partitioner = create_partitioner(network_type)
        model_info = self.partitioner.get_model_info()
        self.total_layers = model_info['num_layers']
        self.total_flops = model_info['total_flops']
        self.layer_specs = self.partitioner.layer_specs

        # Compute the even-split allocation: the layer range each UAV processes
        self.layer_allocation = self._compute_layer_allocation()

    def _compute_layer_allocation(self) -> List[Tuple[int, int]]:
        """
        Compute the even-split allocation: evenly divide total_layers among the N UAVs

        Returns:
            layer_ranges: [(start, end), ...] the layer range each UAV processes
        """
        base = self.total_layers // self.num_uavs
        remainder = self.total_layers % self.num_uavs

        ranges = []
        start = 0
        for i in range(self.num_uavs):
            count = base + (1 if i < remainder else 0)
            ranges.append((start, start + count))
            start += count
        return ranges

    def _get_stage_flops(self, stage_idx: int, task_flops: float) -> float:
        """Get the FLOPS of a given pipeline stage"""
        start, end = self.layer_allocation[stage_idx]
        num_layers = end - start
        return task_flops * (num_layers / self.total_layers)

    def _get_stage_data_size_mb(self, stage_idx: int) -> float:
        """Get the intermediate data size (MB) output by a given pipeline stage"""
        _, end = self.layer_allocation[stage_idx]
        if end >= self.total_layers:
            return 0.0  # the last stage does not need to transmit
        # Use the data size from the layer specs
        if end - 1 < len(self.layer_specs):
            return self.layer_specs[end - 1].data_size_bytes / (1024 * 1024)
        return 0.5  # default 0.5MB

    def evaluate_task_flow(self, task_flops_list: List[float],
                           task_arrival_interval: float = 0.1) -> List[float]:
        """
        Evaluate the pipeline latency of a series of tasks (paper equations 2-5)

        Args:
            task_flops_list: list of FLOPS for each task
            task_arrival_interval: task arrival interval (seconds)

        Returns:
            latencies: list of completion latencies for each task
        """
        num_tasks = len(task_flops_list)
        N = self.num_uavs

        # T[i][n] = completion time of task i on UAV n
        T = np.zeros((num_tasks, N))

        for i in range(num_tasks):
            task_flops = task_flops_list[i]

            for n in range(N):
                # Compute the processing time t_{i,n} of stage n
                stage_flops = self._get_stage_flops(n, task_flops)
                comp_time = stage_flops / self.uav_capacities[n]

                # Communication time (the last UAV does not need to transmit)
                if n < N - 1:
                    data_size_mb = self._get_stage_data_size_mb(n)
                    bandwidth_mb_s = self.bandwidth_mbps / 8
                    trans_time = data_size_mb / bandwidth_mb_s

                    # Communication-range effect: assume the inter-UAV chain distance is comm_radius * 0.6
                    # A larger communication range lets UAVs spread farther apart while staying connected
                    uav_distance = self.comm_radius * 0.6  # meters

                    # Propagation delay (speed of light 3e8 m/s)
                    propagation_delay = uav_distance / 3e8  # seconds

                    # Fixed processing overhead
                    processing_overhead = 0.002  # 2ms

                    # Total communication time
                    trans_time = trans_time + propagation_delay + processing_overhead
                else:
                    trans_time = 0.0

                t_in = comp_time + trans_time

                # Paper equations 2-5
                if i == 0 and n == 0:
                    # T_{1,1} = t_{1,1}
                    T[i][n] = t_in
                elif i == 0:
                    # T_{1,n} = T_{1,n-1} + t_{1,n}
                    T[i][n] = T[i][n - 1] + t_in
                elif n == 0:
                    # T_{i,1} = max(T_{i-1,1}, (i-1)*td) + t_{i,1}
                    arrival_time = i * task_arrival_interval
                    T[i][n] = max(T[i - 1][n], arrival_time) + t_in
                else:
                    # T_{i,n} = max(T_{i-1,n}, T_{i,n-1}) + t_{i,n}
                    T[i][n] = max(T[i - 1][n], T[i][n - 1]) + t_in

        # Latency of each task = completion time - arrival time
        latencies = []
        for i in range(num_tasks):
            arrival_time = i * task_arrival_interval
            latency = T[i][N - 1] - arrival_time
            latencies.append(latency)

        return latencies

    def evaluate_avg_latency(self, num_tasks: int = 200,
                             task_arrival_interval: float = 0.1,
                             task_flops_range: Tuple[float, float] = (8e9, 20e9)) -> float:
        """
        Evaluate the average latency

        Args:
            num_tasks: number of tasks
            task_arrival_interval: task arrival interval (seconds)
            task_flops_range: task FLOPS range

        Returns:
            avg_latency: average latency (seconds)
        """
        np.random.seed(42)
        task_flops_list = np.random.uniform(
            task_flops_range[0], task_flops_range[1], num_tasks
        ).tolist()

        latencies = self.evaluate_task_flow(task_flops_list, task_arrival_interval)
        return np.mean(latencies)


def epcta_evaluate(num_drones: int,
                   network_type: str = 'resnet-8',
                   bandwidth_mbps: float = 100.0,
                   comm_radius: float = 200.0,
                   task_rate_multiplier: float = 1.0,
                   num_tasks: int = 200) -> float:
    """
    EPCTA baseline evaluation (for sensitivity experiments)

    Args:
        num_drones: total number of UAVs in the system
        network_type: network type
        bandwidth_mbps: communication bandwidth
        comm_radius: communication range (meters)
        task_rate_multiplier: task arrival rate multiplier
        num_tasks: number of tasks to evaluate

    Returns:
        avg_latency: average latency (seconds)
    """
    # Communication-range effect: determines how many UAVs can participate in the pipeline
    # Based on actual deployment analysis (10 UAVs in a 400x400 region):
    # - R_comm < 200m: the network is partitioned, the largest connected component has only 5 UAVs
    # - R_comm >= 200m: fully connected, all 10 UAVs can be used
    if comm_radius < 200:
        # Small communication range, network partitioned, only 5 UAVs can form a pipeline
        num_pipeline_uavs = 5
    else:
        # Large communication range, fully connected, all UAVs can be used
        num_pipeline_uavs = max(5, num_drones)

    evaluator = EPCTAEvaluator(
        num_uavs=num_pipeline_uavs,
        network_type=network_type,
        bandwidth_mbps=bandwidth_mbps,
        comm_radius=comm_radius
    )

    # Base task arrival interval (matches the main environment)
    base_interval = 0.1  # 100ms
    task_interval = base_interval / task_rate_multiplier

    avg_latency = evaluator.evaluate_avg_latency(
        num_tasks=num_tasks,
        task_arrival_interval=task_interval,
        task_flops_range=(8e9, 20e9)
    )

    return avg_latency
