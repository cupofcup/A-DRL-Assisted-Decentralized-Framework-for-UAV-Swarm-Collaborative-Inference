"""
EPCTA faithful chain pipeline core

Based on paper: Efficient Pipeline Collaborative DNN Inference in Resource-Constrained
UAV Swarm (Ren et al., WCNC 2024).

The original paper's method = N UAVs form a linear chain, each UAV handles one pipeline stage;
the DNN's L layers are split by N-1 partition points into N segments of consecutive layers,
with segment n on UAV n. Tasks (minibatches) flow through the chain, overlapping computation
and communication.

This module provides the **faithful original** chain N-stage pipeline latency + energy
computation, as well as the paper's two documented heuristic layer-allocation strategies:
  - Layer-Avg: split layers as evenly as possible into N segments
  - Cal-Avg:   allocate layers proportionally to each UAV's compute

Unlike DDCI's pairwise (2-UAV) collaboration paradigm: the chain is a multi-hop (N-1 hop) pipeline.
This module reuses exactly the same underlying infrastructure as DDCI (real layer FLOPs / feature-map
data volumes, signal-attenuation channel model, energy model, heterogeneous compute tiers); only the
collaboration **topology** differs, to ensure a fair comparison.

Note: no DQN training (no learned decision). Faithfulness is embodied by "a real chain system model
+ the paper's documented allocation methods".
"""
import numpy as np
from typing import List, Tuple

from environment.signal_attenuation import SignalAttenuationModel
from environment.energy_model import DroneEnergyModel


# ----------------------------------------------------------------------------
# Layer-allocation strategies (paper-documented heuristics, pure functions, no training)
# ----------------------------------------------------------------------------

def layer_avg_split(num_layers: int, n_stages: int) -> List[int]:
    """Layer-Avg: split num_layers layers as evenly as possible into n_stages segments.

    The remainder goes to the leading segments (the first r segments each get 1 extra layer).
    Each segment has at least 1 layer (requires num_layers >= n_stages).

    Returns: a list of length n_stages, summing to num_layers.
    """
    if n_stages <= 0:
        raise ValueError("n_stages must be >= 1")
    if num_layers < n_stages:
        raise ValueError(f"num_layers({num_layers}) < n_stages({n_stages}), cannot give each segment >=1 layer")
    base = num_layers // n_stages
    rem = num_layers % n_stages
    seg = [base + (1 if i < rem else 0) for i in range(n_stages)]
    assert sum(seg) == num_layers
    return seg


def cal_avg_split(num_layers: int, n_stages: int, chain_caps: List[float]) -> List[int]:
    """Cal-Avg: allocate layers proportionally to each UAV's compute (stronger UAVs get more layers).

    seg[n] ~= round(num_layers * cap[n] / sum(cap)), corrected so that the sum = num_layers and each segment >= 1.

    Args:
        chain_caps: per-UAV compute of length n_stages (FLOPS or GFLOPS both fine, only the ratio is used).
    Returns: a list of length n_stages, summing to num_layers.
    """
    if len(chain_caps) != n_stages:
        raise ValueError("chain_caps length must equal n_stages")
    if num_layers < n_stages:
        raise ValueError(f"num_layers({num_layers}) < n_stages({n_stages}), cannot give each segment >=1 layer")

    total_cap = float(sum(chain_caps))
    # First round proportionally, with at least 1 layer per segment
    seg = [max(1, int(round(num_layers * c / total_cap))) for c in chain_caps]

    # Correct the total to = num_layers
    diff = num_layers - sum(seg)
    if diff > 0:
        # Too few layers: add one at a time to the segment with the highest current compute
        order = sorted(range(n_stages), key=lambda i: -chain_caps[i])
        j = 0
        while diff > 0:
            seg[order[j % n_stages]] += 1
            diff -= 1
            j += 1
    elif diff < 0:
        # Too many layers: remove one at a time from the lowest-compute segment with >1 layer
        order = sorted(range(n_stages), key=lambda i: chain_caps[i])
        j = 0
        guard = 0
        while diff < 0 and guard < 10000:
            idx = order[j % n_stages]
            if seg[idx] > 1:
                seg[idx] -= 1
                diff += 1
            j += 1
            guard += 1
    assert sum(seg) == num_layers, f"seg sum {sum(seg)} != {num_layers}"
    return seg


def split_boundaries(seg_layers: List[int]) -> List[int]:
    """Derive the partition-point boundaries (cumulative sums) from per-segment layer counts, used to index the intermediate-feature layer transmitted at each hop.

    seg_layers=[4,3,3,3,3] -> boundaries=[4,7,10,13] (the boundary layers of the N-1 hops).
    Boundary b means: the first b layers have been computed, and the feature from layer b's output is transmitted.
    """
    bnds = []
    acc = 0
    for s in seg_layers[:-1]:
        acc += s
        bnds.append(acc)
    return bnds


# ----------------------------------------------------------------------------
# Chain N-stage pipeline latency + energy
# ----------------------------------------------------------------------------

class ChainPipeline:
    """Faithful chain N-UAV pipeline (reuses DDCI's shared infrastructure).

    Each UAV = one pipeline stage; N-1 hops transmit intermediate features between adjacent stages.
    A minibatch (M micro-batches) flows through the (2N-1)-segment pipeline (N compute segments +
    N-1 communication segments), overlapping computation and communication. Steady-state latency =
    fill + (M-1)*bottleneck segment.
    """

    def __init__(self, layer_flops: List[float], layer_data_mb: List[float],
                 bandwidth_mbps: float = 400.0, num_micro: int = 8):
        self.layer_flops = list(layer_flops)
        self.layer_data_mb = list(layer_data_mb)
        self.num_layers = len(layer_flops)
        self.total_flops = float(sum(layer_flops))
        self.bandwidth_mbps = bandwidth_mbps
        self.num_micro = max(1, num_micro)
        # Channel model sharing the same source as UnifiedLatencyCalculator (5GHz 802.11ac)
        self.signal_model = SignalAttenuationModel(
            nominal_bandwidth_mbps=bandwidth_mbps, enable_realism=True
        )
        self.energy_model = DroneEnergyModel()

    def _seg_flops_frac(self, seg_layers: List[int]) -> List[float]:
        """FLOPs fraction of each segment's layers (real shared source: sum(layer_flops[a:b])/total)."""
        fracs = []
        a = 0
        for s in seg_layers:
            b = a + s
            fracs.append(sum(self.layer_flops[a:b]) / max(self.total_flops, 1e-9))
            a = b
        return fracs

    def _hop_data_mb(self, boundary: int) -> float:
        """Per-image intermediate-feature volume (MB) transmitted at a hop: the output of layer `boundary`.

        Consistent with UnifiedLatencyCalculator._layer_data_mb_at (the first `boundary` layers have
        been computed, transmitting layer `boundary`'s output -> index boundary-1).
        """
        idx = min(max(boundary, 1), len(self.layer_data_mb)) - 1
        return self.layer_data_mb[idx]

    def compute(self, task_flops: float, seg_layers: List[int],
                chain_caps_flops: List[float], chain_dists: List[float],
                contention_factor: float = 1.0) -> Tuple[float, float, float]:
        """Compute a task's end-to-end pipeline latency (s), total system energy (Wh), and pipeline occupancy time (s) on the chain.

        Args:
            task_flops: total task compute (= total_flops * M_images).
            seg_layers: layers per segment (length N, summing to num_layers).
            chain_caps_flops: per-UAV compute (FLOPS, e.g. 400e9).
            chain_dists: distances between adjacent stages (meters, length N-1).
            contention_factor: shared-channel contention factor (>=1), consistent with DDCI conventions.
        Returns:
            (latency_s, energy_wh, occupy_s)
            occupy_s = M * bottleneck segment: the time this task exclusively occupies the pipeline in
            steady state (subsequent tasks must queue), consistent with epcta_pipeline_env's
            pipeline_occupy_time convention.
        """
        n = len(seg_layers)
        assert len(chain_caps_flops) == n
        assert len(chain_dists) == n - 1
        M = self.num_micro

        fracs = self._seg_flops_frac(seg_layers)
        boundaries = split_boundaries(seg_layers)

        # --- Each compute segment: processing time of a single micro-batch ---
        t_stage = []
        for i in range(n):
            f_micro = task_flops * fracs[i] / M
            t_stage.append(f_micro / max(chain_caps_flops[i], 1e-9))

        # --- Each communication hop: transmission time of a single micro-batch (real bandwidth varies with distance/SINR) ---
        t_hop = []
        for k in range(n - 1):
            data_mb = self._hop_data_mb(boundaries[k])  # single-image feature
            eff_bw = self.signal_model.calculate_effective_bandwidth(chain_dists[k], 0.0)
            # Contention reduction (consistent with DDCI: 1/(1+(N-1)*rho), rho=0.5)
            rho = 0.5
            divisor = 1.0 + max(0.0, contention_factor - 1.0) * rho
            eff_bw = eff_bw / max(1.0, divisor)
            eff_bw_mb_s = max(eff_bw, 1e-3) / 8.0
            data_micro = data_mb  # single micro-batch = 1 image (aligned with the stage compute's /M: task_flops already includes M)
            trans = data_micro / eff_bw_mb_s
            prop = chain_dists[k] / 3e8
            t_hop.append(trans + prop + 0.002)

        # --- Pipeline: N compute segments + N-1 communication segments alternating ---
        pipeline_segs = []
        for i in range(n):
            pipeline_segs.append(t_stage[i])
            if i < n - 1:
                pipeline_segs.append(t_hop[i])

        fill = sum(pipeline_segs)                      # the first micro traverses the whole pipeline
        bottleneck = max(pipeline_segs)
        steady = (M - 1) * bottleneck                  # each subsequent micro per cycle = bottleneck segment
        latency = fill + steady
        occupy = M * bottleneck                        # steady-state occupancy (basis for subsequent-task queuing)

        # --- Energy: per-UAV compute + per-hop tx/rx ---
        energy_wh = 0.0
        for i in range(n):
            seg_flops = task_flops * fracs[i]
            cap_gflops = chain_caps_flops[i] / 1e9  # calculate_compute_energy uses the GFLOPS number
            energy_wh += self.energy_model.calculate_compute_energy(seg_flops, cap_gflops)
        for k in range(n - 1):
            data_mb = self._hop_data_mb(boundaries[k]) * M   # data volume of the whole batch
            comm = self.energy_model.calculate_comm_energy(
                data_mb, chain_dists[k], self.bandwidth_mbps
            )
            energy_wh += comm['tx_energy'] + comm['rx_energy']

        return latency, energy_wh, occupy
