"""
Multi-network DQN training script

Trains separate DQN models for different neural-network architectures:
- ResNet-8 (existing)
- VGG-13
- VGG-16
- GoogLeNet-22
"""

import os
import sys
import io
import argparse
from datetime import datetime

if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='ignore')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='ignore')

import numpy as np
import gymnasium as gym
from gymnasium import spaces

from stable_baselines3 import DQN
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.callbacks import CheckpointCallback, EvalCallback

from experiments.bandwidth_adaptive_training.dynamic_topology_env import DynamicTopologyEnv
from config import ConfigManager


class ActionSpaceWrapper(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        self.action_space = spaces.Discrete(28)

    def step(self, action):
        action = int(action)
        if action < 27:
            partner_idx = action // 9
            layer_cut = action % 9
        else:
            partner_idx = 3
            layer_cut = 0
        return self.env.step((partner_idx, layer_cut))

    def reset(self, **kwargs):
        return self.env.reset(**kwargs)


def create_environment(network_type, log_dir="./training_logs"):
    config_manager = ConfigManager()
    env = DynamicTopologyEnv(
        config_manager=config_manager,
        num_drones=10,
        k_neighbors=3,
        simulation_time=40.0,
        render_mode=None,
        enable_pipeline=True,
        enable_mobility=True,
        move_every_n_steps=50,
        move_distance=30.0,
        move_probability=0.8,
        network_type=network_type,
    )
    env = ActionSpaceWrapper(env)
    os.makedirs(log_dir, exist_ok=True)
    env = Monitor(env, filename=os.path.join(log_dir, "monitor.csv"))
    return env


def heuristic_policy_v4(obs):
    flops_norm = obs[0]
    queue_load = obs[1]
    self_busy = obs[2]
    deadline_urgency = obs[4]

    neighbor_capacities = obs[6:9]
    neighbor_loads = obs[9:12]

    if self_busy < 0.2 and queue_load < 0.2 and deadline_urgency < 0.3 and flops_norm < 0.3:
        return 27

    effective_caps = [neighbor_capacities[i] * (1 - neighbor_loads[i]) for i in range(3)]
    partner_idx = int(np.argmax(effective_caps))

    if flops_norm > 0.7:
        layer_cut = 6
    elif flops_norm > 0.4:
        layer_cut = 4
    else:
        layer_cut = 2

    return partner_idx * 9 + layer_cut


def pretrain_with_heuristic(env, steps=10000):
    print(f"\n[Pretrain] Collecting {steps} steps...")
    obs, _ = env.reset()
    episode_count = 0

    for step in range(steps):
        action = heuristic_policy_v4(obs)
        next_obs, reward, terminated, truncated, _ = env.step(action)
        obs = next_obs
        if terminated or truncated:
            episode_count += 1
            obs, _ = env.reset()

    print(f"[Pretrain] Done, {episode_count} episodes")


def train_dqn_for_network(network_type, total_timesteps=1_000_000, pretrain_steps=10_000):
    print("\n" + "=" * 70)
    print(f"  DQN Training for {network_type}")
    print("=" * 70)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_name = network_type.replace('-', '_')
    save_dir = f"./drl_training_results/dqn_{safe_name}_{timestamp}"
    os.makedirs(save_dir, exist_ok=True)

    train_env = create_environment(network_type, f"./training_logs/train_dqn_{safe_name}")
    eval_env = create_environment(network_type, f"./training_logs/eval_dqn_{safe_name}")

    if pretrain_steps > 0:
        pretrain_with_heuristic(train_env, pretrain_steps)
        train_env.reset()

    model = DQN(
        "MlpPolicy",
        train_env,
        learning_rate=5e-5,
        buffer_size=200_000,
        batch_size=128,
        learning_starts=1000,
        target_update_interval=2000,
        exploration_fraction=0.3,
        exploration_initial_eps=1.0,
        exploration_final_eps=0.02,
        gamma=0.99,
        policy_kwargs=dict(net_arch=[512, 512, 256]),
        tensorboard_log=os.path.join(save_dir, "tensorboard"),
        verbose=1,
        device='auto'
    )

    train_base_env = train_env.unwrapped
    train_base_env.set_shared_drl_model(model)
    eval_base_env = eval_env.unwrapped
    eval_base_env.set_shared_drl_model(model)

    eval_callback = EvalCallback(
        eval_env,
        best_model_save_path=save_dir,
        log_path=save_dir,
        eval_freq=20_000,
        n_eval_episodes=5,
        deterministic=True
    )
    checkpoint_callback = CheckpointCallback(
        save_freq=50_000,
        save_path=save_dir,
        name_prefix=f"dqn_{safe_name}"
    )

    print(f"\n[Training] {network_type}, {total_timesteps:,} steps")
    print(f"[Save] {save_dir}")

    model.learn(
        total_timesteps=total_timesteps,
        callback=[eval_callback, checkpoint_callback],
        progress_bar=True
    )

    final_path = os.path.join(save_dir, "final_model.zip")
    model.save(final_path)
    print(f"\n[Done] {network_type} -> {save_dir}")

    train_env.close()
    eval_env.close()
    return save_dir


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--network", type=str, default=None,
                        help="Network type: vgg-13, vgg-16, googlenet-22, or 'all'")
    parser.add_argument("--timesteps", type=int, default=1_000_000)
    parser.add_argument("--pretrain", type=int, default=10_000)
    args = parser.parse_args()

    if args.network == 'all':
        networks = ['vgg-13', 'vgg-16', 'googlenet-22']
    elif args.network:
        networks = [args.network]
    else:
        networks = ['vgg-13', 'vgg-16', 'googlenet-22']

    results = {}
    for net in networks:
        save_dir = train_dqn_for_network(net, args.timesteps, args.pretrain)
        results[net] = save_dir

    print("\n" + "=" * 70)
    print("  All Training Complete!")
    print("=" * 70)
    for net, path in results.items():
        print(f"  {net}: {path}")
