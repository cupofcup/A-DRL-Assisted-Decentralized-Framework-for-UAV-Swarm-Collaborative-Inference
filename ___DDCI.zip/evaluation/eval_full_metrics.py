"""
Full-metric evaluation across the DNN architectures used in the paper.

Reliability accounting: the deadline-satisfaction denominator is ALL arrived
tasks (met + deadline-violated + expired + failed); failed/expired tasks count
as misses. failure_rate (link failures) and drop_rate (deadline expiry) are
reported separately.

Baselines: DDCI vs Comm-Min, CoDNN, Greedy-Load, EPCTA (common-substrate
variant), Random, and Local (all-local execution).

Statistics: n=30 episodes with common test seeds (paired across methods);
every metric is reported as mean/std/CI95 with the Cliff's delta effect size;
paired Wilcoxon signed-rank test of DDCI vs each baseline with Holm correction.

Convention: every drone runs its own policy (set_shared_drl_model);
'local' = all-local. Latency uses the P50 (median) to avoid outlier pollution;
other metrics use the per-episode mean.

Usage:
    python evaluation/eval_full_metrics.py <vgg16_model> [vgg19_model] \
        [yolov5m_model] [googlenet22_model] [resnext101_model]
Each argument is the path (without .zip) to a trained DQN model for that
network; omitted networks are skipped.
"""
import numpy as np, json, sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from stable_baselines3 import DQN
from config import ConfigManager
from experiments.bandwidth_adaptive_training.dynamic_topology_env import DynamicTopologyEnv
from baselines.greedy_load_policy import greedy_load_strategy
from baselines.epcta_policy import epcta_strategy
from baselines.comm_min_policy import comm_min_strategy
from baselines.codnn_policy import codnn_strategy
from baselines.random_policy import random_strategy
from scipy import stats

# Model paths are passed on the command line (path without the .zip suffix).
NETS = {
    'vgg-16': sys.argv[1] if len(sys.argv) > 1 else None,
    'vgg-19': sys.argv[2] if len(sys.argv) > 2 else None,
    'yolov5m': sys.argv[3] if len(sys.argv) > 3 else None,
    'googlenet-22': sys.argv[4] if len(sys.argv) > 4 else None,
    'resnext-101': sys.argv[5] if len(sys.argv) > 5 else None,
}

N_EP = 30  # 30 episodes, matching the paper
SEED0 = 30000  # common test-seed base (all methods share seeds -> paired tests)
W = {'HIGH': 4, 'MEDIUM': 2, 'LOW': 1, 'BACKGROUND': 0.5}

class BW:
    def __init__(self, fn): self.fn = fn
    def predict(self, obs, deterministic=True): return self.fn(obs), None

class AllLocal:
    def predict(self, obs, deterministic=True): return 27, None

bl = {'comm_min': comm_min_strategy, 'greedy': greedy_load_strategy,
      'epcta': epcta_strategy, 'codnn': codnn_strategy, 'random': random_strategy}


def run_episodes(net, pol, model, n=N_EP):
    """Return the per-episode metric lists plus the list of all task
    processing latencies (used to compute P50).
    Satisfaction rate uses the strict denominator deadline_sat_all;
    failure_rate/drop_rate are additionally recorded."""
    ep_deadline = []; ep_energy = []; ep_gamma = []; ep_high = []
    ep_fail = []; ep_drop = []; ep_battery_viol = []  # battery-violation rate
    all_proc_lat = []       # processing + communication latency (excludes queueing) — legacy metric, kept for comparison
    all_e2e_lat = []        # end-to-end latency = completion_time - arrival_time (includes queueing wait)
    # unified channel: all four networks use 400Mbps (consistent with the channel model, train/eval matched)
    for ep in range(n):
        env = DynamicTopologyEnv(config_manager=ConfigManager(), num_drones=10, k_neighbors=3,
                                 network_type=net, simulation_time=40.0, enable_mobility=True,
                                 bandwidth_mbps=400.0,
                                 move_every_n_steps=15, move_distance=50.0, move_probability=0.9)
        if pol == 'ddci': env.set_shared_drl_model(model)
        elif pol == 'local': env.set_shared_drl_model(AllLocal())
        elif pol in bl: env.set_shared_drl_model(BW(bl[pol]))
        obs, _ = env.reset(seed=SEED0 + ep); done = False  # common seed
        while not done:
            if pol == 'local': a = 27
            elif pol == 'ddci': a = int(model.predict(obs, deterministic=True)[0])
            else: a = int(bl[pol](obs))
            obs, r, t, tr, info = env.step(a); done = t or tr
        s = env.episode_stats
        # strict denominator = met + violated + expired + failed (info is already computed with this convention)
        ep_deadline.append(info['deadline_sat_all'] * 100)
        ep_fail.append(info['failure_rate'] * 100)
        ep_drop.append(info['drop_rate'] * 100)
        ep_energy.append(s.get('total_energy', 0))
        ep_battery_viol.append(info.get('battery_violation_rate', 0.0) * 100)  # battery-depletion violation rate
        # per-priority satisfaction rate: denominator includes all arrived tasks of that priority (completed + expired + failed)
        # completed_tasks already includes link failures (strategy C) and normal completions; pending expired tasks must be added to the denominator from expired
        prio_tot = {p: 0 for p in W}; prio_met = {p: 0 for p in W}
        for did, q in env.task_queues.items():
            for e in q.completed_tasks:
                if hasattr(e, 'task') and getattr(e, 'completion_time', None):
                    pn = e.task.priority.name
                    if pn in W:
                        prio_tot[pn] += 1
                        if e.completion_time <= e.task.deadline:
                            prio_met[pn] += 1
                    # end-to-end latency = completion time - arrival time (includes queueing wait, reflects true response)
                    at = getattr(e.task, 'arrival_time', None)
                    if at is not None and e.completion_time is not None:
                        e2e = e.completion_time - at
                        if e2e >= 0:
                            all_e2e_lat.append(e2e)
                if hasattr(e, 'processing_info'):
                    pi = e.processing_info
                    all_proc_lat.append(pi.get('processing_time', 0) + pi.get('comm_time', 0))
            # tasks in the pending queue that expired unprocessed: count toward the corresponding priority denominator (not met)
            for p in q.priority_queues:
                for e in q.priority_queues[p]:
                    if hasattr(e, 'task') and env.current_time > e.task.deadline:
                        pn = e.task.priority.name
                        if pn in W: prio_tot[pn] += 1
        rates = {p: (prio_met[p] / prio_tot[p] * 100 if prio_tot[p] else 0) for p in W}
        gamma = sum(W[p] * rates[p] for p in W) / sum(W.values())
        ep_gamma.append(gamma)
        ep_high.append(rates['HIGH'])
    return {
        'lat_p50': float(np.median(all_proc_lat)) if all_proc_lat else 0,   # legacy: processing + communication (excludes queueing)
        'e2e_p50': float(np.median(all_e2e_lat)) if all_e2e_lat else 0,     # end-to-end P50 (includes queueing)
        'e2e_p95': float(np.percentile(all_e2e_lat, 95)) if all_e2e_lat else 0,
        'e2e_mean': float(np.mean(all_e2e_lat)) if all_e2e_lat else 0,
        'deadline_mean': float(np.mean(ep_deadline)), 'deadline_std': float(np.std(ep_deadline, ddof=1)),
        'gamma_mean': float(np.mean(ep_gamma)), 'gamma_std': float(np.std(ep_gamma, ddof=1)),
        'energy_mean': float(np.mean(ep_energy)), 'energy_std': float(np.std(ep_energy, ddof=1)),
        'high_mean': float(np.mean(ep_high)), 'high_std': float(np.std(ep_high, ddof=1)),
        'failure_rate_mean': float(np.mean(ep_fail)), 'drop_rate_mean': float(np.mean(ep_drop)),
        'battery_violation_rate_mean': float(np.mean(ep_battery_viol)),  # C14
        'battery_violation_rate_max': float(np.max(ep_battery_viol)),    # worst episode
        '_deadline_samples': ep_deadline, '_high_samples': ep_high,
        '_gamma_samples': ep_gamma, '_energy_samples': ep_energy,
    }


def ci95(a):
    a = np.asarray(a, float); m = a.mean(); sd = a.std(ddof=1)
    h = 1.96 * sd / np.sqrt(len(a))
    return round(float(m - h), 3), round(float(m + h), 3)


def cliffs_delta(a, b):
    """Effect size Cliff's delta in [-1,1]: P(a>b)-P(a<b). |delta|: 0.147 small / 0.33 medium / 0.474 large."""
    a = np.asarray(a, float); b = np.asarray(b, float)
    gt = sum((x > b).sum() for x in a); lt = sum((x < b).sum() for x in a)
    return round((gt - lt) / (len(a) * len(b)), 3)


def holm_correction(pairs):
    """Holm-Bonferroni multiple-comparison correction. pairs=[(name,p),...] -> {name: p_adj}."""
    ordered = sorted(pairs, key=lambda kv: kv[1])
    m = len(ordered); adj = {}
    prev = 0.0
    for i, (name, p) in enumerate(ordered):
        val = min(1.0, (m - i) * p)
        val = max(val, prev)  # ensure monotonic non-decreasing
        adj[name] = round(float(val), 5); prev = val
    return adj


results = {}
# safe merge: first load existing results, only update networks that have a model path this run, keep the rest (including the epcta_chain sub-key).
# (guards against a "single-network eval overwriting the other 4 networks" pitfall)
OUT = '___v3/evidence/full_metrics_results.json'
_existing = {}
if os.path.exists(OUT):
    try:
        _existing = json.load(open(OUT, encoding='utf-8'))
    except Exception:
        _existing = {}
methods = ['local', 'random', 'codnn', 'comm_min', 'greedy', 'epcta', 'ddci']
for net, mpath in NETS.items():
    if not mpath:
        print(f'SKIP {net} (no model path)'); continue
    M = DQN.load(mpath)
    results[net] = {}
    for pol in methods:
        results[net][pol] = run_episodes(net, pol, M if pol == 'ddci' else None, n=N_EP)

    # for all metrics: DDCI vs each baseline paired Wilcoxon + effect size + Holm correction
    ddci = results[net]['ddci']
    metric_samples = {'deadline': '_deadline_samples', 'high': '_high_samples',
                      'gamma': '_gamma_samples', 'energy': '_energy_samples'}
    stat_out = {}
    for met, skey in metric_samples.items():
        raw_p = []; eff = {}
        for pol in methods:
            if pol == 'ddci': continue
            a = np.asarray(ddci[skey], float); b = np.asarray(results[net][pol][skey], float)
            # lower energy is better, higher is better for the rest
            alt = 'less' if met == 'energy' else 'greater'
            try:
                _, p = stats.wilcoxon(a, b, alternative=alt, zero_method='zsplit')
            except Exception:
                p = 1.0
            raw_p.append((pol, float(p)))
            eff[pol] = cliffs_delta(a, b) if met != 'energy' else cliffs_delta(b, a)
        adj = holm_correction(raw_p)
        stat_out[met] = {'p_raw': {k: round(v, 5) for k, v in raw_p},
                         'p_holm': adj, 'cliffs_delta': eff,
                         'ci95': {pol: ci95(results[net][pol][skey]) for pol in methods}}
    results[net]['_stats'] = stat_out
    print(f'{net}: DDCI e2e_p50={ddci["e2e_p50"]:.3f}s (proc_p50={ddci["lat_p50"]:.3f}) '
          f'deadline={ddci["deadline_mean"]:.1f}% high={ddci["high_mean"]:.1f}% gamma={ddci["gamma_mean"]:.1f}% '
          f'fail={ddci["failure_rate_mean"]:.2f}% drop={ddci["drop_rate_mean"]:.2f}%')

# clean up the sample data before saving
for net in results:
    for pol in methods:
        if isinstance(results[net].get(pol), dict):
            for k in ['_deadline_samples', '_high_samples', '_gamma_samples', '_energy_samples']:
                results[net][pol].pop(k, None)

# merge: for networks evaluated this run, keep their existing sub-keys (such as epcta_chain) that this script does not produce
for net in results:
    old = _existing.get(net, {})
    for k, v in old.items():
        if k not in results[net]:
            results[net][k] = v
    _existing[net] = results[net]

with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(_existing, f, indent=2, ensure_ascii=False)
print('saved to', OUT, '| updated:', list(results.keys()), '| kept:',
      [n for n in _existing if n not in results])
