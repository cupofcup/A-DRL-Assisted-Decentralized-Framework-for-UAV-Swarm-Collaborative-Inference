"""
Unified latency calculation module

Ensures the training environment and the integrated system use the **exact same** latency formulas.
"""

import numpy as np
from typing import Tuple


class UnifiedLatencyCalculator:
    """
    Unified pipeline latency calculator

    Core principles:
    1. Fixed 4 mini-batches
    2. Pipeline parallelism modeling
    3. Accounts for communication and computation overlap
    """

    def __init__(self, bandwidth_mbps: float = 100.0, total_layers: int = 8,
                 enable_comm_realism: bool = True, layer_data_mb=None, layer_flops=None):
        self.total_layers = total_layers  # Total number of network layers (supports different architectures)
        self.default_processing_rate = 4e11  # 400 GFLOPS/s (median of the Jetson tier)
        self.bandwidth_mbps = bandwidth_mbps  # Nominal bandwidth (Mbps, ideal short-range conditions)
        # Real same-source data: per-layer output data size (MB) and per-layer FLOPs, passed in by env from the partitioner; falls back to a linear approximation when None
        self.layer_data_mb = layer_data_mb
        self.layer_flops = layer_flops
        # Adaptive batch size (dynamically adjusted by task size)
        self.adaptive_batch_size = False  # Temporarily disabled, falling back to a fixed batch of 4
        # Communication realism: use the signal attenuation model to compute effective bandwidth from distance + SINR + Doppler (module 2, R1.4)
        # Nominal bandwidth is the short-range upper bound, attenuated by distance/occlusion/interference/Doppler
        self.enable_comm_realism = enable_comm_realism
        # Deferred import to avoid a circular dependency (the environment package imports this module back during initialization)
        from environment.signal_attenuation import SignalAttenuationModel
        self.signal_model = SignalAttenuationModel(
            nominal_bandwidth_mbps=bandwidth_mbps,
            enable_realism=enable_comm_realism,
        )

    def calculate_collaborative_time(
        self,
        task_flops: float,
        cut_layer: int,
        distance: float,
        drone_capacity: float = None,
        partner_capacity: float = None,
        comm_calculator = None,
        relative_speed: float = 0.0,
        batch_images: int = 8,
        contention_factor: float = 1.0
    ) -> Tuple[float, float]:
        """
        Paradigm 1 (mini-batch pipeline layer partition): compute the processing and communication time of a collaborative task.

        The DNN is split at cut_layer: the first cut_layer layers run locally, the rest run on the partner.
        The batch is split into micro-batches flowing through three stages (local compute -> transmit intermediate features -> remote compute),
        with computation and communication overlapping. Steady-state total latency = fill time + (num micro - 1) x bottleneck stage.

        Args:
            task_flops: total task compute (FLOPs)
            cut_layer: partition point (1..L-1), first cut_layer layers run locally
            distance: distance (meters)
            drone_capacity/partner_capacity: local/partner compute capacity (FLOPS)
            relative_speed: relative speed (Doppler)
            batch_images: number of micro-batches (= number of images M)

        Returns:
            (processing_time, comm_time)
        """
        local_rate = drone_capacity or self.default_processing_rate
        remote_rate = partner_capacity or self.default_processing_rate
        n_micro = max(1, batch_images)

        # Local/remote FLOPs fraction (by layer partition)
        total_layers = self.total_layers
        # Use the real per-layer FLOPs fraction (if available), otherwise linear by layer count
        if self.layer_flops:
            local_flops_frac = sum(self.layer_flops[:cut_layer]) / max(sum(self.layer_flops), 1e-9)
        else:
            local_flops_frac = cut_layer / total_layers
        remote_flops_frac = 1.0 - local_flops_frac

        # Per-micro-batch time of each compute stage
        f_local_micro = task_flops * local_flops_frac / n_micro
        f_remote_micro = task_flops * remote_flops_frac / n_micro
        t_local_stage = f_local_micro / local_rate
        t_remote_stage = f_remote_micro / remote_rate

        # === Time-varying link within the batch. Recompute the communication stage per micro-batch as distance evolves over time, no longer using a single constant rate ===
        # Estimate batch duration using the contention-free communication stage (avoids the positive feedback where the contention factor inflates duration -> inflates distance)
        t_comm_base = self._calculate_communication_time(
            cut_layer, distance, comm_calculator, relative_speed, batch_m=1,
            contention_factor=1.0
        )
        bottleneck0 = max(t_local_stage, t_comm_base, t_remote_stage)
        est_batch_dur = (t_local_stage + t_comm_base + t_remote_stage) + (n_micro - 1) * bottleneck0
        # Distance evolution cap: within a batch, distance evolves at most up to the communication range (beyond that it is handled by the environment's link-outage mechanism, not represented as infinite latency)
        R_comm = getattr(self.signal_model, 'nominal_range_m', 200.0)
        # Approximate time at which each micro-batch communicates -> corresponding distance (bounded by the communication range)
        comm_stages = []
        for j in range(n_micro):
            frac = (j + 0.5) / n_micro
            d_j = distance + relative_speed * est_batch_dur * frac
            d_j = float(min(max(d_j, 1.0), R_comm))  # Clamp to [1m, R_comm]
            comm_stages.append(self._calculate_communication_time(
                cut_layer, d_j, comm_calculator, relative_speed, batch_m=1,
                contention_factor=contention_factor
            ))
        t_comm_stage_avg = sum(comm_stages) / len(comm_stages)  # Average communication stage within the batch (time-varying)

        # Pipeline: total latency = fill (first micro traverses all three stages) + Σ per-stage bottleneck of subsequent micros (time-varying communication stage)
        fill = t_local_stage + comm_stages[0] + t_remote_stage
        steady = 0.0
        for j in range(1, n_micro):
            steady += max(t_local_stage, comm_stages[j], t_remote_stage)
        t_total = fill + steady

        # Split the return so that processing_time + comm_time == t_total (env computes completion time as the sum of the two)
        comm_bottleneck_count = sum(
            1 for j in range(1, n_micro)
            if comm_stages[j] >= max(t_local_stage, t_remote_stage)
        )
        comm_in_total = comm_stages[0] + sum(
            comm_stages[j] for j in range(1, n_micro)
            if comm_stages[j] >= max(t_local_stage, t_remote_stage)
        )
        comm_in_total = min(comm_in_total, t_total)  # Does not exceed the total latency
        processing_time = t_total - comm_in_total
        return max(processing_time, 0.0), comm_in_total

    def _layer_data_mb_at(self, cut_layer: int) -> float:
        """Real per-image intermediate data size (MB) at the partition point.
        Prefers the real per-layer data passed in by env (partitioner data_size_bytes); otherwise falls back to a linear approximation.
        The cut_layer index means "the first cut_layer layers run locally"; the output of layer cut_layer is transmitted."""
        if self.layer_data_mb:
            if cut_layer <= 0:
                return self.layer_data_mb[0]            # Full offload: transmit the raw input (approximated by the first layer's output)
            idx = min(cut_layer, len(self.layer_data_mb)) - 1
            return self.layer_data_mb[idx]
        # Fallback: legacy linear approximation
        return 0.5 if cut_layer == 0 else cut_layer * 0.125

    def _calculate_communication_time(
        self,
        cut_layer: int,
        distance: float,
        comm_calculator = None,
        relative_speed: float = 0.0,
        batch_m: int = 1,
        contention_factor: float = 1.0,
    ) -> float:
        """
        Compute the per-batch communication time (module 2 realism: bandwidth varies with distance/SINR/Doppler, data size uses real layer output)

        Args:
            cut_layer: partition point (layer index)
            distance: distance (meters)
            comm_calculator: kept for compatibility (no longer used)
            relative_speed: relative speed of the sending/receiving UAVs (m/s), used for Doppler derating
            batch_m: number of images in this batch (per-image data size x batch_m)
            contention_factor: shared-channel contention factor (>=1). When N links share the half-duplex medium at the same time,
                               effective bandwidth is divided; pass the number of active links here, effective bandwidth is divided by this factor.

        Returns:
            t_comm_per_batch: per-batch communication time (seconds)
        """
        # Real intermediate data size (MB) = per-image layer output at this partition point x number of images in the batch
        data_size_per_batch = self._layer_data_mb_at(cut_layer) * max(batch_m, 1)

        # Effective bandwidth: computed by the signal model from distance + SINR (shadowing/interference/Doppler) (Mbps)
        eff_bw_mbps = self.signal_model.calculate_effective_bandwidth(distance, relative_speed)
        # Shared-channel contention. N concurrent links contend for the half-duplex medium, but under CSMA spatial reuse + capture effect
        # measured throughput degrades more slowly than a strict 1/N; use the 1/(1+(N-1)·ρ) model (ρ = contention intensity < 1, default 0.5).
        rho = getattr(self, 'contention_rho', 0.5)
        contention_divisor = 1.0 + max(0.0, contention_factor - 1.0) * rho
        eff_bw_mbps = eff_bw_mbps / max(1.0, contention_divisor)
        eff_bw_mb_per_s = max(eff_bw_mbps, 1e-3) / 8.0  # Mbps -> MB/s

        # Transmission time = data size / effective bandwidth (genuinely varies with communication conditions, no longer hard-clamped)
        transmission_time = data_size_per_batch / eff_bw_mb_per_s

        # Propagation delay (speed of light)
        propagation_delay = distance / 3e8

        # Fixed processing overhead (protocol stack, 2ms)
        processing_overhead = 0.002

        t_comm_per_batch = transmission_time + propagation_delay + processing_overhead
        return t_comm_per_batch

    def calculate_independent_time(
        self,
        task_flops: float,
        drone_capacity: float = None
    ) -> float:
        """
        Compute the independent processing time (no collaboration)

        Args:
            task_flops: total task FLOPS
            drone_capacity: processing capacity (FLOPS/s)

        Returns:
            processing_time: processing time (seconds)
        """
        processing_rate = drone_capacity or self.default_processing_rate
        return task_flops / processing_rate

    def calculate_non_pipeline_collaborative_time(
        self,
        task_flops: float,
        cut_layer: int,
        distance: float,
        drone_capacity: float = None,
        partner_capacity: float = None,
        comm_calculator = None,
        relative_speed: float = 0.0,
        contention_factor: float = 1.0,
        batch_images: int = 1
    ) -> Tuple[float, float]:
        """
        Compute the processing and communication time of a non-pipeline collaborative task (serial processing)

        Serial mode:
        1. Process the first cut_layer layers locally (full data)
        2. Transmit the intermediate result to the partner
        3. The partner processes the remaining layers

        Args:
            task_flops: total task FLOPS
            cut_layer: partition point (0-8)
            distance: inter-drone distance (meters)
            drone_capacity: local processing capacity (FLOPS/s)
            partner_capacity: partner processing capacity (FLOPS/s)
            comm_calculator: communication calculator (optional)

        Returns:
            (processing_time, comm_time): processing and communication time (seconds)
        """
        # Processing rates
        local_rate = drone_capacity or self.default_processing_rate
        remote_rate = partner_capacity or self.default_processing_rate

        # Local and remote layer counts
        local_layers = cut_layer
        remote_layers = self.total_layers - cut_layer

        # Local and remote FLOPS (full task, no batch split)
        local_flops = (local_layers / self.total_layers) * task_flops
        remote_flops = (remote_layers / self.total_layers) * task_flops

        # Serial processing time
        t_local = local_flops / local_rate
        t_remote = remote_flops / remote_rate

        # Communication time (transmit intermediate features)
        # Serial mode: after the first cut layers process the full batch (M images), the entire batch of intermediate features is transmitted at once.
        # Data size = per-image partition-point features x number of images M in the batch (same total as pipeline per-micro transmission,
        #   but serial has no compute-communication overlap -> the communication overhead is fully exposed on the critical path).
        data_size = self._layer_data_mb_at(cut_layer) * max(int(batch_images), 1)

        # Real effective bandwidth (varies with distance/SINR/Doppler, module 2)
        eff_bw_mbps = self.signal_model.calculate_effective_bandwidth(distance, relative_speed)
        # Shared-channel contention derating (consistent with the pipeline path: 1/(1+(N-1)·ρ))
        rho = getattr(self, 'contention_rho', 0.5)
        contention_divisor = 1.0 + max(0.0, contention_factor - 1.0) * rho
        eff_bw_mbps = eff_bw_mbps / max(1.0, contention_divisor)
        eff_bw_mb_per_s = max(eff_bw_mbps, 1e-3) / 8.0
        transmission_time = data_size / eff_bw_mb_per_s
        propagation_delay = distance / 3e8
        t_comm = transmission_time + propagation_delay + 0.002

        # Serial total time = local processing + communication + remote processing
        total_processing_time = t_local + t_remote
        total_comm_time = t_comm

        return total_processing_time, total_comm_time


# Create a global singleton
unified_calculator = UnifiedLatencyCalculator()
