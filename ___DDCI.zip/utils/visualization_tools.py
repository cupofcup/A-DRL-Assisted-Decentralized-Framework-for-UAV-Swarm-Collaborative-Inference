"""
Visualization and report generation tools.

Provides:
- Performance curve plotting
- Time-series analysis charts
- Comparison analysis reports
- Simulation result visualization
"""

import matplotlib.pyplot as plt
import matplotlib.style as mplstyle
import seaborn as sns
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
import json
from datetime import datetime
import os

from .performance_metrics import SystemMetrics, TaskLatencyRecord
from .statistical_tools import ArrivalProcessStats, QueueDynamicsStats

# Set CJK-capable font and style
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
sns.set_style("whitegrid")


class PerformanceVisualizer:
    """Performance visualization tools."""
    
    def __init__(self, output_dir: str = "./performance_plots"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
    def plot_throughput_timeline(self, throughput_data: List[Tuple[float, float]], 
                                title: str = "System Throughput Time Series") -> str:
        """Plot the throughput time-series chart."""
        if not throughput_data:
            return ""

        times, throughputs = zip(*throughput_data)

        plt.figure(figsize=(12, 6))
        plt.plot(times, throughputs, 'b-', linewidth=2, label='Real-time Throughput')
        plt.axhline(y=np.mean(throughputs), color='r', linestyle='--',
                   label=f'Average Throughput: {np.mean(throughputs):.2f}')

        plt.xlabel('Time (s)')
        plt.ylabel('Throughput (tasks/s)')
        plt.title(title)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        filename = os.path.join(self.output_dir, "throughput_timeline.png")
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.close()
        
        return filename
        
    def plot_latency_distribution(self, latency_records: List[TaskLatencyRecord],
                                 title: str = "Task Latency Distribution") -> str:
        """Plot the latency distribution chart."""
        if not latency_records:
            return ""

        # Group by priority
        priority_latencies = {}
        for record in latency_records:
            priority = record.priority.name
            if priority not in priority_latencies:
                priority_latencies[priority] = []
            priority_latencies[priority].append(record.total_latency)
            
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle(title, fontsize=16)
        
        colors = ['red', 'blue', 'green', 'orange']
        
        for idx, (priority, latencies) in enumerate(priority_latencies.items()):
            if idx >= 4:
                break
                
            ax = axes[idx // 2, idx % 2]
            
            # Histogram
            ax.hist(latencies, bins=30, alpha=0.7, color=colors[idx],
                   density=True, label=f'{priority} Priority')

            # Statistical lines
            mean_lat = np.mean(latencies)
            median_lat = np.median(latencies)

            ax.axvline(mean_lat, color='red', linestyle='--', label=f'Mean: {mean_lat:.3f}s')
            ax.axvline(median_lat, color='blue', linestyle='--', label=f'Median: {median_lat:.3f}s')

            ax.set_xlabel('Latency (s)')
            ax.set_ylabel('Density')
            ax.set_title(f'{priority} Priority Task Latency')
            ax.legend()
            ax.grid(True, alpha=0.3)
            
        plt.tight_layout()
        filename = os.path.join(self.output_dir, "latency_distribution.png")
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.close()
        
        return filename
        
    def plot_load_balance_heatmap(self, drone_loads: Dict[str, List[Tuple[float, float]]],
                                 title: str = "Drone Load Heatmap") -> str:
        """Plot the load-balance heatmap."""
        if not drone_loads:
            return ""

        # Prepare data
        drone_ids = list(drone_loads.keys())
        max_time_points = max(len(loads) for loads in drone_loads.values())

        # Create matrix
        load_matrix = np.zeros((len(drone_ids), max_time_points))
        time_points = []

        for i, drone_id in enumerate(drone_ids):
            loads = drone_loads[drone_id]
            for j, (time, load) in enumerate(loads):
                if j < max_time_points:
                    load_matrix[i, j] = load
                    if i == 0:  # Record time points only once
                        time_points.append(time)

        # Plot heatmap
        plt.figure(figsize=(14, 8))

        # Choose suitable time-point labels (avoid overcrowding)
        time_step = max(1, len(time_points) // 10)
        time_labels = [f"{t:.1f}" for t in time_points[::time_step]]

        sns.heatmap(load_matrix[:, ::time_step],
                   xticklabels=time_labels,
                   yticklabels=drone_ids,
                   cmap='YlOrRd',
                   cbar_kws={'label': 'Load Rate'})

        plt.xlabel('Time (s)')
        plt.ylabel('Drone ID')
        plt.title(title)
        plt.tight_layout()
        
        filename = os.path.join(self.output_dir, "load_balance_heatmap.png")
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.close()
        
        return filename
        
    def plot_collaboration_analysis(self, collab_data: Dict[str, List[float]],
                                  title: str = "Collaboration Efficiency Analysis") -> str:
        """Plot the collaboration efficiency analysis chart."""
        if not collab_data:
            return ""

        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle(title, fontsize=16)

        # Collaborative vs. independent processing time comparison
        if 'collaboration_times' in collab_data and 'independent_times' in collab_data:
            ax = axes[0, 0]

            collab_times = collab_data['collaboration_times']
            indep_times = collab_data['independent_times']

            ax.boxplot([collab_times, indep_times],
                      labels=['Collaborative', 'Independent'])
            ax.set_ylabel('Processing Time (s)')
            ax.set_title('Processing Time Comparison')
            ax.grid(True, alpha=0.3)

        # Collaboration success rate time series
        if 'success_rate_timeline' in collab_data:
            ax = axes[0, 1]
            times, rates = zip(*collab_data['success_rate_timeline'])

            ax.plot(times, rates, 'g-', linewidth=2)
            ax.set_xlabel('Time (s)')
            ax.set_ylabel('Collaboration Success Rate')
            ax.set_title('Collaboration Success Rate Over Time')
            ax.grid(True, alpha=0.3)

        # Communication overhead analysis
        if 'communication_overhead' in collab_data:
            ax = axes[1, 0]
            overhead_data = collab_data['communication_overhead']

            ax.hist(overhead_data, bins=20, alpha=0.7, color='orange')
            ax.axvline(np.mean(overhead_data), color='red', linestyle='--',
                      label=f'Average Overhead: {np.mean(overhead_data):.1%}')
            ax.set_xlabel('Communication Overhead Ratio')
            ax.set_ylabel('Frequency')
            ax.set_title('Communication Overhead Distribution')
            ax.legend()
            ax.grid(True, alpha=0.3)

        # Speedup analysis
        if 'speedup_ratios' in collab_data:
            ax = axes[1, 1]
            speedups = collab_data['speedup_ratios']

            ax.scatter(range(len(speedups)), speedups, alpha=0.6, c='blue')
            ax.axhline(y=1.0, color='red', linestyle='--', label='No-speedup Baseline')
            ax.axhline(y=np.mean(speedups), color='green', linestyle='--',
                      label=f'Average Speedup: {np.mean(speedups):.2f}x')
            ax.set_xlabel('Task Index')
            ax.set_ylabel('Speedup Ratio')
            ax.set_title('Collaboration Speedup')
            ax.legend()
            ax.grid(True, alpha=0.3)
            
        plt.tight_layout()
        filename = os.path.join(self.output_dir, "collaboration_analysis.png")
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.close()
        
        return filename


class TimeSeriesPlotter:
    """Time-series plotting tools."""
    
    def __init__(self, output_dir: str = "./timeseries_plots"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
    def plot_multi_metric_timeline(self, metrics_data: Dict[str, List[Tuple[float, float]]],
                                  title: str = "System Performance Time Series") -> str:
        """Plot the multi-metric time-series chart."""
        if not metrics_data:
            return ""
            
        fig, axes = plt.subplots(len(metrics_data), 1, figsize=(14, 4 * len(metrics_data)))
        if len(metrics_data) == 1:
            axes = [axes]
            
        fig.suptitle(title, fontsize=16)
        
        colors = ['blue', 'red', 'green', 'orange', 'purple', 'brown']
        
        for idx, (metric_name, data) in enumerate(metrics_data.items()):
            ax = axes[idx]
            times, values = zip(*data)
            
            ax.plot(times, values, color=colors[idx % len(colors)], 
                   linewidth=2, label=metric_name)
            
            # Add moving average line
            if len(values) > 10:
                window = min(10, len(values) // 5)
                moving_avg = pd.Series(values).rolling(window=window).mean()
                ax.plot(times, moving_avg, '--', color=colors[idx % len(colors)],
                       alpha=0.7, label=f'{metric_name} (Moving Average)')

            ax.set_xlabel('Time (s)')
            ax.set_ylabel(metric_name)
            ax.legend()
            ax.grid(True, alpha=0.3)
            
        plt.tight_layout()
        filename = os.path.join(self.output_dir, "multi_metric_timeline.png")
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.close()
        
        return filename
        
    def plot_performance_correlation(self, x_data: List[float], y_data: List[float],
                                   x_label: str, y_label: str,
                                   title: str = "Performance Metric Correlation Analysis") -> str:
        """Plot the performance-metric correlation scatter chart."""
        if len(x_data) != len(y_data) or not x_data:
            return ""

        plt.figure(figsize=(10, 8))

        # Scatter plot
        plt.scatter(x_data, y_data, alpha=0.6, s=50)

        # Fitted line
        z = np.polyfit(x_data, y_data, 1)
        p = np.poly1d(z)
        plt.plot(x_data, p(x_data), "r--", alpha=0.8,
                label=f'Fit Line: y={z[0]:.3f}x+{z[1]:.3f}')

        # Compute correlation coefficient
        correlation = np.corrcoef(x_data, y_data)[0, 1]

        plt.xlabel(x_label)
        plt.ylabel(y_label)
        plt.title(f"{title}\nCorrelation Coefficient: {correlation:.3f}")
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        filename = os.path.join(self.output_dir, "performance_correlation.png")
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.close()
        
        return filename


class ComparisonReporter:
    """Comparison analysis report generator."""
    
    def __init__(self, output_dir: str = "./comparison_reports"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
    def generate_performance_comparison(self, metrics_dict: Dict[str, SystemMetrics],
                                      report_title: str = "Performance Comparison Analysis Report") -> str:
        """Generate the performance comparison report."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(self.output_dir, f"performance_comparison_{timestamp}.html")
        
        html_content = self._create_html_report(metrics_dict, report_title)
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(html_content)
            
        return filename
        
    def _create_html_report(self, metrics_dict: Dict[str, SystemMetrics], title: str) -> str:
        """Create the HTML report."""
        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        body {{ font-family: Arial, 'Microsoft YaHei', sans-serif; margin: 20px; }}
        .header {{ background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px; }}
        .metric-table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        .metric-table th, .metric-table td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
        .metric-table th {{ background-color: #f2f2f2; }}
        .best-value {{ background-color: #d4edda; font-weight: bold; }}
        .worst-value {{ background-color: #f8d7da; }}
        .section {{ margin: 30px 0; }}
        .chart-container {{ text-align: center; margin: 20px 0; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>{title}</h1>
        <p>Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
    </div>
"""

        # Create comparison table
        html += self._create_comparison_table(metrics_dict)

        # Create detailed analysis
        html += self._create_detailed_analysis(metrics_dict)
        
        html += """
</body>
</html>
"""
        return html
        
    def _create_comparison_table(self, metrics_dict: Dict[str, SystemMetrics]) -> str:
        """Create the comparison table."""
        if not metrics_dict:
            return "<p>No performance data available</p>"

        # Define metrics and formats
        metrics_config = [
            ("simulation_time", "Simulation Time (s)", ".2f"),
            ("wall_clock_time", "Wall-clock Time (s)", ".2f"),
            ("time_efficiency", "Time Efficiency", ".2f"),
            ("system_throughput", "System Throughput (tasks/s)", ".3f"),
            ("weighted_throughput", "Weighted Throughput", ".3f"),
            ("average_latency", "Average Latency (s)", ".3f"),
            ("p95_latency", "P95 Latency (s)", ".3f"),
            ("completion_rate", "Completion Rate", ".1%"),
            ("weighted_completion_rate", "Weighted Completion Rate", ".1%"),
            ("load_balance_index", "Load Balance Index", ".3f"),
            ("collaboration_success_rate", "Collaboration Success Rate", ".1%"),
            ("collaboration_speedup", "Collaboration Speedup", ".2f")
        ]

        html = """
    <div class="section">
        <h2>Performance Metric Comparison</h2>
        <table class="metric-table">
            <tr>
                <th>Metric</th>
"""

        # Table header
        for config_name in metrics_dict.keys():
            html += f"                <th>{config_name}</th>\n"
        html += "            </tr>\n"

        # Table content
        for attr, display_name, fmt in metrics_config:
            html += f"            <tr>\n                <td><strong>{display_name}</strong></td>\n"

            values = []
            for config_name, metrics in metrics_dict.items():
                value = getattr(metrics, attr, 0)
                values.append(value)

            # Mark best and worst values
            if values:
                # For latency metrics, lower is better
                if 'latency' in attr.lower():
                    best_idx = np.argmin(values)
                    worst_idx = np.argmax(values)
                # For other metrics, higher is better
                else:
                    best_idx = np.argmax(values)
                    worst_idx = np.argmin(values)
                    
                for i, (config_name, value) in enumerate(zip(metrics_dict.keys(), values)):
                    css_class = ""
                    if i == best_idx:
                        css_class = "best-value"
                    elif i == worst_idx and len(values) > 2:
                        css_class = "worst-value"
                        
                    if fmt.endswith('%'):
                        formatted_value = f"{value:{fmt}}"
                    else:
                        formatted_value = f"{value:{fmt}}"
                        
                    html += f"                <td class=\"{css_class}\">{formatted_value}</td>\n"
                    
            html += "            </tr>\n"
            
        html += "        </table>\n    </div>\n"
        
        return html
        
    def _create_detailed_analysis(self, metrics_dict: Dict[str, SystemMetrics]) -> str:
        """Create the detailed analysis section."""
        html = """
    <div class="section">
        <h2>Detailed Analysis</h2>
"""

        # Performance ranking
        html += "        <h3>Performance Ranking</h3>\n"

        # Compute composite score
        scores = {}
        for config_name, metrics in metrics_dict.items():
            score = (
                metrics.system_throughput * 0.3 +
                metrics.weighted_completion_rate * 0.25 +
                (1.0 - metrics.average_latency / 10.0) * 0.25 +  # Assume 10s is the maximum acceptable latency
                metrics.load_balance_index * 0.1 +
                metrics.collaboration_success_rate * 0.1
            )
            scores[config_name] = max(0, score)

        # Sort
        ranked_configs = sorted(scores.items(), key=lambda x: x[1], reverse=True)

        html += "        <ol>\n"
        for i, (config_name, score) in enumerate(ranked_configs):
            html += f"            <li><strong>{config_name}</strong> - Composite Score: {score:.3f}</li>\n"
        html += "        </ol>\n"

        # Performance recommendations
        html += "        <h3>Performance Optimization Recommendations</h3>\n        <ul>\n"

        # Provide recommendations based on analysis
        if len(metrics_dict) > 1:
            best_config = ranked_configs[0][0]
            best_metrics = metrics_dict[best_config]

            html += f"            <li>Recommended configuration: <strong>{best_config}</strong></li>\n"

            if best_metrics.collaboration_speedup > 1.2:
                html += "            <li>Collaborative processing performs well; keep the current collaboration strategy</li>\n"
            elif best_metrics.collaboration_speedup < 0.9:
                html += "            <li>Collaborative processing efficiency is low; optimize the collaboration algorithm or reduce collaboration frequency</li>\n"

            if best_metrics.load_balance_index < 0.7:
                html += "            <li>Load is imbalanced; improve the task dispatch strategy</li>\n"

            if best_metrics.average_latency > 2.0:
                html += "            <li>Average latency is high; optimize the processing algorithm or increase processing capacity</li>\n"

        html += "        </ul>\n    </div>\n"
        
        return html
        
    def create_comparison_charts(self, metrics_dict: Dict[str, SystemMetrics]) -> List[str]:
        """Create the comparison charts."""
        chart_files = []

        if not metrics_dict:
            return chart_files

        # Radar chart of main performance metrics
        radar_chart = self._create_radar_chart(metrics_dict)
        if radar_chart:
            chart_files.append(radar_chart)

        # Throughput comparison bar chart
        throughput_chart = self._create_throughput_comparison(metrics_dict)
        if throughput_chart:
            chart_files.append(throughput_chart)
            
        return chart_files
        
    def _create_radar_chart(self, metrics_dict: Dict[str, SystemMetrics]) -> str:
        """Create the radar chart."""
        try:
            import matplotlib.pyplot as plt
            from math import pi

            # Define radar chart metrics
            categories = ['Throughput', 'Completion Rate', 'Latency Performance', 'Load Balance', 'Collaboration Efficiency']

            fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(projection='polar'))

            angles = [n / float(len(categories)) * 2 * pi for n in range(len(categories))]
            angles += angles[:1]  # Close the shape

            colors = ['red', 'blue', 'green', 'orange', 'purple']

            for i, (config_name, metrics) in enumerate(metrics_dict.items()):
                # Normalize metrics to 0-1
                values = [
                    min(1.0, metrics.system_throughput / 10.0),  # Assume 10 is the maximum
                    metrics.weighted_completion_rate,
                    max(0, 1.0 - metrics.average_latency / 5.0),  # Lower latency is better
                    metrics.load_balance_index,
                    metrics.collaboration_success_rate
                ]

                values += values[:1]  # Close the loop

                ax.plot(angles, values, 'o-', linewidth=2,
                       label=config_name, color=colors[i % len(colors)])
                ax.fill(angles, values, alpha=0.25, color=colors[i % len(colors)])

            ax.set_xticks(angles[:-1])
            ax.set_xticklabels(categories)
            ax.set_ylim(0, 1)
            plt.legend(loc='upper right', bbox_to_anchor=(0.1, 0.1))
            plt.title("Performance Radar Chart", size=20, y=1.1)

            filename = os.path.join(self.output_dir, "performance_radar.png")
            plt.savefig(filename, dpi=300, bbox_inches='tight')
            plt.close()

            return filename

        except Exception as e:
            print(f"Failed to create radar chart: {e}")
            return ""
            
    def _create_throughput_comparison(self, metrics_dict: Dict[str, SystemMetrics]) -> str:
        """Create the throughput comparison bar chart."""
        try:
            config_names = list(metrics_dict.keys())
            throughputs = [metrics.system_throughput for metrics in metrics_dict.values()]
            weighted_throughputs = [metrics.weighted_throughput for metrics in metrics_dict.values()]
            
            x = np.arange(len(config_names))
            width = 0.35
            
            fig, ax = plt.subplots(figsize=(12, 6))
            
            bars1 = ax.bar(x - width/2, throughputs, width, label='System Throughput', alpha=0.8)
            bars2 = ax.bar(x + width/2, weighted_throughputs, width, label='Weighted Throughput', alpha=0.8)

            ax.set_xlabel('Configuration')
            ax.set_ylabel('Throughput (tasks/s)')
            ax.set_title('System Throughput Comparison')
            ax.set_xticks(x)
            ax.set_xticklabels(config_names, rotation=45)
            ax.legend()
            ax.grid(True, alpha=0.3)

            # Add value labels
            for bar in bars1:
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height,
                       f'{height:.3f}', ha='center', va='bottom')
                       
            for bar in bars2:
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height,
                       f'{height:.3f}', ha='center', va='bottom')
            
            plt.tight_layout()
            filename = os.path.join(self.output_dir, "throughput_comparison.png")
            plt.savefig(filename, dpi=300, bbox_inches='tight')
            plt.close()
            
            return filename
            
        except Exception as e:
            print(f"Failed to create throughput comparison chart: {e}")
            return ""


if __name__ == "__main__":
    # Test the visualization tools
    print("Testing visualization tools...")

    visualizer = PerformanceVisualizer("./test_plots")

    # Simulate throughput data
    throughput_data = [(i * 0.5, np.random.uniform(1, 5)) for i in range(100)]

    # Plot the throughput time series
    plot_file = visualizer.plot_throughput_timeline(throughput_data)
    print(f"Throughput chart saved: {plot_file}")

    print("Visualization tool test complete!")