"""
Performance evaluation metrics computation module.

Implements the mathematical formulas in CLAUDE.md:
- System throughput: Θ(T) = (1/NT) * Σ|C_i(t)|
- Weighted completion rate: Γ(T) = Σw(p)completed / Σw(p)generated
- Mean response time: T̄_response = (1/|T_completed|) * Σ(t_complete - t_arrive)
- Load balance: LB = 1 - Var(loads) / mean(loads)
"""

import numpy as np
import time
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict, deque
import statistics
import math

from tasks import Task, TaskPriority


@dataclass
class SystemMetrics:
    """System performance metrics data structure."""
    # Time-related metrics
    simulation_time: float = 0.0
    wall_clock_time: float = 0.0  # Actual runtime
    time_efficiency: float = 0.0  # Time efficiency ratio

    # Throughput metrics
    system_throughput: float = 0.0  # tasks/second
    weighted_throughput: float = 0.0  # weighted tasks/second
    peak_throughput: float = 0.0

    # Latency metrics
    average_latency: float = 0.0  # seconds
    median_latency: float = 0.0
    p95_latency: float = 0.0
    p99_latency: float = 0.0

    # Completion rate metrics
    completion_rate: float = 0.0  # 0-1
    weighted_completion_rate: float = 0.0
    priority_completion_rates: Dict[int, float] = field(default_factory=dict)

    # Load balance metrics
    load_balance_index: float = 0.0  # 0-1
    load_variance: float = 0.0
    load_distribution: List[float] = field(default_factory=list)

    # Collaboration efficiency metrics
    collaboration_rate: float = 0.0
    collaboration_success_rate: float = 0.0
    collaboration_speedup: float = 1.0  # Collaboration speedup ratio

    # Resource utilization
    average_cpu_utilization: float = 0.0
    network_utilization: float = 0.0
    queue_utilization: float = 0.0


@dataclass
class TaskLatencyRecord:
    """Task latency record."""
    task_id: str
    priority: TaskPriority
    arrival_time: float
    start_time: float
    completion_time: float

    # Computed properties
    @property
    def total_latency(self) -> float:
        return self.completion_time - self.arrival_time
        
    @property  
    def queue_waiting_time(self) -> float:
        return self.start_time - self.arrival_time
        
    @property
    def processing_time(self) -> float:
        return self.completion_time - self.start_time


class TimeAnalyzer:
    """Time analyzer: dedicated to analyzing time-related performance metrics."""

    def __init__(self):
        self.start_wall_time = 0.0
        self.end_wall_time = 0.0
        self.simulation_start_time = 0.0
        self.simulation_end_time = 0.0

        # Time series data
        self.throughput_timeline = []  # (time, throughput) pairs
        self.latency_timeline = []     # (time, latency) pairs
        self.load_timeline = []        # (time, avg_load) pairs

    def start_timing(self):
        """Start timing."""
        self.start_wall_time = time.time()
        self.simulation_start_time = 0.0

    def end_timing(self, simulation_time: float):
        """End timing."""
        self.end_wall_time = time.time()
        self.simulation_end_time = simulation_time

    def calculate_time_efficiency(self) -> float:
        """Compute time efficiency: simulation time / actual runtime."""
        wall_duration = self.end_wall_time - self.start_wall_time
        if wall_duration == 0:
            return 0.0
        return self.simulation_end_time / wall_duration

    def add_throughput_point(self, sim_time: float, throughput: float):
        """Add a throughput time point."""
        self.throughput_timeline.append((sim_time, throughput))

    def add_latency_point(self, sim_time: float, latency: float):
        """Add a latency time point."""
        self.latency_timeline.append((sim_time, latency))

    def add_load_point(self, sim_time: float, avg_load: float):
        """Add a load time point."""
        self.load_timeline.append((sim_time, avg_load))

    def get_peak_throughput(self) -> Tuple[float, float]:
        """Get the peak throughput and its corresponding time."""
        if not self.throughput_timeline:
            return 0.0, 0.0

        peak_time, peak_throughput = max(self.throughput_timeline, key=lambda x: x[1])
        return peak_throughput, peak_time

    def get_average_throughput(self) -> float:
        """Compute the average throughput."""
        if not self.throughput_timeline:
            return 0.0
        return np.mean([tp for _, tp in self.throughput_timeline])

    def calculate_throughput_stability(self) -> float:
        """Compute throughput stability (inverse of the coefficient of variation)."""
        if not self.throughput_timeline or len(self.throughput_timeline) < 2:
            return 0.0

        throughputs = [tp for _, tp in self.throughput_timeline]
        mean_tp = np.mean(throughputs)
        std_tp = np.std(throughputs)

        if mean_tp == 0:
            return 0.0
        return 1.0 / (std_tp / mean_tp + 1e-8)  # Avoid division by zero


class TaskLatencyAnalyzer:
    """Task latency analyzer: detailed analysis of task latency metrics."""

    def __init__(self):
        self.latency_records: List[TaskLatencyRecord] = []
        self.priority_latencies: Dict[TaskPriority, List[float]] = defaultdict(list)

    def add_task_record(self, task_id: str, priority: TaskPriority,
                       arrival_time: float, start_time: float, completion_time: float):
        """Add a task latency record."""
        record = TaskLatencyRecord(
            task_id=task_id,
            priority=priority,
            arrival_time=arrival_time,
            start_time=start_time,
            completion_time=completion_time
        )
        
        self.latency_records.append(record)
        self.priority_latencies[priority].append(record.total_latency)
        
    def calculate_average_latency(self) -> float:
        """Compute the average latency."""
        if not self.latency_records:
            return 0.0
        return np.mean([r.total_latency for r in self.latency_records])

    def calculate_latency_percentiles(self) -> Dict[str, float]:
        """Compute latency percentiles."""
        if not self.latency_records:
            return {"p50": 0.0, "p95": 0.0, "p99": 0.0}
            
        latencies = [r.total_latency for r in self.latency_records]
        return {
            "p50": np.percentile(latencies, 50),
            "p95": np.percentile(latencies, 95), 
            "p99": np.percentile(latencies, 99)
        }
        
    def calculate_priority_latency_stats(self) -> Dict[TaskPriority, Dict[str, float]]:
        """Compute latency statistics per priority."""
        stats = {}
        
        for priority, latencies in self.priority_latencies.items():
            if not latencies:
                stats[priority] = {"mean": 0.0, "median": 0.0, "std": 0.0}
                continue
                
            stats[priority] = {
                "mean": np.mean(latencies),
                "median": np.median(latencies),
                "std": np.std(latencies),
                "min": np.min(latencies),
                "max": np.max(latencies)
            }
            
        return stats
        
    def calculate_queue_waiting_time_analysis(self) -> Dict[str, float]:
        """Analyze queue waiting time."""
        if not self.latency_records:
            return {"mean": 0.0, "median": 0.0, "ratio": 0.0}
            
        wait_times = [r.queue_waiting_time for r in self.latency_records]
        total_times = [r.total_latency for r in self.latency_records]
        
        return {
            "mean": np.mean(wait_times),
            "median": np.median(wait_times),
            "ratio": np.mean(wait_times) / np.mean(total_times) if np.mean(total_times) > 0 else 0.0
        }


class CollaborationAnalyzer:
    """Collaboration analyzer: analyzes collaboration performance and efficiency."""

    def __init__(self):
        self.collaboration_records = []
        self.independent_records = []

    def add_collaboration_record(self, task_id: str, processing_time: float,
                               communication_time: float, success: bool):
        """Add a collaborative processing record."""
        self.collaboration_records.append({
            "task_id": task_id,
            "processing_time": processing_time,
            "communication_time": communication_time, 
            "total_time": processing_time + communication_time,
            "success": success
        })
        
    def add_independent_record(self, task_id: str, processing_time: float):
        """Add an independent processing record."""
        self.independent_records.append({
            "task_id": task_id,
            "processing_time": processing_time,
            "total_time": processing_time
        })
        
    def calculate_collaboration_speedup(self) -> float:
        """Compute the collaboration speedup ratio."""
        if not self.collaboration_records or not self.independent_records:
            return 1.0
            
        collab_avg_time = np.mean([r["total_time"] for r in self.collaboration_records if r["success"]])
        indep_avg_time = np.mean([r["total_time"] for r in self.independent_records])
        
        if collab_avg_time == 0:
            return 1.0
        return indep_avg_time / collab_avg_time
        
    def calculate_collaboration_overhead(self) -> float:
        """Compute the collaboration communication overhead ratio."""
        if not self.collaboration_records:
            return 0.0
            
        total_processing = sum(r["processing_time"] for r in self.collaboration_records if r["success"])
        total_communication = sum(r["communication_time"] for r in self.collaboration_records if r["success"])
        
        if total_processing == 0:
            return 0.0
        return total_communication / (total_processing + total_communication)
        
    def calculate_collaboration_success_rate(self) -> float:
        """Compute the collaboration success rate."""
        if not self.collaboration_records:
            return 0.0
        return sum(1 for r in self.collaboration_records if r["success"]) / len(self.collaboration_records)


class PerformanceCalculator:
    """
    Main performance calculator class: integrates all performance metric computations.

    Implements a complete performance evaluation system based on the mathematical formulas in CLAUDE.md.
    """

    def __init__(self):
        self.time_analyzer = TimeAnalyzer()
        self.latency_analyzer = TaskLatencyAnalyzer()
        self.collaboration_analyzer = CollaborationAnalyzer()

        # Task statistics
        self.tasks_generated = 0
        self.tasks_completed = 0
        self.tasks_failed = 0

        # Per-priority statistics
        self.priority_stats = {
            TaskPriority.HIGH: {"generated": 0, "completed": 0, "failed": 0},
            TaskPriority.MEDIUM: {"generated": 0, "completed": 0, "failed": 0},
            TaskPriority.LOW: {"generated": 0, "completed": 0, "failed": 0},
            TaskPriority.BACKGROUND: {"generated": 0, "completed": 0, "failed": 0}
        }
        
        # Priority weights (based on CLAUDE.md)
        self.priority_weights = {
            TaskPriority.HIGH: 4.0,
            TaskPriority.MEDIUM: 2.0,
            TaskPriority.LOW: 1.0,
            TaskPriority.BACKGROUND: 0.5
        }
        
    def start_measurement(self):
        """Start performance measurement."""
        self.time_analyzer.start_timing()

    def end_measurement(self, simulation_time: float):
        """End performance measurement."""
        self.time_analyzer.end_timing(simulation_time)

    def record_task_generation(self, priority: TaskPriority, count: int = 1):
        """Record task generation."""
        self.tasks_generated += count
        self.priority_stats[priority]["generated"] += count

    def record_task_completion(self, task_id: str, priority: TaskPriority,
                              arrival_time: float, start_time: float,
                              completion_time: float, success: bool):
        """Record task completion."""
        if success:
            self.tasks_completed += 1
            self.priority_stats[priority]["completed"] += 1
            self.latency_analyzer.add_task_record(
                task_id, priority, arrival_time, start_time, completion_time
            )
        else:
            self.tasks_failed += 1
            self.priority_stats[priority]["failed"] += 1
            
    def record_collaboration(self, task_id: str, processing_time: float,
                           communication_time: float, success: bool):
        """Record collaborative processing."""
        self.collaboration_analyzer.add_collaboration_record(
            task_id, processing_time, communication_time, success
        )

    def record_independent_processing(self, task_id: str, processing_time: float):
        """Record independent processing."""
        self.collaboration_analyzer.add_independent_record(task_id, processing_time)
        
    def calculate_system_throughput(self, num_drones: int, simulation_time: float) -> float:
        """
        Compute system throughput: Θ(T) = (1/NT) * Σ|C_i(t)|

        Args:
            num_drones: number of drones N
            simulation_time: simulation time T

        Returns:
            System throughput (tasks/second)
        """
        if simulation_time == 0 or num_drones == 0:
            return 0.0
        return self.tasks_completed / (num_drones * simulation_time)
        
    def calculate_weighted_completion_rate(self) -> float:
        """
        Compute the weighted completion rate: Γ(T) = Σw(p)completed / Σw(p)generated
        """
        weighted_completed = sum(
            self.priority_weights[p] * stats["completed"] 
            for p, stats in self.priority_stats.items()
        )
        
        weighted_generated = sum(
            self.priority_weights[p] * stats["generated"]
            for p, stats in self.priority_stats.items()
        )
        
        if weighted_generated == 0:
            return 0.0
        return weighted_completed / weighted_generated
        
    def calculate_load_balance_index(self, drone_loads: List[float]) -> float:
        """
        Compute load balance: LB = 1 - Var(loads) / mean(loads)

        Args:
            drone_loads: list of per-drone loads

        Returns:
            Load balance index (0-1, 1 means perfectly balanced)
        """
        if not drone_loads or len(drone_loads) < 2:
            return 1.0
            
        mean_load = np.mean(drone_loads)
        if mean_load == 0:
            return 1.0
            
        load_variance = np.var(drone_loads)
        return max(0.0, 1.0 - load_variance / mean_load)
        
    def calculate_comprehensive_metrics(self, num_drones: int, 
                                      simulation_time: float,
                                      drone_loads: List[float]) -> SystemMetrics:
        """Compute comprehensive performance metrics."""
        # Basic time metrics
        time_efficiency = self.time_analyzer.calculate_time_efficiency()
        wall_clock_time = self.time_analyzer.end_wall_time - self.time_analyzer.start_wall_time

        # Throughput metrics
        system_throughput = self.calculate_system_throughput(num_drones, simulation_time)
        peak_throughput, _ = self.time_analyzer.get_peak_throughput()

        # Weighted throughput
        weighted_throughput = system_throughput * self.calculate_weighted_completion_rate()

        # Latency metrics
        avg_latency = self.latency_analyzer.calculate_average_latency()
        latency_percentiles = self.latency_analyzer.calculate_latency_percentiles()

        # Completion rate metrics
        completion_rate = self.tasks_completed / max(1, self.tasks_generated)
        weighted_completion_rate = self.calculate_weighted_completion_rate()

        # Per-priority completion rate
        priority_completion_rates = {}
        for priority, stats in self.priority_stats.items():
            if stats["generated"] > 0:
                priority_completion_rates[priority.value] = stats["completed"] / stats["generated"]
            else:
                priority_completion_rates[priority.value] = 0.0

        # Load balance metrics
        load_balance_index = self.calculate_load_balance_index(drone_loads)
        load_variance = np.var(drone_loads) if drone_loads else 0.0

        # Collaboration efficiency metrics
        collaboration_success_rate = self.collaboration_analyzer.calculate_collaboration_success_rate()
        collaboration_speedup = self.collaboration_analyzer.calculate_collaboration_speedup()
        collaboration_overhead = self.collaboration_analyzer.calculate_collaboration_overhead()
        
        return SystemMetrics(
            simulation_time=simulation_time,
            wall_clock_time=wall_clock_time,
            time_efficiency=time_efficiency,
            system_throughput=system_throughput,
            weighted_throughput=weighted_throughput,
            peak_throughput=peak_throughput,
            average_latency=avg_latency,
            median_latency=latency_percentiles["p50"],
            p95_latency=latency_percentiles["p95"],
            p99_latency=latency_percentiles["p99"],
            completion_rate=completion_rate,
            weighted_completion_rate=weighted_completion_rate,
            priority_completion_rates=priority_completion_rates,
            load_balance_index=load_balance_index,
            load_variance=load_variance,
            load_distribution=drone_loads.copy() if drone_loads else [],
            collaboration_success_rate=collaboration_success_rate,
            collaboration_speedup=collaboration_speedup,
            network_utilization=1.0 - collaboration_overhead  # Simplified computation
        )

    def generate_performance_report(self, metrics: SystemMetrics) -> str:
        """Generate a performance report."""
        report = []
        report.append("=" * 60)
        report.append("System Performance Evaluation Report")
        report.append("=" * 60)

        # Time analysis
        report.append("\n[Time Performance Analysis]")
        report.append(f"Simulation time: {metrics.simulation_time:.2f}s")
        report.append(f"Actual runtime: {metrics.wall_clock_time:.2f}s")
        report.append(f"Time efficiency: {metrics.time_efficiency:.2f}x")

        # Throughput analysis
        report.append("\n[Throughput Performance Analysis]")
        report.append(f"System throughput: {metrics.system_throughput:.3f} tasks/s")
        report.append(f"Weighted throughput: {metrics.weighted_throughput:.3f} weighted-tasks/s")
        report.append(f"Peak throughput: {metrics.peak_throughput:.3f} tasks/s")

        # Latency analysis
        report.append("\n[Latency Performance Analysis]")
        report.append(f"Mean response time: {metrics.average_latency:.3f}s")
        report.append(f"Median response time: {metrics.median_latency:.3f}s")
        report.append(f"95th percentile response time: {metrics.p95_latency:.3f}s")
        report.append(f"99th percentile response time: {metrics.p99_latency:.3f}s")

        # Completion rate analysis
        report.append("\n[Task Completion Rate Analysis]")
        report.append(f"Overall completion rate: {metrics.completion_rate:.1%}")
        report.append(f"Weighted completion rate: {metrics.weighted_completion_rate:.1%}")

        report.append("Completion rate by priority:")
        priority_names = {3: "High", 2: "Medium", 1: "Low", 0: "Background"}
        for priority, rate in metrics.priority_completion_rates.items():
            report.append(f"  {priority_names.get(priority, priority)} priority: {rate:.1%}")

        # Load balance analysis
        report.append("\n[Load Balance Analysis]")
        report.append(f"Load balance index: {metrics.load_balance_index:.3f}")
        report.append(f"Load variance: {metrics.load_variance:.3f}")

        # Collaboration efficiency analysis
        report.append("\n[Collaboration Efficiency Analysis]")
        report.append(f"Collaboration success rate: {metrics.collaboration_success_rate:.1%}")
        report.append(f"Collaboration speedup: {metrics.collaboration_speedup:.2f}x")

        report.append("=" * 60)

        return "\n".join(report)


if __name__ == "__main__":
    # Test the performance calculator
    print("Testing performance calculator...")

    calc = PerformanceCalculator()
    calc.start_measurement()

    # Simulate some data
    import random
    import time as time_module

    # Simulate task generation and completion
    for i in range(100):
        priority = TaskPriority(random.randint(0, 3))
        calc.record_task_generation(priority)

        if random.random() < 0.8:  # 80% completion rate
            arrival_time = i * 0.1
            start_time = arrival_time + random.uniform(0, 0.5)
            completion_time = start_time + random.uniform(0.1, 2.0)

            calc.record_task_completion(
                f"task_{i}", priority, arrival_time, start_time, completion_time, True
            )

            # Simulate collaborative processing
            if random.random() < 0.3:  # 30% collaborative processing
                calc.record_collaboration(
                    f"task_{i}",
                    completion_time - start_time - 0.1,
                    0.1,
                    True
                )
            else:
                calc.record_independent_processing(f"task_{i}", completion_time - start_time)

    # Wait a short while
    time_module.sleep(0.1)

    calc.end_measurement(10.0)  # 10s simulation time

    # Compute metrics
    drone_loads = [random.uniform(0.2, 0.8) for _ in range(5)]
    metrics = calc.calculate_comprehensive_metrics(5, 10.0, drone_loads)

    # Generate report
    report = calc.generate_performance_report(metrics)
    print(report)