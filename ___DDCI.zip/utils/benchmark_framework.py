"""
Benchmark framework.

Provides:
- Performance benchmark suite
- Algorithm performance comparison
- Parameter sensitivity analysis
- System bottleneck identification
"""

import time
import numpy as np
import json
import os
from typing import Dict, List, Tuple, Optional, Any, Callable
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
from collections import defaultdict

from .performance_metrics import PerformanceCalculator, SystemMetrics
from .statistical_tools import ArrivalProcessAnalyzer, QueueDynamicsAnalyzer, LoadBalanceAnalyzer


@dataclass
class BenchmarkConfig:
    """Benchmark configuration."""
    name: str
    description: str

    # Simulation parameters
    simulation_duration: float = 30.0
    num_drones: int = 5
    area_size: float = 400.0

    # Task parameters
    task_arrival_rates: Dict[str, float] = field(default_factory=lambda: {
        "high": 0.1, "medium": 0.5, "low": 1.0, "background": 0.2
    })

    # Collaboration parameters
    collaboration_enabled: bool = True
    collaboration_probability: float = 0.3

    # Network parameters
    communication_radius: float = 200.0
    mobility_enabled: bool = True

    # Number of repetitions
    num_runs: int = 3

    # Custom parameters
    custom_params: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BenchmarkResult:
    """Benchmark result."""
    config_name: str
    run_id: int

    # Performance metrics
    metrics: SystemMetrics

    # Timing information
    start_time: float
    end_time: float
    wall_clock_time: float

    # Extra information
    success: bool
    error_message: str = ""
    raw_data: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ComparisonResult:
    """Comparison result."""
    baseline_config: str
    test_configs: List[str]

    # Performance improvements
    throughput_improvement: Dict[str, float] = field(default_factory=dict)
    latency_improvement: Dict[str, float] = field(default_factory=dict)
    efficiency_improvement: Dict[str, float] = field(default_factory=dict)

    # Statistical significance
    statistical_significance: Dict[str, bool] = field(default_factory=dict)

    # Recommended configuration
    recommended_config: str = ""
    improvement_summary: str = ""


class BenchmarkSuite:
    """Benchmark suite."""

    def __init__(self, output_dir: str = "./benchmark_results"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

        self.configs: Dict[str, BenchmarkConfig] = {}
        self.results: Dict[str, List[BenchmarkResult]] = defaultdict(list)

        # Default benchmark configurations
        self._setup_default_benchmarks()

    def _setup_default_benchmarks(self):
        """Set up the default benchmark configurations."""

        # Baseline configuration - no collaboration
        self.configs["baseline_no_collab"] = BenchmarkConfig(
            name="baseline_no_collab",
            description="Baseline test without collaborative processing",
            collaboration_enabled=False,
            num_drones=5,
            simulation_duration=30.0
        )

        # Standard collaboration configuration
        self.configs["standard_collab"] = BenchmarkConfig(
            name="standard_collab",
            description="Standard collaborative processing configuration",
            collaboration_enabled=True,
            collaboration_probability=0.3,
            num_drones=5,
            simulation_duration=30.0
        )

        # High collaboration configuration
        self.configs["high_collab"] = BenchmarkConfig(
            name="high_collab",
            description="High-frequency collaborative processing configuration",
            collaboration_enabled=True,
            collaboration_probability=0.6,
            num_drones=5,
            simulation_duration=30.0
        )

        # Large-scale configuration
        self.configs["large_scale"] = BenchmarkConfig(
            name="large_scale",
            description="Large-scale drone swarm test",
            collaboration_enabled=True,
            collaboration_probability=0.4,
            num_drones=10,
            area_size=600.0,
            simulation_duration=30.0
        )

        # High-load configuration
        self.configs["high_load"] = BenchmarkConfig(
            name="high_load",
            description="High task load test",
            collaboration_enabled=True,
            task_arrival_rates={
                "high": 0.2, "medium": 1.0, "low": 2.0, "background": 0.5
            },
            num_drones=5,
            simulation_duration=30.0
        )

    def add_custom_config(self, config: BenchmarkConfig):
        """Add a custom test configuration."""
        self.configs[config.name] = config

    def run_benchmark(self, config_name: str,
                     simulation_runner: Callable[[BenchmarkConfig], SystemMetrics]) -> List[BenchmarkResult]:
        """Run a single benchmark."""
        if config_name not in self.configs:
            raise ValueError(f"Configuration not found: {config_name}")

        config = self.configs[config_name]
        results = []

        print(f"Running benchmark: {config.name}")
        print(f"Description: {config.description}")
        print(f"Number of runs: {config.num_runs}")

        for run_id in range(config.num_runs):
            print(f"  Run {run_id + 1}/{config.num_runs}...")

            start_time = time.time()

            try:
                # Run the simulation
                metrics = simulation_runner(config)

                end_time = time.time()
                wall_clock_time = end_time - start_time
                
                result = BenchmarkResult(
                    config_name=config_name,
                    run_id=run_id,
                    metrics=metrics,
                    start_time=start_time,
                    end_time=end_time,
                    wall_clock_time=wall_clock_time,
                    success=True
                )
                
                results.append(result)
                self.results[config_name].append(result)

                print(f"    [OK] Done - throughput: {metrics.system_throughput:.3f}, latency: {metrics.average_latency:.3f}s")

            except Exception as e:
                end_time = time.time()
                wall_clock_time = end_time - start_time

                result = BenchmarkResult(
                    config_name=config_name,
                    run_id=run_id,
                    metrics=SystemMetrics(),  # Empty metrics
                    start_time=start_time,
                    end_time=end_time,
                    wall_clock_time=wall_clock_time,
                    success=False,
                    error_message=str(e)
                )

                results.append(result)
                self.results[config_name].append(result)

                print(f"    [FAIL] Failed - {e}")

        return results

    def run_all_benchmarks(self, simulation_runner: Callable[[BenchmarkConfig], SystemMetrics]) -> Dict[str, List[BenchmarkResult]]:
        """Run all benchmarks."""
        print("=" * 60)
        print("Starting the benchmark suite")
        print("=" * 60)

        all_results = {}

        for config_name in self.configs:
            results = self.run_benchmark(config_name, simulation_runner)
            all_results[config_name] = results
            print()

        print("=" * 60)
        print("Benchmark suite complete")
        print("=" * 60)

        # Save results
        self._save_results()

        return all_results

    def run_parallel_benchmarks(self, simulation_runner: Callable[[BenchmarkConfig], SystemMetrics],
                               max_workers: int = 3) -> Dict[str, List[BenchmarkResult]]:
        """Run benchmarks in parallel."""
        print("=" * 60)
        print("Starting the benchmark suite in parallel")
        print(f"Max parallelism: {max_workers}")
        print("=" * 60)

        all_results = {}

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            future_to_config = {}

            for config_name in self.configs:
                future = executor.submit(self.run_benchmark, config_name, simulation_runner)
                future_to_config[future] = config_name

            # Collect results
            for future in as_completed(future_to_config):
                config_name = future_to_config[future]
                try:
                    results = future.result()
                    all_results[config_name] = results
                except Exception as e:
                    print(f"Configuration {config_name} failed to run: {e}")
                    all_results[config_name] = []

        print("=" * 60)
        print("Parallel benchmark suite complete")
        print("=" * 60)

        # Save results
        self._save_results()

        return all_results

    def _save_results(self):
        """Save the test results."""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(self.output_dir, f"benchmark_results_{timestamp}.json")

        # Prepare serializable data
        serializable_results = {}
        
        for config_name, results in self.results.items():
            serializable_results[config_name] = []
            
            for result in results:
                serializable_results[config_name].append({
                    "config_name": result.config_name,
                    "run_id": result.run_id,
                    "success": result.success,
                    "error_message": result.error_message,
                    "wall_clock_time": result.wall_clock_time,
                    "metrics": {
                        "simulation_time": result.metrics.simulation_time,
                        "system_throughput": result.metrics.system_throughput,
                        "average_latency": result.metrics.average_latency,
                        "completion_rate": result.metrics.completion_rate,
                        "load_balance_index": result.metrics.load_balance_index,
                        "collaboration_success_rate": result.metrics.collaboration_success_rate,
                        "collaboration_speedup": result.metrics.collaboration_speedup
                    }
                })
                
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(serializable_results, f, indent=2, ensure_ascii=False)

        print(f"Benchmark results saved: {filename}")


class PerformanceComparator:
    """Performance comparison analyzer."""

    def __init__(self):
        self.significance_threshold = 0.05  # Statistical significance threshold

    def compare_configurations(self, results: Dict[str, List[BenchmarkResult]],
                             baseline_config: str) -> ComparisonResult:
        """Compare the performance of different configurations."""
        if baseline_config not in results:
            raise ValueError(f"Baseline configuration does not exist: {baseline_config}")
            
        baseline_metrics = self._aggregate_metrics(results[baseline_config])
        comparison_result = ComparisonResult(
            baseline_config=baseline_config,
            test_configs=[]
        )
        
        for config_name, config_results in results.items():
            if config_name == baseline_config:
                continue
                
            comparison_result.test_configs.append(config_name)
            test_metrics = self._aggregate_metrics(config_results)

            # Compute performance improvements
            throughput_improvement = self._calculate_improvement(
                baseline_metrics['system_throughput'],
                test_metrics['system_throughput']
            )

            latency_improvement = self._calculate_improvement(
                baseline_metrics['average_latency'],
                test_metrics['average_latency'],
                lower_is_better=True
            )

            efficiency_improvement = self._calculate_improvement(
                baseline_metrics['load_balance_index'],
                test_metrics['load_balance_index']
            )

            comparison_result.throughput_improvement[config_name] = throughput_improvement
            comparison_result.latency_improvement[config_name] = latency_improvement
            comparison_result.efficiency_improvement[config_name] = efficiency_improvement

            # Statistical significance test
            significance = self._test_significance(
                results[baseline_config],
                config_results
            )
            comparison_result.statistical_significance[config_name] = significance

        # Recommend the best configuration
        comparison_result.recommended_config = self._recommend_best_config(comparison_result)
        comparison_result.improvement_summary = self._generate_improvement_summary(comparison_result)

        return comparison_result

    def _aggregate_metrics(self, results: List[BenchmarkResult]) -> Dict[str, float]:
        """Aggregate metrics across multiple runs."""
        successful_results = [r for r in results if r.success]
        
        if not successful_results:
            return {
                "system_throughput": 0.0,
                "average_latency": float('inf'),
                "completion_rate": 0.0,
                "load_balance_index": 0.0,
                "collaboration_success_rate": 0.0,
                "collaboration_speedup": 1.0
            }
            
        return {
            "system_throughput": np.mean([r.metrics.system_throughput for r in successful_results]),
            "average_latency": np.mean([r.metrics.average_latency for r in successful_results]),
            "completion_rate": np.mean([r.metrics.completion_rate for r in successful_results]),
            "load_balance_index": np.mean([r.metrics.load_balance_index for r in successful_results]),
            "collaboration_success_rate": np.mean([r.metrics.collaboration_success_rate for r in successful_results]),
            "collaboration_speedup": np.mean([r.metrics.collaboration_speedup for r in successful_results])
        }
        
    def _calculate_improvement(self, baseline: float, test: float, lower_is_better: bool = False) -> float:
        """Compute the performance improvement percentage."""
        if baseline == 0:
            return 0.0

        if lower_is_better:
            # For metrics like latency, lower is better
            improvement = (baseline - test) / baseline
        else:
            # For metrics like throughput, higher is better
            improvement = (test - baseline) / baseline

        return improvement * 100.0  # Convert to percentage

    def _test_significance(self, baseline_results: List[BenchmarkResult],
                          test_results: List[BenchmarkResult]) -> bool:
        """Statistical significance test (simplified)."""
        baseline_throughputs = [r.metrics.system_throughput for r in baseline_results if r.success]
        test_throughputs = [r.metrics.system_throughput for r in test_results if r.success]
        
        if len(baseline_throughputs) < 2 or len(test_throughputs) < 2:
            return False
            
        try:
            from scipy import stats
            _, p_value = stats.ttest_ind(baseline_throughputs, test_throughputs)
            return p_value < self.significance_threshold
        except ImportError:
            # If scipy is unavailable, use a simple variance test
            baseline_mean = np.mean(baseline_throughputs)
            test_mean = np.mean(test_throughputs)
            baseline_std = np.std(baseline_throughputs)
            test_std = np.std(test_throughputs)

            # Simple test: whether the difference exceeds the standard deviation
            diff = abs(test_mean - baseline_mean)
            combined_std = np.sqrt(baseline_std**2 + test_std**2)

            return diff > combined_std

    def _recommend_best_config(self, comparison: ComparisonResult) -> str:
        """Recommend the best configuration."""
        if not comparison.test_configs:
            return comparison.baseline_config

        # Composite score: throughput improvement * 0.4 + latency improvement * 0.3 + efficiency improvement * 0.3
        scores = {}
        
        for config in comparison.test_configs:
            score = (
                comparison.throughput_improvement.get(config, 0) * 0.4 +
                comparison.latency_improvement.get(config, 0) * 0.3 +
                comparison.efficiency_improvement.get(config, 0) * 0.3
            )
            scores[config] = score
            
        if not scores:
            return comparison.baseline_config
            
        best_config = max(scores.items(), key=lambda x: x[1])[0]
        return best_config
        
    def _generate_improvement_summary(self, comparison: ComparisonResult) -> str:
        """Generate an improvement summary."""
        if not comparison.test_configs:
            return "No configurations available for comparison"

        summary_parts = []
        best_config = comparison.recommended_config

        if best_config in comparison.throughput_improvement:
            throughput_imp = comparison.throughput_improvement[best_config]
            summary_parts.append(f"Throughput improvement: {throughput_imp:+.1f}%")

        if best_config in comparison.latency_improvement:
            latency_imp = comparison.latency_improvement[best_config]
            summary_parts.append(f"Latency improvement: {latency_imp:+.1f}%")

        if best_config in comparison.efficiency_improvement:
            efficiency_imp = comparison.efficiency_improvement[best_config]
            summary_parts.append(f"Efficiency improvement: {efficiency_imp:+.1f}%")

        significance = comparison.statistical_significance.get(best_config, False)
        significance_text = "statistically significant" if significance else "not statistically significant"

        return f"Recommended configuration {best_config}: " + ", ".join(summary_parts) + f" ({significance_text})"


class AlgorithmTester:
    """Algorithm tester: dedicated to testing the performance of different algorithms."""

    def __init__(self):
        self.test_scenarios = {}
        self.algorithm_results = {}

    def add_test_scenario(self, scenario_name: str, config: BenchmarkConfig):
        """Add a test scenario."""
        self.test_scenarios[scenario_name] = config

    def test_algorithms(self, algorithms: Dict[str, Callable],
                       scenario_name: str = None) -> Dict[str, Dict[str, Any]]:
        """Test the performance of multiple algorithms."""
        if scenario_name and scenario_name not in self.test_scenarios:
            raise ValueError(f"Test scenario does not exist: {scenario_name}")

        results = {}
        scenarios_to_test = {scenario_name: self.test_scenarios[scenario_name]} if scenario_name else self.test_scenarios

        print(f"Testing {len(algorithms)} algorithms across {len(scenarios_to_test)} scenarios")

        for scenario_name, config in scenarios_to_test.items():
            print(f"\nScenario: {scenario_name}")
            scenario_results = {}

            for algo_name, algorithm_func in algorithms.items():
                print(f"  Testing algorithm: {algo_name}")

                try:
                    start_time = time.time()
                    metrics = algorithm_func(config)
                    end_time = time.time()

                    scenario_results[algo_name] = {
                        "metrics": metrics,
                        "execution_time": end_time - start_time,
                        "success": True,
                        "error": None
                    }

                    print(f"    [OK] throughput: {metrics.system_throughput:.3f}, latency: {metrics.average_latency:.3f}s")

                except Exception as e:
                    scenario_results[algo_name] = {
                        "metrics": SystemMetrics(),
                        "execution_time": 0,
                        "success": False,
                        "error": str(e)
                    }
                    print(f"    [FAIL] Failed: {e}")

            results[scenario_name] = scenario_results

        self.algorithm_results.update(results)
        return results

    def generate_algorithm_comparison_report(self, results: Dict[str, Dict[str, Any]]) -> str:
        """Generate an algorithm comparison report."""
        report_lines = []
        report_lines.append("=" * 60)
        report_lines.append("Algorithm Performance Comparison Report")
        report_lines.append("=" * 60)

        for scenario_name, scenario_results in results.items():
            report_lines.append(f"\n[Scenario: {scenario_name}]")
            report_lines.append("-" * 40)

            # Sort by throughput
            successful_results = {k: v for k, v in scenario_results.items() if v["success"]}
            if successful_results:
                sorted_algos = sorted(
                    successful_results.items(),
                    key=lambda x: x[1]["metrics"].system_throughput,
                    reverse=True
                )

                report_lines.append("Algorithm ranking (by throughput):")
                for rank, (algo_name, result) in enumerate(sorted_algos, 1):
                    metrics = result["metrics"]
                    report_lines.append(
                        f"  {rank}. {algo_name}: "
                        f"throughput={metrics.system_throughput:.3f}, "
                        f"latency={metrics.average_latency:.3f}s, "
                        f"completion rate={metrics.completion_rate:.1%}"
                    )

            # Failed algorithms
            failed_results = {k: v for k, v in scenario_results.items() if not v["success"]}
            if failed_results:
                report_lines.append("\nFailed algorithms:")
                for algo_name, result in failed_results.items():
                    report_lines.append(f"  [FAIL] {algo_name}: {result['error']}")

        report_lines.append("\n" + "=" * 60)

        return "\n".join(report_lines)


if __name__ == "__main__":
    # Test the benchmark framework
    print("Testing benchmark framework...")

    # Mock simulation runner function
    def mock_simulation_runner(config: BenchmarkConfig) -> SystemMetrics:
        """Mock simulation run."""
        # Simulate some processing time
        time.sleep(0.1)

        # Generate mock metrics based on the configuration
        base_throughput = 2.0
        if config.collaboration_enabled:
            base_throughput *= (1 + config.collaboration_probability)
        if config.num_drones > 5:
            base_throughput *= (config.num_drones / 5)

        return SystemMetrics(
            simulation_time=config.simulation_duration,
            wall_clock_time=0.1,
            time_efficiency=config.simulation_duration / 0.1,
            system_throughput=base_throughput + np.random.uniform(-0.2, 0.2),
            average_latency=np.random.uniform(0.5, 2.0),
            completion_rate=np.random.uniform(0.8, 0.95),
            load_balance_index=np.random.uniform(0.6, 0.9),
            collaboration_success_rate=config.collaboration_probability if config.collaboration_enabled else 0.0,
            collaboration_speedup=1.2 if config.collaboration_enabled else 1.0
        )
        
    # Create the benchmark suite
    suite = BenchmarkSuite("./test_benchmark_results")

    # Run the benchmarks
    results = suite.run_all_benchmarks(mock_simulation_runner)

    # Performance comparison
    comparator = PerformanceComparator()
    comparison = comparator.compare_configurations(results, "baseline_no_collab")

    print("\nPerformance comparison results:")
    print(f"Recommended configuration: {comparison.recommended_config}")
    print(f"Improvement summary: {comparison.improvement_summary}")

    print("\nBenchmark framework test complete!")