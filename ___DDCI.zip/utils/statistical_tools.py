"""
Statistical analysis tools module.

Implements the mathematical model in CLAUDE.md:
- Task arrival process analysis (Poisson, compound Poisson, batch arrival)
- Queue dynamics analysis
- Load balance analysis
- Network topology analysis
"""

import numpy as np
import scipy.stats as stats
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from collections import defaultdict, deque
import math

from tasks import TaskPriority


@dataclass
class ArrivalProcessStats:
    """Task arrival process statistics."""
    priority: TaskPriority
    total_tasks: int
    arrival_rate: float  # λ (tasks/second)
    inter_arrival_times: List[float]

    # Statistical properties
    mean_inter_arrival: float
    variance_inter_arrival: float
    coefficient_variation: float  # CV = std/mean

    # Fitting results
    fitted_distribution: str
    goodness_of_fit: float  # p-value
    distribution_parameters: Dict[str, float]


@dataclass  
class QueueDynamicsStats:
    """Queue dynamics statistics."""
    drone_id: str
    priority: TaskPriority

    # Queue length statistics
    mean_queue_length: float
    max_queue_length: int
    queue_length_variance: float

    # Waiting time statistics
    mean_waiting_time: float
    median_waiting_time: float
    p95_waiting_time: float

    # Service time statistics
    mean_service_time: float
    service_time_variance: float

    # Utilization statistics
    server_utilization: float  # ρ = λ/μ
    queue_utilization: float


class ArrivalProcessAnalyzer:
    """Task arrival process analyzer."""

    def __init__(self):
        self.arrival_data: Dict[TaskPriority, List[float]] = defaultdict(list)
        self.last_arrival_time: Dict[TaskPriority, float] = {}

    def record_task_arrival(self, priority: TaskPriority, arrival_time: float):
        """Record a task arrival."""
        if priority in self.last_arrival_time:
            inter_arrival = arrival_time - self.last_arrival_time[priority]
            if inter_arrival > 0:  # Avoid tasks arriving simultaneously
                self.arrival_data[priority].append(inter_arrival)

        self.last_arrival_time[priority] = arrival_time

    def analyze_priority_arrivals(self, priority: TaskPriority) -> ArrivalProcessStats:
        """Analyze the arrival process for a given priority."""
        if priority not in self.arrival_data or len(self.arrival_data[priority]) < 2:
            return ArrivalProcessStats(
                priority=priority,
                total_tasks=0,
                arrival_rate=0.0,
                inter_arrival_times=[],
                mean_inter_arrival=0.0,
                variance_inter_arrival=0.0,
                coefficient_variation=0.0,
                fitted_distribution="unknown",
                goodness_of_fit=0.0,
                distribution_parameters={}
            )
            
        inter_arrivals = self.arrival_data[priority]

        # Basic statistics
        mean_inter = np.mean(inter_arrivals)
        var_inter = np.var(inter_arrivals)
        std_inter = np.std(inter_arrivals)

        arrival_rate = 1.0 / mean_inter if mean_inter > 0 else 0.0
        cv = std_inter / mean_inter if mean_inter > 0 else 0.0

        # Distribution fitting
        fitted_dist, gof, params = self._fit_distribution(inter_arrivals)
        
        return ArrivalProcessStats(
            priority=priority,
            total_tasks=len(inter_arrivals) + 1,  # +1 for first task
            arrival_rate=arrival_rate,
            inter_arrival_times=inter_arrivals.copy(),
            mean_inter_arrival=mean_inter,
            variance_inter_arrival=var_inter,
            coefficient_variation=cv,
            fitted_distribution=fitted_dist,
            goodness_of_fit=gof,
            distribution_parameters=params
        )
        
    def _fit_distribution(self, data: List[float]) -> Tuple[str, float, Dict[str, float]]:
        """Fit distributions and return the best-fitting result."""
        if len(data) < 10:
            return "insufficient_data", 0.0, {}
            
        distributions = {
            'exponential': stats.expon,
            'gamma': stats.gamma,
            'normal': stats.norm,
            'lognormal': stats.lognorm
        }
        
        best_dist = "unknown"
        best_p_value = 0.0
        best_params = {}
        
        for dist_name, distribution in distributions.items():
            try:
                # Fit parameters
                params = distribution.fit(data)

                # Kolmogorov-Smirnov test
                _, p_value = stats.kstest(data, lambda x: distribution.cdf(x, *params))

                if p_value > best_p_value:
                    best_p_value = p_value
                    best_dist = dist_name

                    # Save parameters
                    if dist_name == 'exponential':
                        best_params = {'loc': params[0], 'scale': params[1]}
                    elif dist_name == 'gamma':
                        best_params = {'a': params[0], 'loc': params[1], 'scale': params[2]}
                    elif dist_name == 'normal':
                        best_params = {'loc': params[0], 'scale': params[1]}
                    elif dist_name == 'lognormal':
                        best_params = {'s': params[0], 'loc': params[1], 'scale': params[2]}
                        
            except Exception as e:
                continue  # Skip distributions that fail to fit

        return best_dist, best_p_value, best_params

    def test_poisson_hypothesis(self, priority: TaskPriority, time_window: float) -> Dict[str, float]:
        """Test the Poisson distribution hypothesis."""
        if priority not in self.arrival_data:
            return {"lambda_est": 0.0, "p_value": 0.0, "is_poisson": False}
            
        inter_arrivals = self.arrival_data[priority]
        if len(inter_arrivals) < 10:
            return {"lambda_est": 0.0, "p_value": 0.0, "is_poisson": False}
            
        # Estimate the λ parameter
        lambda_est = 1.0 / np.mean(inter_arrivals)

        # Exponential distribution test (inter-arrival times of a Poisson process are exponentially distributed)
        _, p_value = stats.kstest(inter_arrivals, lambda x: stats.expon.cdf(x, scale=1.0/lambda_est))

        is_poisson = p_value > 0.05  # Significance level 0.05
        
        return {
            "lambda_est": lambda_est,
            "p_value": p_value,
            "is_poisson": is_poisson
        }


class QueueDynamicsAnalyzer:
    """Queue dynamics analyzer."""

    def __init__(self):
        self.queue_length_history: Dict[str, Dict[TaskPriority, List[Tuple[float, int]]]] = defaultdict(lambda: defaultdict(list))
        self.waiting_times: Dict[str, Dict[TaskPriority, List[float]]] = defaultdict(lambda: defaultdict(list))
        self.service_times: Dict[str, Dict[TaskPriority, List[float]]] = defaultdict(lambda: defaultdict(list))

    def record_queue_state(self, drone_id: str, priority: TaskPriority, time: float, queue_length: int):
        """Record the queue state."""
        self.queue_length_history[drone_id][priority].append((time, queue_length))

    def record_task_timing(self, drone_id: str, priority: TaskPriority,
                          waiting_time: float, service_time: float):
        """Record task timing."""
        self.waiting_times[drone_id][priority].append(waiting_time)
        self.service_times[drone_id][priority].append(service_time)

    def analyze_queue_dynamics(self, drone_id: str, priority: TaskPriority) -> QueueDynamicsStats:
        """Analyze queue dynamics."""
        if drone_id not in self.queue_length_history:
            return self._empty_queue_stats(drone_id, priority)

        # Queue length statistics
        queue_history = self.queue_length_history[drone_id][priority]
        if not queue_history:
            return self._empty_queue_stats(drone_id, priority)

        queue_lengths = [length for _, length in queue_history]
        mean_queue = np.mean(queue_lengths)
        max_queue = max(queue_lengths)
        var_queue = np.var(queue_lengths)

        # Waiting time statistics
        wait_times = self.waiting_times[drone_id][priority]
        if wait_times:
            mean_wait = np.mean(wait_times)
            median_wait = np.median(wait_times)
            p95_wait = np.percentile(wait_times, 95)
        else:
            mean_wait = median_wait = p95_wait = 0.0

        # Service time statistics
        service_times = self.service_times[drone_id][priority]
        if service_times:
            mean_service = np.mean(service_times)
            var_service = np.var(service_times)
        else:
            mean_service = var_service = 0.0

        # Utilization computation (simplified)
        if service_times and wait_times:
            total_time = sum(service_times) + sum(wait_times)
            busy_time = sum(service_times)
            server_util = busy_time / total_time if total_time > 0 else 0.0
        else:
            server_util = 0.0
            
        queue_util = mean_queue / max(1, max_queue) if max_queue > 0 else 0.0
        
        return QueueDynamicsStats(
            drone_id=drone_id,
            priority=priority,
            mean_queue_length=mean_queue,
            max_queue_length=max_queue,
            queue_length_variance=var_queue,
            mean_waiting_time=mean_wait,
            median_waiting_time=median_wait,
            p95_waiting_time=p95_wait,
            mean_service_time=mean_service,
            service_time_variance=var_service,
            server_utilization=server_util,
            queue_utilization=queue_util
        )
        
    def _empty_queue_stats(self, drone_id: str, priority: TaskPriority) -> QueueDynamicsStats:
        """Return empty queue statistics."""
        return QueueDynamicsStats(
            drone_id=drone_id,
            priority=priority,
            mean_queue_length=0.0,
            max_queue_length=0,
            queue_length_variance=0.0,
            mean_waiting_time=0.0,
            median_waiting_time=0.0,
            p95_waiting_time=0.0,
            mean_service_time=0.0,
            service_time_variance=0.0,
            server_utilization=0.0,
            queue_utilization=0.0
        )
        
    def calculate_little_law_verification(self, drone_id: str, priority: TaskPriority) -> Dict[str, float]:
        """Verify Little's law: L = λW."""
        stats = self.analyze_queue_dynamics(drone_id, priority)

        if stats.mean_waiting_time == 0:
            return {"L": 0.0, "lambda": 0.0, "W": 0.0, "ratio": 0.0, "verification": False}

        # L = mean queue length
        L = stats.mean_queue_length

        # W = mean waiting time
        W = stats.mean_waiting_time

        # λ = arrival rate (estimated)
        service_times = self.service_times[drone_id][priority]
        if service_times:
            lambda_est = 1.0 / np.mean(service_times)
        else:
            lambda_est = 0.0

        # Verify L ≈ λW
        expected_L = lambda_est * W
        ratio = L / expected_L if expected_L > 0 else 0.0
        verification = 0.8 <= ratio <= 1.2  # Considered verified within 20% error
        
        return {
            "L": L,
            "lambda": lambda_est,
            "W": W,
            "expected_L": expected_L,
            "ratio": ratio,
            "verification": verification
        }


class LoadBalanceAnalyzer:
    """Load balance analyzer."""

    def __init__(self):
        self.load_history: Dict[str, List[Tuple[float, float]]] = defaultdict(list)  # (time, load)

    def record_drone_load(self, drone_id: str, time: float, load: float):
        """Record a drone's load."""
        self.load_history[drone_id].append((time, load))

    def calculate_load_balance_metrics(self) -> Dict[str, float]:
        """Compute load balance metrics."""
        if not self.load_history:
            return {"gini_coefficient": 0.0, "load_variance": 0.0, "balance_index": 1.0}

        # Get the most recent load values
        current_loads = []
        for drone_id, history in self.load_history.items():
            if history:
                current_loads.append(history[-1][1])  # Latest load value

        if not current_loads:
            return {"gini_coefficient": 0.0, "load_variance": 0.0, "balance_index": 1.0}

        # Compute Gini coefficient
        gini = self._calculate_gini_coefficient(current_loads)

        # Compute load variance
        load_variance = np.var(current_loads)

        # Compute load balance index
        mean_load = np.mean(current_loads)
        if mean_load > 0:
            balance_index = 1.0 - (load_variance / mean_load)
        else:
            balance_index = 1.0
            
        return {
            "gini_coefficient": gini,
            "load_variance": load_variance,
            "balance_index": max(0.0, balance_index),
            "mean_load": mean_load,
            "max_load": max(current_loads),
            "min_load": min(current_loads)
        }
        
    def _calculate_gini_coefficient(self, values: List[float]) -> float:
        """Compute the Gini coefficient."""
        if not values or len(values) < 2:
            return 0.0

        # Sort
        sorted_values = sorted(values)
        n = len(sorted_values)

        # Compute the Gini coefficient
        cumsum = np.cumsum(sorted_values)
        return (n + 1 - 2 * sum((n + 1 - i) * y for i, y in enumerate(cumsum))) / (n * sum(sorted_values))

    def analyze_load_distribution(self) -> Dict[str, Any]:
        """Analyze the load distribution."""
        if not self.load_history:
            return {}
            
        distribution_stats = {}
        
        for drone_id, history in self.load_history.items():
            if not history:
                continue
                
            loads = [load for _, load in history]
            
            distribution_stats[drone_id] = {
                "mean": np.mean(loads),
                "std": np.std(loads),
                "min": np.min(loads),
                "max": np.max(loads),
                "median": np.median(loads),
                "p95": np.percentile(loads, 95),
                "coefficient_variation": np.std(loads) / np.mean(loads) if np.mean(loads) > 0 else 0.0
            }
            
        return distribution_stats


class NetworkAnalyzer:
    """Network topology analyzer."""

    def __init__(self):
        self.topology_history: List[Tuple[float, Dict[str, List[str]]]] = []
        self.connection_changes = 0

    def record_topology(self, time: float, topology: Dict[str, List[str]]):
        """Record the network topology."""
        if self.topology_history:
            # Detect topology changes
            last_topology = self.topology_history[-1][1]
            if self._topology_changed(last_topology, topology):
                self.connection_changes += 1

        self.topology_history.append((time, topology.copy()))

    def _topology_changed(self, old_topo: Dict[str, List[str]], new_topo: Dict[str, List[str]]) -> bool:
        """Detect whether the topology has changed."""
        if set(old_topo.keys()) != set(new_topo.keys()):
            return True
            
        for node in old_topo:
            if set(old_topo[node]) != set(new_topo.get(node, [])):
                return True
                
        return False
        
    def calculate_network_metrics(self) -> Dict[str, float]:
        """Compute network metrics."""
        if not self.topology_history:
            return {}

        # Use the latest topology
        _, current_topology = self.topology_history[-1]

        num_nodes = len(current_topology)
        if num_nodes == 0:
            return {}

        # Compute connectivity
        total_connections = sum(len(neighbors) for neighbors in current_topology.values())
        max_connections = num_nodes * (num_nodes - 1)  # Directed graph
        connectivity = total_connections / max_connections if max_connections > 0 else 0.0

        # Compute average degree
        average_degree = total_connections / num_nodes if num_nodes > 0 else 0.0

        # Compute clustering coefficient (simplified)
        clustering_coeff = self._calculate_clustering_coefficient(current_topology)

        # Compute network diameter (simplified)
        diameter = self._calculate_network_diameter(current_topology)
        
        return {
            "num_nodes": num_nodes,
            "connectivity": connectivity,
            "average_degree": average_degree,
            "clustering_coefficient": clustering_coeff,
            "network_diameter": diameter,
            "topology_changes": self.connection_changes,
            "topology_stability": 1.0 / (1.0 + self.connection_changes)  # Stability metric
        }

    def _calculate_clustering_coefficient(self, topology: Dict[str, List[str]]) -> float:
        """Compute the clustering coefficient (simplified)."""
        if len(topology) < 3:
            return 0.0

        total_coeff = 0.0
        valid_nodes = 0

        for node, neighbors in topology.items():
            if len(neighbors) < 2:
                continue

            # Count connections among neighbors
            neighbor_connections = 0
            for i, neighbor1 in enumerate(neighbors):
                for neighbor2 in neighbors[i+1:]:
                    if neighbor2 in topology.get(neighbor1, []):
                        neighbor_connections += 1

            # Number of possible connections
            possible_connections = len(neighbors) * (len(neighbors) - 1) // 2
            
            if possible_connections > 0:
                total_coeff += neighbor_connections / possible_connections
                valid_nodes += 1
                
        return total_coeff / valid_nodes if valid_nodes > 0 else 0.0
        
    def _calculate_network_diameter(self, topology: Dict[str, List[str]]) -> int:
        """Compute the network diameter (simplified BFS)."""
        if not topology:
            return 0

        max_distance = 0
        nodes = list(topology.keys())

        # Run BFS from each node
        for start_node in nodes[:5]:  # Limit computation to the first 5 nodes
            distances = self._bfs_distances(topology, start_node)
            if distances:
                max_distance = max(max_distance, max(distances.values()))

        return max_distance

    def _bfs_distances(self, topology: Dict[str, List[str]], start_node: str) -> Dict[str, int]:
        """Compute distances via BFS."""
        distances = {start_node: 0}
        queue = deque([start_node])
        
        while queue:
            current = queue.popleft()
            current_dist = distances[current]
            
            for neighbor in topology.get(current, []):
                if neighbor not in distances:
                    distances[neighbor] = current_dist + 1
                    queue.append(neighbor)
                    
        return distances


if __name__ == "__main__":
    # Test the statistical analysis tools
    print("Testing statistical analysis tools...")

    # Test arrival process analysis
    arrival_analyzer = ArrivalProcessAnalyzer()

    # Simulate a Poisson arrival process
    np.random.seed(42)
    current_time = 0.0
    lambda_rate = 2.0  # 2 tasks per second

    for _ in range(50):
        inter_arrival = np.random.exponential(1.0 / lambda_rate)
        current_time += inter_arrival
        arrival_analyzer.record_task_arrival(TaskPriority.MEDIUM, current_time)

    # Analyze results
    stats = arrival_analyzer.analyze_priority_arrivals(TaskPriority.MEDIUM)
    print(f"Arrival rate analysis: {stats.arrival_rate:.2f} tasks/s")
    print(f"Fitted distribution: {stats.fitted_distribution}")
    print(f"Goodness of fit: {stats.goodness_of_fit:.3f}")

    # Test the Poisson hypothesis
    poisson_test = arrival_analyzer.test_poisson_hypothesis(TaskPriority.MEDIUM, 30.0)
    print(f"Poisson test: λ={poisson_test['lambda_est']:.2f}, p={poisson_test['p_value']:.3f}, is Poisson: {poisson_test['is_poisson']}")

    print("\nStatistical analysis tools test complete!")