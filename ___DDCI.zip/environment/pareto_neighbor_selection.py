"""
Pareto-optimal neighbor selection strategy (V4: three objectives - distance/load/capacity)

Three-objective optimization:
1. Minimize distance (reduce communication energy consumption and propagation latency)
2. Minimize load rate (reduce queue waiting time)
3. Maximize computing capacity (increase processing speed)

Note: once energy consumption becomes a first-class optimization objective,
communication energy consumption is proportional to distance x data size, so distance
is brought back as a Pareto dimension. When selecting a neighbor, the partition point
is not yet decided and the exact communication energy consumption is unknown, so
distance is the best proxy for the communication energy consumption at that moment.
"""

import numpy as np
from typing import List, Dict, Optional
from dataclasses import dataclass


@dataclass
class NeighborCandidate:
    """Neighbor candidate"""
    neighbor_id: str
    distance: float  # distance (m) - Pareto dimension 1 (min)
    load: float  # load rate [0, 1] - Pareto dimension 2 (min)
    capacity: float = 10e9  # computing capacity (FLOPS, rate) - Pareto dimension 3 (max)

    @property
    def capacity_gflops(self) -> float:
        """Computing capacity (GFLOPS)"""
        return self.capacity / 1e9

    @property
    def effective_capacity(self) -> float:
        """Effective processing capacity = computing capacity x (1 - load rate)"""
        return self.capacity * (1 - self.load)

    def __repr__(self):
        return f"{self.neighbor_id}(d={self.distance:.0f}m, load={self.load:.0%}, cap={self.capacity_gflops:.0f}G)"


class ParetoNeighborSelector:
    """
    Pareto-optimal neighbor selector (V4: three objectives)

    Three-objective optimization:
    1. min distance (reduce communication energy consumption and propagation latency)
    2. min load (reduce queue waiting)
    3. max capacity (increase processing speed)

    Reasons for bringing distance back as a Pareto dimension (revised):
    - Once energy consumption is promoted to a first-class optimization objective,
      communication energy consumption is proportional to distance x data size, so distance is no longer negligible
    - When selecting a neighbor the partition point is not yet decided and the exact
      communication energy consumption is unknown; distance is the best proxy for the communication energy consumption at that moment
    - The three objectives preserve the genuine conflict among communication cost vs
      queue waiting vs computing speed, avoiding the heuristic collapsing them into a single dimension
    """

    def __init__(self, k: int = 3):
        self.k = k

    def is_dominated(self, candidate_a: NeighborCandidate, candidate_b: NeighborCandidate) -> bool:
        """
        Determine whether candidate_a is dominated by candidate_b (three-objective version)

        Objectives:
        - distance: smaller is better
        - load: smaller is better
        - capacity: larger is better
        """
        # candidate_b is no worse than candidate_a on all three objectives
        not_worse_on_all = (
            candidate_b.distance <= candidate_a.distance and
            candidate_b.load <= candidate_a.load and
            candidate_b.capacity >= candidate_a.capacity
        )

        # candidate_b is strictly better than candidate_a on at least one objective
        better_on_at_least_one = (
            candidate_b.distance < candidate_a.distance or
            candidate_b.load < candidate_a.load or
            candidate_b.capacity > candidate_a.capacity
        )

        return not_worse_on_all and better_on_at_least_one

    def find_pareto_front(self, candidates: List[NeighborCandidate]) -> List[NeighborCandidate]:
        """Find the Pareto front (set of non-dominated solutions)"""
        pareto_front = []

        for i, candidate_i in enumerate(candidates):
            is_dominated_by_any = False

            for j, candidate_j in enumerate(candidates):
                if i == j:
                    continue

                if self.is_dominated(candidate_i, candidate_j):
                    is_dominated_by_any = True
                    break

            if not is_dominated_by_any:
                pareto_front.append(candidate_i)

        return pareto_front

    def select_diverse_representatives(
        self,
        pareto_front: List[NeighborCandidate],
        k: int,
        comm_radius: float = 200.0
    ) -> List[NeighborCandidate]:
        """
        Select K representative nodes from the Pareto front (three-objective version)

        Strategy: sort by a combined three-objective score. The combined score
        simultaneously rewards short distance, low load, and high capacity.
        score = capacity*(1-load) * (1 - distance/comm_radius)
              = effective processing capacity x proximity discount
        """
        if len(pareto_front) == 0:
            return []

        def tri_score(c: NeighborCandidate) -> float:
            proximity = max(0.0, 1.0 - c.distance / max(comm_radius, 1e-9))
            return c.effective_capacity * proximity

        # Sort by combined three-objective score (high to low)
        sorted_front = sorted(pareto_front, key=tri_score, reverse=True)

        if len(sorted_front) >= k:
            return sorted_front[:k]
        else:
            return sorted_front

    @staticmethod
    def _ranking_key(c: 'NeighborCandidate'):
        """Deterministic sort key: effective processing capacity descending, ties broken by neighbor_id ascending.

        - Primary key: effective_capacity = capacity*(1-load), larger is better (negated so ascending sort is equivalent to descending)
        - Secondary key (tie-breaker): neighbor_id string ascending, ensuring a stable and reproducible candidate order
        This makes the mapping from action index m to a specific neighbor deterministic for the same observation and consistent across epochs.
        """
        return (-c.effective_capacity, str(c.neighbor_id))

    def select_top_k(self, candidates: List[NeighborCandidate], k: int = None) -> List[NeighborCandidate]:
        """
        Select TOP-K neighbors based on Pareto optimality (deterministic and reproducible)

        Process:
        - Step 1: filter the three-objective Pareto front (distance/load/capacity)
        - Step 2: sort the front by the deterministic sort key (effective capacity descending, ID ascending for tie-breaking),
                 take the top K; if the front has fewer than K, fill from the remaining candidates using the same sort key
        - No random shuffling: the mapping from action index m to neighbor is stable, and each index's semantics are consistent between training and evaluation

        Note: the sort key provides a reproducible "representative" order -- it presents the
        non-dominated candidates with the highest effective processing capacity first,
        while preserving the three-way conflict of distance/load/capacity characterized by the Pareto front.
        """
        if k is None:
            k = self.k

        if len(candidates) == 0:
            return []

        if len(candidates) <= k:
            # Fewer candidates than K: return sorted directly by the deterministic sort key (no randomness)
            return sorted(candidates, key=self._ranking_key)

        # Step 1: find the three-objective Pareto front (non-dominated set)
        pareto_front = self.find_pareto_front(candidates)

        # Step 2: sort by the deterministic sort key
        sorted_front = sorted(pareto_front, key=self._ranking_key)

        if len(sorted_front) >= k:
            selected = sorted_front[:k]
        else:
            # Front has fewer than K: fill from the remaining non-front candidates using the same sort key
            selected = sorted_front.copy()
            remaining = sorted(
                [c for c in candidates if c not in sorted_front],
                key=self._ranking_key,
            )
            needed = k - len(selected)
            selected.extend(remaining[:needed])

        return selected

    def get_pareto_info(self, candidates: List[NeighborCandidate]) -> Dict:
        """Get Pareto analysis information"""
        pareto_front = self.find_pareto_front(candidates)
        selected = self.select_top_k(candidates)

        return {
            'total_candidates': len(candidates),
            'pareto_front_size': len(pareto_front),
            'pareto_front': pareto_front,
            'selected': selected,
            'pareto_ratio': len(pareto_front) / len(candidates) if candidates else 0,
        }


def calculate_collaboration_score(
    neighbor: NeighborCandidate,
    load_weight: float = 0.5,
    capacity_weight: float = 0.5
) -> float:
    """
    Calculate collaboration score (used for heuristic selection)

    Considers only load and computing capacity, not distance
    """
    load_score = 1.0 - neighbor.load  # lower load is better
    capacity_score = min(neighbor.capacity / 20e9, 1.0)  # higher capacity is better

    return load_score * load_weight + capacity_score * capacity_weight
