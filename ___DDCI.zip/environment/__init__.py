"""
Environment module for drone collaborative inference.

This module provides:
- Spatial management for drone positions and movement
- Network topology management
- Mobility simulation with different movement patterns
- Integration with communication and neighbor discovery systems
- Gymnasium environment interface for DRL training

Based on CLAUDE.md mathematical models:
- Position coordinates: p_i(t) ∈ R^2
- Neighbor sets: N_i(t) = {u_j : ||p_i(t) - p_j(t)|| ≤ R_comm, j ≠ i}
- Distance calculations: d_{i,j} = ||p_i(t) - p_j(t)||
- State space: s_i(t) ∈ R^{3+2K}
- Action space: (partner_idx, layer_cut)
- Reward function: R_i(t) = Σw(p)·r_completion - α·latency - β·comm_cost
"""

from .spatial_manager import (
    SpatialManager,
    DroneState,
    SpatialConfiguration,
    MovementPattern
)

from .swarm_simulator import (
    SwarmSimulator,
    DroneSimulator,
    DroneConfiguration,
    SwarmConfiguration,
    SimulationStatistics,
    SimulationState
)

# Gymnasium environment interface
from .drone_collaboration_env import (
    DroneCollaborationEnv,
    DroneObservation,
    CollaborationAction
)

# Environment utilities and wrappers removed during cleanup
# These were redundant and consolidated into main modules

__all__ = [
    # Spatial management
    'SpatialManager',
    'DroneState',
    'SpatialConfiguration', 
    'MovementPattern',
    
    # Swarm simulation
    'SwarmSimulator',
    'DroneSimulator',
    'DroneConfiguration',
    'SwarmConfiguration',
    'SimulationStatistics',
    'SimulationState',
    
    # Gymnasium environment interface
    'DroneCollaborationEnv',
    'DroneObservation', 
    'CollaborationAction',
]