"""
Hierarchical decision environment wrapper - two-stage sequential decision

Stage 1: select collaboration partner (partner_idx: 0-3)
Stage 2: select partition layer (layer_cut: 0-8)

Each stage is a standard Discrete action space and can be trained directly
with SB3's DQN.
"""

import numpy as np
import gymnasium as gym
from gymnasium import spaces
from typing import Tuple, Dict, Any


class Stage1PartnerSelectionWrapper(gym.Wrapper):
    """
    Stage 1: collaboration partner selection environment

    Action space: Discrete(4) - select partner (0=local, 1-3=neighbors)
    Observation space: keeps the original 13-dim observation

    During training, layer_cut is fixed to 4 (medium partition point)
    """

    def __init__(self, env, fixed_layer_cut: int = 4):
        super().__init__(env)
        self.action_space = spaces.Discrete(4)  # select partner only
        self.fixed_layer_cut = fixed_layer_cut

    def step(self, partner_idx: int):
        """
        Execute the stage 1 action

        Args:
            partner_idx: 0-3 (which partner to select)

        Returns:
            standard gym return format
        """
        # Compose full action: (partner_idx, fixed_layer_cut)
        full_action = (int(partner_idx), self.fixed_layer_cut)

        # Execute
        obs, reward, terminated, truncated, info = self.env.step(full_action)

        # Record extra info
        info['stage'] = 1
        info['partner_idx'] = partner_idx
        info['layer_cut'] = self.fixed_layer_cut

        return obs, reward, terminated, truncated, info


class Stage2LayerSelectionWrapper(gym.Wrapper):
    """
    Stage 2: partition layer selection environment

    Action space: Discrete(9) - select layer_cut (0-8)
    Observation space: extended to [original 13-dim + partner_idx(1-dim)] = 14-dim

    Requires a stage 1 model already trained to select the partner, then trains
    the layer selection
    """

    def __init__(self, env, stage1_model):
        """
        Args:
            env: original environment
            stage1_model: trained stage 1 model (SB3 DQN)
        """
        super().__init__(env)
        self.action_space = spaces.Discrete(9)  # select layer only

        # Extend observation space: original 13-dim + partner_idx(1-dim)
        original_obs_space = env.observation_space
        self.observation_space = spaces.Box(
            low=0.0,
            high=1.0,
            shape=(14,),  # 13 + 1
            dtype=np.float32
        )

        self.stage1_model = stage1_model
        self.current_partner_idx = None

    def reset(self, **kwargs):
        """Reset the environment"""
        obs, info = self.env.reset(**kwargs)

        # Use the stage 1 model to select the partner
        self.current_partner_idx, _ = self.stage1_model.predict(obs, deterministic=False)

        # Extend observation: [original obs, partner_idx]
        extended_obs = self._extend_observation(obs, self.current_partner_idx)

        info['stage'] = 2
        info['partner_idx'] = int(self.current_partner_idx)

        return extended_obs, info

    def step(self, layer_cut: int):
        """
        Execute the stage 2 action

        Args:
            layer_cut: 0-8 (select the partition layer)

        Returns:
            standard gym return format
        """
        # Compose full action: (current_partner_idx, layer_cut)
        full_action = (int(self.current_partner_idx), int(layer_cut))

        # Execute
        obs, reward, terminated, truncated, info = self.env.step(full_action)

        # If the episode has not ended, update the partner selection
        if not (terminated or truncated):
            self.current_partner_idx, _ = self.stage1_model.predict(obs, deterministic=False)

        # Extend observation
        extended_obs = self._extend_observation(obs, self.current_partner_idx)

        # Record extra info
        info['stage'] = 2
        info['partner_idx'] = int(self.current_partner_idx)
        info['layer_cut'] = int(layer_cut)

        return extended_obs, reward, terminated, truncated, info

    def _extend_observation(self, obs: np.ndarray, partner_idx: int) -> np.ndarray:
        """
        Extend observation: append partner_idx info

        Args:
            obs: original 13-dim observation
            partner_idx: selected partner index (0-3)

        Returns:
            14-dim extended observation
        """
        partner_idx_norm = partner_idx / 3.0  # normalize to [0, 1]
        return np.append(obs, partner_idx_norm)


class HierarchicalDualDQNWrapper(gym.Wrapper):
    """
    Complete hierarchical dual-DQN environment - joint training version

    In each step:
    1. Stage 1 agent selects the partner
    2. Stage 2 agent selects the layer
    3. Execute the full action
    4. Both agents receive the reward and learn

    This version allows both agents to be trained simultaneously
    """

    def __init__(self, env):
        super().__init__(env)
        # Do not change action_space, since the two agents are called separately externally
        self.current_obs = None

    def reset(self, **kwargs):
        """Reset the environment"""
        obs, info = self.env.reset(**kwargs)
        self.current_obs = obs
        return obs, info

    def step_stage1(self, partner_idx: int) -> Tuple[np.ndarray, int]:
        """
        Stage 1: select the partner

        Returns:
            (extended_obs_for_stage2, partner_idx)
        """
        # Extend observation for stage 2: [original obs, partner_idx]
        partner_idx_norm = partner_idx / 3.0
        extended_obs = np.append(self.current_obs, partner_idx_norm)

        return extended_obs, partner_idx

    def step_stage2(self, partner_idx: int, layer_cut: int):
        """
        Stage 2: select the layer and execute the full action

        Returns:
            standard gym return format
        """
        # Execute the full action
        full_action = (int(partner_idx), int(layer_cut))
        obs, reward, terminated, truncated, info = self.env.step(full_action)

        self.current_obs = obs

        info['partner_idx'] = partner_idx
        info['layer_cut'] = layer_cut

        return obs, reward, terminated, truncated, info
