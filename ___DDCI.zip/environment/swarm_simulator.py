"""
Drone swarm simulator: multi-drone collaborative inference environment integrating all components.

Mathematical model:
- System state: S(t) = (Q(t), P(t), G(t), E(t))
- Drone set: U = {u_1, u_2, ..., u_N}
- Hierarchical task arrival process: high priority (Poisson), medium priority (compound Poisson), low priority (Poisson), background (batch)
- Collaborative inference: minibatch pipeline parallel processing
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

import time
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import threading
import queue
from concurrent.futures import ThreadPoolExecutor
import json

# Import all related modules
from environment import SpatialManager, SpatialConfiguration, MovementPattern
from communication import CommunicationEngine, NeighborDiscoveryManager, SelectionStrategy
from tasks import TaskGenerator, PriorityScheduler, HierarchicalTaskQueue
from models import ResNetPartitioner, MiniBatchPipelineEngine


class SimulationState(Enum):
    """Simulation state."""
    INITIALIZED = "initialized"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass
class DroneConfiguration:
    """Single drone configuration."""
    drone_id: str
    initial_position: Tuple[float, float]
    movement_pattern: MovementPattern = MovementPattern.STATIONARY
    communication_radius: float = 200.0
    processing_capacity: float = 1000.0  # FLOPS
    initial_battery: float = 1.0
    max_speed: float = 20.0  # m/s

    # Task processing configuration
    max_concurrent_tasks: int = 5
    queue_size: int = 20
    

@dataclass
class SwarmConfiguration:
    """Swarm simulation configuration."""
    # Spatial configuration
    area_bounds: Tuple[Tuple[float, float], Tuple[float, float]] = ((-500, -500), (500, 500))

    # Time configuration
    simulation_duration: float = 300.0  # Simulation duration (seconds)
    time_step: float = 0.1             # Time step (seconds)
    topology_update_interval: float = 1.0  # Topology update interval

    # Task generation configuration
    enable_task_generation: bool = True
    task_generation_interval: float = 0.5  # Task generation interval

    # Performance configuration
    max_threads: int = 8
    log_interval: float = 10.0  # Log output interval

    # Output configuration
    save_trajectory: bool = True
    save_statistics: bool = True
    output_directory: str = "./simulation_results"


@dataclass
class SimulationStatistics:
    """Simulation statistics."""
    # Basic information
    simulation_time: float = 0.0
    total_drones: int = 0

    # Task statistics
    tasks_generated: int = 0
    tasks_completed: int = 0
    tasks_failed: int = 0

    # Statistics by priority
    priority_stats: Dict[int, Dict[str, int]] = field(default_factory=lambda: {
        3: {"generated": 0, "completed": 0, "failed": 0},  # High priority
        2: {"generated": 0, "completed": 0, "failed": 0},  # Medium priority
        1: {"generated": 0, "completed": 0, "failed": 0},  # Low priority
        0: {"generated": 0, "completed": 0, "failed": 0}   # Background
    })

    # Collaboration statistics
    collaboration_attempts: int = 0
    successful_collaborations: int = 0

    # Network statistics
    topology_changes: int = 0
    average_neighbors: float = 0.0
    network_connectivity: float = 0.0

    # Performance statistics
    average_task_latency: float = 0.0
    system_throughput: float = 0.0  # tasks/second
    load_balance_index: float = 0.0


class DroneSimulator:
    """Single drone simulator."""

    def __init__(self, config: DroneConfiguration, swarm_simulator):
        self.config = config
        self.swarm_simulator = swarm_simulator
        self.drone_id = config.drone_id

        # Component initialization
        self.task_queue = HierarchicalTaskQueue(drone_id=config.drone_id, max_queue_size=config.queue_size)
        self.priority_scheduler = PriorityScheduler()
        self.resnet_partitioner = ResNetPartitioner()
        self.pipeline_engine = MiniBatchPipelineEngine()

        # State management
        self.is_active = True
        self.current_load = 0.0
        self.battery_level = config.initial_battery
        self.processing_count = 0

        # Statistics
        self.tasks_processed = 0
        self.collaborations_performed = 0
        self.total_processing_time = 0.0

        # Thread management
        self._stop_event = threading.Event()
        self._task_thread = None

    def start(self):
        """Start drone simulation."""
        if self._task_thread is None or not self._task_thread.is_alive():
            self._stop_event.clear()
            self._task_thread = threading.Thread(target=self._task_processing_loop)
            self._task_thread.start()
            
    def stop(self):
        """Stop drone simulation."""
        self._stop_event.set()
        if self._task_thread and self._task_thread.is_alive():
            self._task_thread.join(timeout=2.0)

    def _task_processing_loop(self):
        """Task processing loop."""
        while not self._stop_event.is_set():
            try:
                # Get the next task
                task_entry = self.task_queue.get_next_task_for_processing(time.time())
                task = task_entry.task if task_entry else None

                if task is None:
                    time.sleep(0.01)  # Brief sleep
                    continue

                # Process task
                self._process_task(task)

            except Exception as e:
                print(f"Error: drone {self.drone_id} task processing exception: {e}")
                time.sleep(0.1)

    def _process_task(self, task):
        """Process a single task."""
        start_time = time.time()

        try:
            # Check whether collaboration is needed
            if task.priority == 2 and task.flops > self.config.processing_capacity * 0.8:
                # Medium-priority task with large computation, attempt collaboration
                success = self._attempt_collaboration(task)

                if success:
                    self.collaborations_performed += 1
                else:
                    # Collaboration failed, process independently
                    self._process_independently(task)
            else:
                # Process independently
                self._process_independently(task)

            # Update statistics
            self.tasks_processed += 1
            processing_time = time.time() - start_time
            self.total_processing_time += processing_time

            # Update system statistics
            self.swarm_simulator._update_task_completion(task, True, processing_time)

        except Exception as e:
            print(f"Task processing failed: {e}")
            self.swarm_simulator._update_task_completion(task, False, 0)
            
    def _attempt_collaboration(self, task) -> bool:
        """Attempt collaborative task processing."""
        try:
            # Get the neighbor discovery manager
            neighbor_manager = self.swarm_simulator.neighbor_manager

            # Select Top-3 candidates
            candidates = neighbor_manager.select_top_candidates(
                self.drone_id,
                SelectionStrategy.LOAD_BALANCED
            )

            if not candidates:
                return False

            # Select the best collaboration partner (top-ranked candidate)
            partner_id = candidates[0].drone_id
            partner_simulator = self.swarm_simulator.drone_simulators.get(partner_id)

            if not partner_simulator or not partner_simulator.is_active:
                return False

            # Check the partner's load
            if partner_simulator.current_load > 0.8:
                return False

            # Execute collaborative inference
            return self._execute_collaborative_inference(task, partner_id)

        except Exception as e:
            print(f"Collaboration attempt failed: {e}")
            return False

    def _execute_collaborative_inference(self, task, partner_id: str) -> bool:
        """Execute collaborative inference."""
        try:
            # Create simulated input data
            batch_size = min(32, task.flops // 1000)  # Estimate batch size from FLOPS
            input_data = np.random.randn(batch_size, 3, 224, 224).astype(np.float32)

            # Get partner position information
            partner_state = self.swarm_simulator.spatial_manager.get_drone_state(partner_id)
            self_state = self.swarm_simulator.spatial_manager.get_drone_state(self.drone_id)

            if not partner_state or not self_state:
                return False

            # Execute minibatch pipeline inference
            result = self.pipeline_engine.process_collaborative_inference(
                input_data=input_data,
                cut_layer=5,  # Fixed partition point; should be decided by DRL in practice
                drone_a_id=self.drone_id,
                drone_b_id=partner_id,
                drone_a_pos=self_state.position,
                drone_b_pos=partner_state.position,
                comm_engine=self.swarm_simulator.comm_engine
            )

            # Update collaboration statistics
            self.swarm_simulator.stats.collaboration_attempts += 1
            if result.success:
                self.swarm_simulator.stats.successful_collaborations += 1

            return result.success

        except Exception as e:
            print(f"Collaborative inference execution failed: {e}")
            return False

    def _process_independently(self, task):
        """Process a task independently."""
        # Simulate independent inference processing
        processing_time = task.flops / self.config.processing_capacity

        # Update load
        self.current_load = min(1.0, self.current_load + 0.1)

        # Simulate processing delay
        time.sleep(min(0.01, processing_time))  # Sleep at most 10ms

        # Processing complete, reduce load
        self.current_load = max(0.0, self.current_load - 0.1)

    def add_task(self, task):
        """Add a new task."""
        return self.task_queue.add_task(task)

    def get_status(self) -> Dict:
        """Get drone status."""
        queue_lengths, queue_load, busy_rate = self.task_queue.get_queue_state(0.0)
        return {
            "drone_id": self.drone_id,
            "is_active": self.is_active,
            "current_load": self.current_load,
            "battery_level": self.battery_level,
            "queue_size": sum(queue_lengths),
            "tasks_processed": self.tasks_processed,
            "collaborations_performed": self.collaborations_performed,
            "avg_processing_time": self.total_processing_time / max(1, self.tasks_processed)
        }


class SwarmSimulator:
    """
    Main drone swarm simulator class.

    Integrates all components:
    - Spatial manager: position and topology
    - Communication engine: communication modeling
    - Neighbor discovery: Top-3 candidate selection
    - Task generator: hierarchical task arrival
    - Drone simulator: task processing and collaboration
    """

    def __init__(self, config: SwarmConfiguration):
        self.config = config
        self.state = SimulationState.INITIALIZED

        # Core component initialization
        spatial_config = SpatialConfiguration(
            area_bounds=config.area_bounds,
            enable_mobility=True,
            position_update_interval=config.time_step
        )
        self.spatial_manager = SpatialManager(spatial_config)
        self.comm_engine = CommunicationEngine()
        self.neighbor_manager = NeighborDiscoveryManager(
            self.spatial_manager, self.comm_engine, K=3
        )
        self.task_generator = TaskGenerator()

        # Simulation state
        self.drone_simulators: Dict[str, DroneSimulator] = {}
        self.simulation_start_time = 0.0
        self.current_time = 0.0

        # Statistics
        self.stats = SimulationStatistics()

        # Thread management
        self.executor = ThreadPoolExecutor(max_workers=config.max_threads)
        self._stop_event = threading.Event()
        self._main_thread = None

        # Result storage
        self.trajectory_data = []
        self.event_log = []

    def add_drone(self, drone_config: DroneConfiguration) -> bool:
        """Add a drone to the swarm."""
        try:
            # Register with the spatial manager
            success = self.spatial_manager.register_drone(
                drone_config.drone_id,
                drone_config.initial_position,
                drone_config.communication_radius,
                drone_config.movement_pattern
            )
            
            if not success:
                return False

            # Set drone state
            drone_state = self.spatial_manager.get_drone_state(drone_config.drone_id)
            if drone_state:
                drone_state.battery_level = drone_config.initial_battery
                drone_state.max_speed = drone_config.max_speed

            # Create drone simulator
            drone_simulator = DroneSimulator(drone_config, self)
            self.drone_simulators[drone_config.drone_id] = drone_simulator

            self.stats.total_drones += 1
            print(f"Added drone: {drone_config.drone_id} position: {drone_config.initial_position}")

            return True

        except Exception as e:
            print(f"Failed to add drone: {e}")
            return False

    def remove_drone(self, drone_id: str) -> bool:
        """Remove a drone."""
        try:
            # Stop the drone simulator
            if drone_id in self.drone_simulators:
                self.drone_simulators[drone_id].stop()
                del self.drone_simulators[drone_id]

            # Unregister from the spatial manager
            self.spatial_manager.unregister_drone(drone_id)

            self.stats.total_drones -= 1
            print(f"Removed drone: {drone_id}")

            return True

        except Exception as e:
            print(f"Failed to remove drone: {e}")
            return False

    def start_simulation(self) -> None:
        """Start the simulation."""
        if self.state != SimulationState.INITIALIZED:
            print("Simulation is already running or not properly initialized")
            return

        print("=" * 60)
        print("Starting drone swarm simulation...")
        print(f"Simulation duration: {self.config.simulation_duration}s")
        print(f"Number of drones: {len(self.drone_simulators)}")
        print(f"Simulation area: {self.config.area_bounds}")
        print("=" * 60)

        self.state = SimulationState.RUNNING
        self.simulation_start_time = time.time()

        # Start all drone simulators
        for drone_simulator in self.drone_simulators.values():
            drone_simulator.start()

        # Start the main simulation loop
        self._stop_event.clear()
        self._main_thread = threading.Thread(target=self._simulation_loop)
        self._main_thread.start()

    def stop_simulation(self) -> None:
        """Stop the simulation."""
        print("Stopping simulation...")

        self.state = SimulationState.STOPPED
        self._stop_event.set()

        # Stop all drone simulators
        for drone_simulator in self.drone_simulators.values():
            drone_simulator.stop()

        # Wait for the main thread to finish
        if self._main_thread and self._main_thread.is_alive():
            self._main_thread.join(timeout=5.0)

        # Shut down the thread pool
        self.executor.shutdown(wait=True)

        print("Simulation stopped")
        
    def _simulation_loop(self):
        """Main simulation loop."""
        last_log_time = 0.0
        last_topology_update = 0.0
        last_task_generation = 0.0

        while not self._stop_event.is_set() and self.current_time < self.config.simulation_duration:
            loop_start = time.time()

            # Update simulation time
            self.current_time = time.time() - self.simulation_start_time
            self.stats.simulation_time = self.current_time

            # Simulate drone movement
            self.spatial_manager.simulate_movement(self.config.time_step)

            # Periodically update the network topology
            if self.current_time - last_topology_update >= self.config.topology_update_interval:
                changes = self.spatial_manager.update_topology()
                self.stats.topology_changes += changes
                last_topology_update = self.current_time

            # Periodically generate tasks
            if (self.config.enable_task_generation and
                self.current_time - last_task_generation >= self.config.task_generation_interval):
                self._generate_and_distribute_tasks()
                last_task_generation = self.current_time

            # Record trajectory data
            if self.config.save_trajectory:
                self._record_trajectory()

            # Periodically output logs
            if self.current_time - last_log_time >= self.config.log_interval:
                self._log_progress()
                last_log_time = self.current_time

            # Control simulation speed
            loop_duration = time.time() - loop_start
            sleep_time = max(0, self.config.time_step - loop_duration)
            if sleep_time > 0:
                time.sleep(sleep_time)

        # Simulation complete
        self._finalize_simulation()

    def _generate_and_distribute_tasks(self):
        """Generate and distribute tasks."""
        try:
            # Generate tasks for each active drone
            active_drones = self.spatial_manager.get_all_active_drones()

            for drone_id in active_drones:
                # Generate tasks (hierarchical arrival process)
                drone_state = self.spatial_manager.get_drone_state(drone_id)
                if drone_state:
                    tasks = self.task_generator.generate_tasks(
                        self.config.task_generation_interval,
                        self.current_time,
                        drone_state.position
                    )
                else:
                    tasks = []

                # Distribute tasks to the corresponding drone
                drone_simulator = self.drone_simulators.get(drone_id)
                if drone_simulator:
                    for task in tasks:
                        success = drone_simulator.add_task(task)
                        if success:
                            self.stats.tasks_generated += 1
                            self.stats.priority_stats[task.priority]["generated"] += 1
                        else:
                            print(f"Task queue full, dropping task: {task.id}")

        except Exception as e:
            print(f"Task generation failed: {e}")

    def _update_task_completion(self, task, success: bool, processing_time: float):
        """Update task completion statistics."""
        if success:
            self.stats.tasks_completed += 1
            self.stats.priority_stats[task.priority]["completed"] += 1
        else:
            self.stats.tasks_failed += 1
            self.stats.priority_stats[task.priority]["failed"] += 1

        # Update average latency
        if success and processing_time > 0:
            total_latency = self.stats.average_task_latency * max(1, self.stats.tasks_completed - 1)
            self.stats.average_task_latency = (total_latency + processing_time) / self.stats.tasks_completed

    def _record_trajectory(self):
        """Record trajectory data."""
        trajectory_point = {
            "time": self.current_time,
            "drones": {}
        }
        
        for drone_id in self.drone_simulators.keys():
            drone_state = self.spatial_manager.get_drone_state(drone_id)
            drone_status = self.drone_simulators[drone_id].get_status()
            
            if drone_state:
                trajectory_point["drones"][drone_id] = {
                    "position": drone_state.position,
                    "velocity": drone_state.velocity,
                    "battery": drone_state.battery_level,
                    "load": drone_status["current_load"],
                    "queue_size": drone_status["queue_size"]
                }
                
        self.trajectory_data.append(trajectory_point)

    def _log_progress(self):
        """Output simulation progress."""
        # Compute system statistics
        spatial_stats = self.spatial_manager.get_spatial_statistics()
        self.stats.average_neighbors = spatial_stats.get("average_neighbors", 0.0)
        self.stats.network_connectivity = spatial_stats.get("network_connectivity", 0.0)

        # Compute throughput
        if self.current_time > 0:
            self.stats.system_throughput = self.stats.tasks_completed / self.current_time

        # Compute load balance index
        loads = [sim.current_load for sim in self.drone_simulators.values()]
        if loads:
            mean_load = np.mean(loads)
            load_variance = np.var(loads)
            self.stats.load_balance_index = 1.0 - (load_variance / max(0.01, mean_load))

        print(f"Time: {self.current_time:.1f}s | "
              f"Completed tasks: {self.stats.tasks_completed} | "
              f"Collaboration success rate: {self._get_collaboration_success_rate():.1%} | "
              f"System throughput: {self.stats.system_throughput:.2f} tasks/s | "
              f"Average neighbors: {self.stats.average_neighbors:.1f}")

    def _get_collaboration_success_rate(self) -> float:
        """Get the collaboration success rate."""
        if self.stats.collaboration_attempts == 0:
            return 0.0
        return self.stats.successful_collaborations / self.stats.collaboration_attempts

    def _finalize_simulation(self):
        """Finalize the simulation and generate a report."""
        print("\n" + "=" * 60)
        print("Simulation complete!")
        print("=" * 60)

        # Save results
        if self.config.save_statistics:
            self._save_simulation_results()

        # Print final statistics
        self._print_final_statistics()

    def _save_simulation_results(self):
        """Save simulation results."""
        try:
            import os
            os.makedirs(self.config.output_directory, exist_ok=True)

            # Save statistics data
            stats_file = os.path.join(self.config.output_directory, "simulation_stats.json")
            stats_dict = {
                "simulation_time": self.stats.simulation_time,
                "total_drones": self.stats.total_drones,
                "tasks_generated": self.stats.tasks_generated,
                "tasks_completed": self.stats.tasks_completed,
                "tasks_failed": self.stats.tasks_failed,
                "priority_stats": self.stats.priority_stats,
                "collaboration_attempts": self.stats.collaboration_attempts,
                "successful_collaborations": self.stats.successful_collaborations,
                "average_task_latency": self.stats.average_task_latency,
                "system_throughput": self.stats.system_throughput,
                "load_balance_index": self.stats.load_balance_index,
                "topology_changes": self.stats.topology_changes,
                "average_neighbors": self.stats.average_neighbors,
                "network_connectivity": self.stats.network_connectivity
            }
            
            with open(stats_file, 'w', encoding='utf-8') as f:
                json.dump(stats_dict, f, indent=2, ensure_ascii=False)

            # Save trajectory data
            if self.config.save_trajectory and self.trajectory_data:
                trajectory_file = os.path.join(self.config.output_directory, "trajectory_data.json")
                with open(trajectory_file, 'w', encoding='utf-8') as f:
                    json.dump(self.trajectory_data, f, indent=2, ensure_ascii=False)

            print(f"Simulation results saved to: {self.config.output_directory}")

        except Exception as e:
            print(f"Failed to save results: {e}")

    def _print_final_statistics(self):
        """Print final statistics."""
        print("\nFinal statistics:")
        print("-" * 40)
        print(f"Simulation duration: {self.stats.simulation_time:.1f}s")
        print(f"Number of drones: {self.stats.total_drones}")
        print(f"Tasks generated: {self.stats.tasks_generated}")
        print(f"Tasks completed: {self.stats.tasks_completed}")
        print(f"Tasks failed: {self.stats.tasks_failed}")
        print(f"Task completion rate: {self.stats.tasks_completed / max(1, self.stats.tasks_generated):.1%}")
        print(f"Collaboration attempts: {self.stats.collaboration_attempts}")
        print(f"Successful collaborations: {self.stats.successful_collaborations}")
        print(f"Collaboration success rate: {self._get_collaboration_success_rate():.1%}")
        print(f"Average task latency: {self.stats.average_task_latency:.3f}s")
        print(f"System throughput: {self.stats.system_throughput:.2f} tasks/s")
        print(f"Load balance index: {self.stats.load_balance_index:.3f}")
        print(f"Number of topology changes: {self.stats.topology_changes}")
        print(f"Average neighbors: {self.stats.average_neighbors:.1f}")
        print(f"Network connectivity: {self.stats.network_connectivity:.3f}")

        print("\nStatistics by priority:")
        for priority in [3, 2, 1, 0]:
            stats = self.stats.priority_stats[priority]
            priority_name = ["Background", "Low", "Medium", "High"][priority]
            print(f"  {priority_name} priority: generated {stats['generated']}, completed {stats['completed']}, failed {stats['failed']}")

    def get_current_statistics(self) -> SimulationStatistics:
        """Get current statistics."""
        return self.stats

    def get_drone_status_all(self) -> Dict[str, Dict]:
        """Get the status of all drones."""
        return {drone_id: sim.get_status()
                for drone_id, sim in self.drone_simulators.items()}


if __name__ == "__main__":
    # Test the drone swarm simulator
    print("Testing drone swarm simulator...")
    print("=" * 70)

    # Create simulation configuration
    config = SwarmConfiguration(
        area_bounds=((-400, -400), (400, 400)),
        simulation_duration=60.0,  # 60-second simulation
        time_step=0.1,
        save_trajectory=True,
        save_statistics=True,
        output_directory="./test_simulation_results"
    )

    # Create the simulator
    simulator = SwarmSimulator(config)

    # Add test drones
    drone_configs = [
        DroneConfiguration("CenterDrone", (0, 0), MovementPattern.STATIONARY),
        DroneConfiguration("MobileDrone1", (100, 100), MovementPattern.RANDOM_WALK),
        DroneConfiguration("MobileDrone2", (-100, 100), MovementPattern.CIRCULAR),
        DroneConfiguration("PatrolDrone", (0, 200), MovementPattern.LINEAR),
        DroneConfiguration("EdgeDrone", (300, 200), MovementPattern.RANDOM_WALK),
    ]
    
    print("Adding drones to the swarm:")
    for drone_config in drone_configs:
        success = simulator.add_drone(drone_config)
        print(f"  {drone_config.drone_id}: {'Success' if success else 'Failed'}")

    print()

    try:
        # Start the simulation
        simulator.start_simulation()

        # Let the simulation run
        time.sleep(config.simulation_duration + 5)

    except KeyboardInterrupt:
        print("\nUser interrupted the simulation")

    finally:
        # Stop the simulation
        simulator.stop_simulation()

    print("\nTest complete!")