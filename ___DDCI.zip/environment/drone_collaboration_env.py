"""
Gymnasium environment for decentralized UAV collaborative inference.

Implements the mathematical model from the redesign spec (redesign_spec):
- State space: s_i(t) in R^{6+3K} = [self state 6-dim, K neighbor states (each [distance, load, compute])]
- Action space: Discrete(K*9+1); the first K*9 are collaboration (partner*layer), the last is explicit local processing a_local
- Reward function (deadline version): R = w_p*r_comp - alpha*l_deadline - beta_E*E - beta_C*c_comm
"""

import gymnasium as gym
from gymnasium import spaces
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
import random
import sys
import os

# Add code path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from tasks import HierarchicalTaskQueue, Task, TaskPriority, TaskType, TaskGenerator
from models import ResNetPartitioner
from models.minibatch_pipeline_engine import MiniBatchPipelineEngine
from models.resnet_partitioner import ResNetLayer
from models.configurable_partitioner import create_partitioner, NetworkType
from communication import CommunicationEngine
from environment.spatial_manager import SpatialManager
from environment.signal_attenuation import create_default_wifi_model, SignalAttenuationModel
from environment.pareto_neighbor_selection import ParetoNeighborSelector, NeighborCandidate
from environment.energy_model import DroneEnergyModel, DroneEnergyManager, DroneEnergyConfig
from utils import PerformanceCalculator, SystemMetrics
from utils.unified_latency_calculator import UnifiedLatencyCalculator
from config import ConfigManager


@dataclass
class DroneObservation:
    """
    UAV observation state V3.

    Observation space: 15-dim (K=3)
    - Self state (6-dim)
    - Neighbor state (9-dim = 3 neighbors * 3 features)

    Neighbor features: [distance, load, compute] (consistent with the three Pareto objectives; distance is included for energy-aware decisions)

    Decision logic:
    - 0 neighbors: process locally directly
    - 1-2 neighbors: greedy strategy
    - >=3 neighbors: DRL decision after Pareto filtering
    """
    # Self state (7-dim)
    flops_norm: float          # Normalized FLOPs demand of the current task [0,1]
    queue_load: float          # Queue load rate [0,1] (based on backlog FLOPs, see Eq. 4)
    busy_rate: float           # Busy rate [0,1]
    task_priority_norm: float  # Normalized task priority [0,1]
    deadline_urgency: float    # Deadline urgency [0,1]
    self_capacity_norm: float  # Normalized self compute capability (FLOPS) [0,1]
    battery_pct: float         # Own remaining battery ratio [0,1] (energy-aware decision, R1.6/R3.11)

    # K neighbor states (K*3 matrix, flattened to 3K-dim): each neighbor [distance, load, compute]
    neighbor_distances: List[float]   # Normalized distances of K neighbors [0,1] (d/R_comm)
    neighbor_loads: List[float]       # Load rates of K neighbors [0,1]
    neighbor_capacities: List[float]  # Normalized compute capability (FLOPS) of K neighbors [0,1]

    def to_array(self) -> np.ndarray:
        """Convert to a numpy array for the Gymnasium environment."""
        self_state = [
            self.flops_norm,
            self.queue_load,
            self.busy_rate,
            self.task_priority_norm,
            self.deadline_urgency,
            self.self_capacity_norm,
            self.battery_pct
        ]
        neighbor_state = []

        # Interleave each neighbor's [distance, load, compute] (order consistent with the three Pareto objectives)
        for i in range(len(self.neighbor_distances)):
            neighbor_state.extend([
                self.neighbor_distances[i],
                self.neighbor_loads[i],
                self.neighbor_capacities[i]
            ])

        return np.array(self_state + neighbor_state, dtype=np.float32)


@dataclass
class CollaborationAction:
    """
    Collaboration action.
    Based on CLAUDE.md: (partner_idx, layer_cut)
    """
    partner_idx: int    # Collaboration partner index [0, K-1]
    layer_cut: int      # Partition point [1, 7]

    @classmethod
    def from_discrete(cls, action: int, k: int = 3) -> 'CollaborationAction':
        """
        Convert from a discrete action (action space = k*9 + 1)

        Action mapping:
        - action in [0, k*9-1]: collaborative processing
          - partner_idx = action // 9 in [0, k-1]
          - layer_idx   = action % 9  in [0, 8]
        - action = k*9: explicit local processing a_local
          - partner_idx = k (out-of-range marker -> local)
          - layer_idx   = 0
        """
        if action < k * 9:
            # Collaborative processing
            partner_idx = action // 9
            layer_cut = action % 9       # 0-8 (abstract layer index, later mapped via layer_mapper)
        else:
            # Explicit local processing: action = k*9
            partner_idx = k
            layer_cut = 0

        return cls(partner_idx, layer_cut)

    @classmethod
    def from_hierarchical(cls, action: tuple) -> 'CollaborationAction':
        """
        Convert from a hierarchical action (tuple format)

        Args:
            action: (partner_idx, layer_cut)
                - partner_idx: 0-3 (0=local, 1-3=neighbor)
                - layer_cut: 0-8 (0=full offload, 8=fully local)

        Returns:
            CollaborationAction instance
        """
        partner_idx, layer_cut = action
        # Note: the hierarchical DQN layer_cut is 0-8; it needs conversion to 1-8 (or special handling of 0)
        # layer_cut=0 means full offload; here it is mapped to layer_cut=1 (minimum local processing)
        # Actually it should stay 0-8 and be handled by later code
        if layer_cut == 0:
            # Full offload: can use layer_cut=0 or a special marker
            # Here we keep 0; later code must support it
            actual_layer_cut = 0
        else:
            actual_layer_cut = layer_cut
        return cls(partner_idx, actual_layer_cut)

    def to_discrete(self, k: int = 3) -> int:
        """Convert to a discrete action."""
        return self.partner_idx * 9 + (self.layer_cut - 1)


class DroneCollaborationEnv(gym.Env):
    """
    Gymnasium environment for decentralized UAV collaborative inference.

    This environment simulates the decision process of a single UAV:
    - Observation: self state + K neighbor states
    - Action: select a collaboration partner and a partition point
    - Reward: based on completed-task gains and communication cost
    """
    
    metadata = {'render_modes': ['human', 'rgb_array']}
    
    def __init__(self,
                 config_manager: ConfigManager = None,
                 num_drones: int = 10,
                 k_neighbors: int = 3,
                 simulation_time: float = 30.0,
                 render_mode: Optional[str] = None,
                 enable_pipeline: bool = True,
                 network_type: str = 'resnet-8',  # Added: network type, default resnet-8 for backward compatibility
                 fifo_mode: bool = False,  # FIFO ablation: enable FIFO scheduling mode
                 enable_preemption: bool = True,  # Preemption ablation: enable preemption mechanism
                 bandwidth_mbps: float = 400.0,  # 5GHz WiFi 802.11ac nominal PHY rate (R1.4 realism)
                 communication_radius: float = 200.0,  # Communication-range experiment: configurable communication radius (meters)
                 task_rate_multiplier: float = 1.0,  # Task-arrival-rate experiment: task generation rate multiplier
                 ablate_priority: bool = False,  # State-feature ablation: when True, priority+deadline_urgency in observation are zeroed
                 ablate_deadline_urgency: bool = False,  # Zero only the deadline_urgency state feature (ablated separately from priority)
                 ablate_reward_priority: bool = False,  # Reward-component ablation: when True, reward priority weight w_p is fixed to 1 (no weighting for high priority)
                 ablate_priority_arbitration: bool = False,  # Mechanism ablation: when True, partner acceptance ignores priority (HIGH no longer prioritizes fast partners)
                 enable_recovery: bool = True,  # Link-interruption recovery state machine (migration + fallback); when False, an interruption is judged a failure directly (ablation)
                 ablate_pareto: bool = False,  # Pareto ablation: when True, K neighbors are chosen randomly (instead of Pareto-optimal)
                 enable_partner_refusal: bool = True,  # Partner accept/refuse decision; when False, degenerates to unconditional acceptance (ablation)
                 accept_load_thresh: float = 0.9,  # Refuse collaboration if partner load rate exceeds this value
                 accept_batt_thresh: float = 0.1,  # Refuse collaboration if partner battery is below this value (self-preservation)
                 max_contention_links: float = 4.0,  # Upper bound on the shared-channel contention factor (limited effective contenders under spatial reuse)
                 battery_capacity_wh: float = 100.0,  # Battery capacity (Wh); default 100 for backward compatibility, can be lowered for stress tests
                 capacity_levels: list = None,  # Heterogeneity experiment: custom compute levels (FLOPS); None = default levels
                 reward_coeffs: dict = None):  # Reward coefficients (support sensitivity analysis; None = paper default values)

        super().__init__()

        # Reward coefficient vector (defaults are the paper's final values; passing a dict enables sensitivity sweeps)
        _default_coeffs = {'R_BASE': 10.0, 'ALPHA': 3.0, 'BETA_E': 1.0,
                           'BETA_C': 0.3, 'D_REF': 10.0, 'E_REF': 2.37e-3,
                           'SPEEDUP_CAP': 5.0}  # Completion-reward speedup upper bound (bounded)
        if reward_coeffs:
            _default_coeffs.update(reward_coeffs)
        self.reward_coeffs = _default_coeffs

        # Basic parameters
        self.num_drones = num_drones
        self.k_neighbors = k_neighbors
        self.simulation_time = simulation_time
        self.render_mode = render_mode
        self.enable_pipeline = enable_pipeline  # Controls whether to use pipeline parallelism
        self.network_type = network_type.lower()  # Store network type (normalized to lowercase)
        self.fifo_mode = fifo_mode  # FIFO ablation: True=FIFO scheduling, False=priority scheduling
        self.enable_preemption = enable_preemption  # Preemption ablation: True=enable preemption, False=disable preemption
        self.bandwidth_mbps = bandwidth_mbps  # Bandwidth experiment: configurable bandwidth
        self.communication_radius = communication_radius  # Communication-range experiment: configurable communication radius
        self.task_rate_multiplier = task_rate_multiplier  # Task-arrival-rate experiment: task generation rate multiplier
        self.ablate_priority = ablate_priority  # State-feature ablation
        self.ablate_deadline_urgency = ablate_deadline_urgency  # Ablate deadline_urgency separately
        self.ablate_reward_priority = ablate_reward_priority  # Reward-component ablation
        self.ablate_priority_arbitration = ablate_priority_arbitration  # Mechanism ablation: priority arbitration
        self.enable_recovery = enable_recovery  # Recovery state machine switch
        self.eval_deterministic = False  # Set True during evaluation -> background UAVs also disable exploration (kept False during training)
        self.ablate_pareto = ablate_pareto  # Pareto ablation: random K-neighbor selection
        self.enable_partner_refusal = enable_partner_refusal  # Partner accept/refuse
        self.accept_load_thresh = accept_load_thresh  # Refusal load threshold
        self.accept_batt_thresh = accept_batt_thresh  # Refusal battery threshold
        self.max_contention_links = max_contention_links  # Contention factor upper bound

        # Parameter-sharing multi-agent DRL support
        self.shared_drl_model = None
        self.baseline_mode = False  # Scheme Y: baseline uses neither Pareto nor naive partitioning

        # Partner reward storage (fixes the issue of partners receiving no reward)
        self.pending_partner_rewards: Dict[str, float] = {}

        # Heterogeneous processing capability (each drone has a different processing rate, FLOPS)
        # x40 aligned with real Jetson: discrete levels [160,320,400,600,800] GFLOPS (see _init_components)
        np.random.seed(42)  # Fixed random seed for reproducibility
        self.drone_capacities: Dict[str, float] = {}

        # Load configuration
        if config_manager is None:
            config_manager = ConfigManager()
        self._load_configs(config_manager)

        # Initialize network config and layer mapping
        self._init_network_config()

        # Define state space and action space
        self._define_spaces()

        # Real same-source data: take each layer's output data size (MB) and per-layer FLOPs for pipeline latency modeling
        layer_data_mb = [s.data_size_bytes / (1024 * 1024) for s in self.model_partitioner.layer_specs]
        layer_flops = [s.flops for s in self.model_partitioner.layer_specs]

        # Create a bandwidth-configurable latency calculator (pipeline layer partitioning, real layer data)
        self.latency_calculator = UnifiedLatencyCalculator(
            bandwidth_mbps=self.bandwidth_mbps,
            total_layers=self.num_layers,
            layer_data_mb=layer_data_mb,
            layer_flops=layer_flops
        )

        # Signal attenuation model (5GHz 802.11ac, consistent with the paper/latency calculator)
        # Note: actual communication latency is computed by self.latency_calculator.signal_model; this instance is only for diagnostics/external queries
        self.signal_attenuation_model = SignalAttenuationModel(
            frequency_ghz=5.0,
            nominal_bandwidth_mbps=self.bandwidth_mbps,
            enable_realism=True,
        )
        print(f"[ENV] Signal attenuation model enabled (WiFi 802.11ac, 5GHz)")

        # Create the Pareto neighbor selector (multi-objective optimization: distance vs load)
        self.pareto_selector = ParetoNeighborSelector(k=self.k_neighbors)
        print(f"[ENV] Pareto neighbor selection enabled (k={self.k_neighbors})")

        # Create the energy manager
        self.battery_capacity_wh = battery_capacity_wh  # Configurable (for stress tests)
        self._custom_capacity_levels = capacity_levels  # Heterogeneity experiment: custom compute levels
        self.oracle_mode = False  # Upper-bound experiment: when True the controlling drone enumerates task-level analytic optima for cut/partner (off by default, zero impact)
        self.energy_manager = DroneEnergyManager(num_drones=self.num_drones, battery_capacity_wh=battery_capacity_wh)
        self.energy_model = DroneEnergyModel()
        print(f"[ENV] Energy model enabled (battery={battery_capacity_wh}Wh)")

        # Initialize system components
        self._init_components()

        # Environment state
        self.current_time = 0.0
        self.current_drone_id = "drone_0"  # Currently controlled UAV
        self.episode_step = 0
        self.max_episode_steps = 1000  # Set a large default to avoid conflicts with external settings


        # Performance statistics
        self.episode_stats = {
            "tasks_completed": 0,
            "collaborative_tasks": 0,
            "independent_tasks": 0,
            "total_reward": 0.0,
            "total_latency": 0.0,
            "total_comm_cost": 0.0,
            "total_flops": 0.0  # Cumulative completed FLOPs
        }

    def _load_configs(self, config_manager: ConfigManager):
        """Load configuration."""
        self.sim_config = config_manager.load_config("simulation", "default")
        self.swarm_config = config_manager.load_config("drone_swarm", "default")
        self.task_config = config_manager.load_config("task_generation", "default")
        self.collab_config = config_manager.load_config("collaboration", "default")
        self.drl_config = config_manager.load_config("drl", "default")

        # Ensure configuration consistency
        self.swarm_config.num_drones = self.num_drones
        self.k_neighbors = min(self.k_neighbors, self.num_drones - 1)

    def _init_network_config(self):
        """
        Initialize network config and layer mapping.

        Create the corresponding model partitioner based on network_type, and initialize the action-layer to actual-layer mapping function.
        """
        # Create the ConfigurableModelPartitioner (used for FLOPs calculation)
        self.model_partitioner = create_partitioner(self.network_type)

        # Get network info
        model_info = self.model_partitioner.get_model_info()
        self.num_layers = model_info['num_layers']
        self.total_flops = model_info['total_flops']

        # Main table: per-network scaling factor for batch M, so the primary networks' "local processing time magnitude" falls in a range where collaboration is worthwhile.
        # Design intent (consistent with the paper):
        #   - vgg-16(15.5G)/vgg-19(19.6G): heavy enough compute, m_scale=1.0 (baseline).
        #   - yolov5m(12.4G): slightly lighter, m_scale=1.5 makes local time comparable to VGG, so collaboration speedup can translate into satisfaction rate.
        #   - googlenet-22(1.64G): **intentionally kept as a negative case** -- an extremely light network is instantly solved locally (t_local~0.07s),
        #     collaboration communication overhead > local computation, DDCI ~= local. This is an honest negative result, showing the applicability boundary of collaboration,
        #     and responds to the reviewer's question about googlenet performance (C21). Hence m_scale=1.0 (no forced collaboration value).
        _M_SCALE_BY_NET = {
            'vgg-16': 1.0, 'vgg-19': 1.0,
            'yolov5m': 1.5, 'yolov5s': 1.5,
            'googlenet-22': 1.0, 'resnet-8': 1.0,
        }
        self.m_scale = _M_SCALE_BY_NET.get(self.network_type, 1.0)

        # Layer mapping function: map the 9 abstract action-layer indices {0..8} to valid partition points {1, ..., L-1}
        # (fix R3.6: the old int(x*L/8) produced out-of-range partition points cut=0 or cut=L,
        #  and for deep networks could not reach the highest valid partition point L-1)
        # Layer mapping: 9 action levels map to "reasonable partition points" (low-data layers = pooling boundaries / bottleneck layers)
        # Fix: VGG feature maps are non-monotonic (doubling conv channels makes middle layers larger); if actions map linearly to arbitrary layers,
        # it may cut at a large feature-map layer and cause a communication blowup. Changed to select only among low-data candidate layers, consistent with collaborative inference practice
        # (Neurosurgeon etc. all cut at bottleneck layers), and let DRL pick partner / cut depth among the good options.
        L = self.num_layers
        self.max_action_layers = 8
        if L <= 2:
            self.layer_mapper = lambda x: 1
        else:
            # Candidate partition layers: customized per network (each network uses its best-suited partition-point set, ensuring the partition choice has range and avoids pitfalls)
            # VGG series: feature maps decrease monotonically; use 4 layers spanning shallow->deep (including a shallow layer with a large feature map, giving DRL room to "avoid bad layers")
            # YOLOv5m: FPN structure has non-monotonic feature maps; use only low-data good layers (avoid neck upsampling bad points)
            specs = self.model_partitioner.layer_specs
            data_mb = [s.data_size_bytes/(1024*1024) for s in specs]

            if self.network_type in ['vgg-16', 'VGG-16']:
                cand = [4, 7, 10, 13]  # 1.53/0.77/0.38/0.10 MB, wide range -> DRL dynamic partitioning is valuable
            elif self.network_type in ['vgg-19', 'VGG-19']:
                cand = [8, 12, 16]  # 0.77/0.38/0.10MB, 3 good layers -> baseline cuts middle (12), DRL learns to cut deepest (16)
            elif self.network_type in ['yolov5m', 'YOLOv5m', 'yolov5s']:
                cand = [4, 5, 9, 11]   # 0.57/0.57/0.57/0.19 MB, avoid layer 7 (1.15MB bad point)
            elif self.network_type in ['googlenet-22', 'GoogLeNet-22']:
                cand = [5, 10, 15, 20]  # evenly cover the 22 layers
            elif self.network_type in ['resnext-101', 'ResNeXt-101', 'resnext']:
                cand = [4, 6, 8, 13]  # 18 units: includes the optimal region (cut 6-8 bottleneck 262ms / 60% speedup), spanning shallow->deep
            else:
                # Generic: 4 points evenly spaced by layer order
                cand = sorted(set(max(1, min(L-1, int(round(i*(L-1)/4)))) for i in range(1,5)))

            # Safety check: ensure no out-of-range values
            cand = [c for c in cand if 1 <= c < L]
            if len(cand) < 2:
                cand = [max(1, L//3), max(1, 2*L//3)]
            self._cut_candidates = cand
            def _map(x, cand=cand):
                idx = int(np.clip(round(x * (len(cand) - 1) / 8), 0, len(cand) - 1))
                return cand[idx]
            self.layer_mapper = _map

        # Print configuration info
        print(f"[ENV] Network Type: {self.network_type}")
        print(f"      Actual Layers: {self.num_layers}")
        print(f"      Total FLOPs: {model_info['total_flops_gflops']:.2f} GFLOPs")
        print(f"      Action Space: 0-8 -> Actual: 0-{self.num_layers}")

    def _define_spaces(self):
        """Define the state space and action space."""
        # State space: 15-dim (K=3)
        # Self state (6-dim) + neighbor state (3K-dim = 3 neighbors * 3 features)
        # Neighbor features: [distance, load, compute] (consistent with the three Pareto objectives)
        state_dim = 7 + 3 * self.k_neighbors  # 7 + 3*3 = 16
        self.observation_space = spaces.Box(
            low=0.0,
            high=1.0,
            shape=(state_dim,),
            dtype=np.float32
        )

        # Action space: K * 9 + 1 = 28 (K=3) discrete actions
        # The first K*9 are collaboration actions (partner_idx * layer_idx); the last is explicit local processing a_local
        total_actions = self.k_neighbors * 9 + 1
        self.action_space = spaces.Discrete(total_actions)

    def _init_components(self):
        """Initialize system components."""
        # Generate UAV configs
        if not self.swarm_config.individual_configs:
            self.swarm_config.generate_individual_configs()

        # Initialize components
        self.task_queues = {}
        self.task_generators = {}
        self.model_partitioners = {}
        self.pipeline_engines = {}

        # Spatial manager
        self.spatial_manager = SpatialManager(config=None)  # Use default config

        # Communication calculator
        self.comm_calculator = CommunicationEngine()

        # Performance calculator
        self.performance_calc = PerformanceCalculator()

        # Initialize components for each UAV
        for i, drone_config in enumerate(self.swarm_config.individual_configs):
            drone_id = drone_config.drone_id

            # Initialize position
            x, y = drone_config.initial_position
            self.spatial_manager.register_drone(drone_id, (x, y), comm_radius=self.communication_radius)

            # Heterogeneous processing capability (x40 aligned with real Jetson embedded GPUs, R2.2):
            # The old [4,8,10,15,20]G deviated from real hardware; after x40 it spans the Jetson Nano (472 GFLOPS) ~ TX2 range
            # drone_0~1:160G(weak), drone_2~3:320G, drone_4:400G, drone_5~7:600G, drone_8~9:800G(strong)
            # Unit: FLOPS (floating-point operations/second, a rate)
            capacity_levels = self._custom_capacity_levels or \
                [160e9, 160e9, 320e9, 320e9, 400e9, 600e9, 600e9, 600e9, 800e9, 800e9]
            self.drone_capacities[drone_id] = capacity_levels[i % len(capacity_levels)]

            # Task-related components
            self.task_queues[drone_id] = HierarchicalTaskQueue(drone_id, fifo_mode=self.fifo_mode, enable_preemption=self.enable_preemption)
            self.task_generators[drone_id] = TaskGenerator()

            # Model processing components
            self.model_partitioners[drone_id] = ResNetPartitioner()
            self.pipeline_engines[drone_id] = MiniBatchPipelineEngine()

    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None) -> Tuple[np.ndarray, dict]:
        """Reset the environment."""
        super().reset(seed=seed)

        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)

        # Rotate the controlling drone (training experience covers all compute levels, rather than always learning from the weakest drone_0's viewpoint)
        # Fix: previously current_drone_id was fixed to drone_0 (160G), so DRL only learned "weak nodes always collaborate",
        # and could not learn "strong nodes should fall back to local" -> at evaluation, strong nodes blindly collaborate and drag down performance.
        drone_list = sorted(self.task_queues.keys()) if self.task_queues else [f"drone_{i}" for i in range(self.num_drones)]
        self._reset_count = getattr(self, '_reset_count', -1) + 1
        self.current_drone_id = drone_list[self._reset_count % len(drone_list)]

        # Reset environment state
        self.current_time = 0.0
        self.episode_step = 0


        # Reset statistics
        self.episode_stats = {
            "tasks_completed": 0,
            "collaborative_tasks": 0,
            "independent_tasks": 0,
            "total_reward": 0.0,
            "total_latency": 0.0,
            "total_comm_cost": 0.0,
            "total_flops": 0.0,
            "total_energy": 0.0,  # Cumulative energy consumption (Wh)
            "idle_energy": 0.0,  # Cumulative idle base power (Wh)
            "control_overhead_bytes": 0.0,  # Cumulative control-channel overhead bytes (neighbor discovery + load exchange, R1.7)
            "control_overhead_energy": 0.0,  # Control-channel overhead energy (Wh, R1.7)
            "deadline_violations": 0,  # Deadline violation count (completed but late)
            "deadline_met": 0,  # Deadline met count (completed and on time)
            "tasks_generated": 0,  # Total tasks generated (arrived tasks, basis for the C1 satisfaction-rate denominator)
            "tasks_expired": 0,  # Number of tasks dropped for timing out in the pending queue (drop, reported separately in C1)
            "tasks_failed": 0,  # Number of tasks unrecoverable after collaboration-link failure (failure, reported separately in C1)
            "link_fallbacks": 0,  # Number of successful local/reroute rescues after a link interruption
            "collab_refused": 0,  # Number of collaboration requests refused by partners
            "battery_violations": 0,  # Battery-depletion violation count (consume_energy returns False)
            "batch_latencies": [],  # End-to-end latency (s) of each collaboration batch, used to report the latency distribution
            "link_migrations": 0,  # Number of migrations to a backup neighbor after a link interruption
            "link_interruptions": 0,  # Number of link-interruption detections
        }

        # Clear task queues
        for queue in self.task_queues.values():
            # Clear the queue (reset for new episode)
            queue.priority_queues = {p: [] for p in TaskPriority}
            queue.processing_tasks = []
            queue.completed_tasks = []

        # Reset the performance calculator
        self.performance_calc = PerformanceCalculator()
        self.performance_calc.start_measurement()

        # Reset the energy manager
        self.energy_manager.reset()

        # Reset the balanced-selection counters (fixes random-selection bias)
        self._baseline_selection_counts = {}

        # Fix: remove pre-filling to avoid an inflated reward in the first episode
        # Let all episodes start from the same empty-queue state
        self._generate_tasks()  # Generate only 1 round, simulating normal task arrivals

        # Get the initial observation
        observation = self._get_observation()
        info = self._get_info()

        return observation.to_array(), info

    def _cleanup_completed_processing_tasks(self):
        """Clean up completed processing_tasks of the currently controlled drone to prevent queue congestion."""
        # **Important fix: only clean up the currently controlled drone to avoid multiple rewards**
        drone_id = self.current_drone_id
        queue = self.task_queues[drone_id]

        # Find timed-out processing_tasks and mark them complete
        to_complete = []
        for entry in queue.processing_tasks:
            # A task is considered complete at most 0.2 seconds after it starts
            if hasattr(entry, 'start_time') and entry.start_time is not None:
                expected_completion = entry.start_time + 0.2
                if self.current_time >= expected_completion:
                    to_complete.append(entry.task.id)
            else:
                # If there is no start_time, clean up directly (possibly a leftover task)
                to_complete.append(entry.task.id)

        # **Silent cleanup: produces no extra reward**
        for task_id in to_complete:
            queue.complete_task(task_id, self.current_time)

    def step(self, action) -> Tuple[np.ndarray, float, bool, bool, dict]:
        """
        Execute one action step. **Parameter-sharing multi-agent DRL mode**.

        Args:
            action: can be one of the following formats:
                - int: discrete action (0-26)
                - tuple: hierarchical action (partner_idx, layer_cut)
        """
        # Parse the controlling drone's action (auto-detect action type)
        if isinstance(action, (tuple, list)):
            # Hierarchical action: (partner_idx, layer_cut)
            main_drl_action = CollaborationAction.from_hierarchical(action)
        else:
            # Discrete action: integer
            main_drl_action = CollaborationAction.from_discrete(action, self.k_neighbors)

        # **Sequential execution: all drones use DRL decisions, executed in order to ensure state updates**
        drone_ids = sorted(self.task_queues.keys())  # Fixed execution order

        # Collect only the current drone's reward (fixes the reward-attribution issue)
        current_drone_reward = 0.0

        for i, drone_id in enumerate(drone_ids):
            if drone_id == self.current_drone_id:
                # The controlling drone uses the passed-in action
                immediate_reward = self._execute_drone_action(drone_id, main_drl_action)
                current_drone_reward = immediate_reward  # As the requester's reward
            else:
                # Other drones must independently obtain observations and decide
                drone_obs = self._get_observation_for_drone(drone_id)

                # Use the shared DRL network to decide (parameter sharing)
                if self.shared_drl_model is not None:
                    try:
                        # Use the shared DRL model to predict the action
                        # During evaluation (eval_deterministic=True) background UAVs also disable exploration,
                        # so the "exploration-off greedy policy" claim holds for the whole swarm (not just the controlled agent); exploration is kept during training.
                        obs_array = drone_obs.to_array()
                        drl_action_int, _ = self.shared_drl_model.predict(
                            obs_array, deterministic=self.eval_deterministic)
                        drl_action_int = int(drl_action_int)
                        drone_drl_action = CollaborationAction.from_discrete(drl_action_int, self.k_neighbors)
                        self._execute_drone_action(drone_id, drone_drl_action)  # Does not accumulate reward
                    except Exception as e:
                        # If DRL prediction fails, fall back to baseline
                        baseline_action = self._generate_baseline_action(drone_id)
                        self._execute_drone_action(drone_id, baseline_action)  # Does not accumulate reward
                else:
                    # Use baseline when the DRL model is not yet set at the start of training
                    baseline_action = self._generate_baseline_action(drone_id)
                    self._execute_drone_action(drone_id, baseline_action)  # Does not accumulate reward

        # Add the reward the current drone earned as a collaboration partner
        if self.current_drone_id in self.pending_partner_rewards:
            partner_reward = self.pending_partner_rewards[self.current_drone_id]
            current_drone_reward += partner_reward
            # Clear the assigned reward
            del self.pending_partner_rewards[self.current_drone_id]

        # Update environment state
        step_dt = 0.1  # Time step 0.1 seconds
        self.current_time += step_dt
        self.episode_step += 1

        # === Idle energy ===
        # The reviewer requested accounting for receive and idle energy. Compute/communication energy is already accumulated per task in _execute,
        # but the base electronics power during silent standby was not previously counted. Honest accounting: within this time step, UAVs that are "fully idle"
        # (no processing_tasks) are charged base power as idle_power * step_dt;
        # busy nodes' base power is already folded into compute_power_base and is not counted again, to avoid double counting.
        idle_energy_step = 0.0
        for did, q in self.task_queues.items():
            if len(q.processing_tasks) == 0:
                e_idle = self.energy_manager.energy_model.calculate_idle_energy(step_dt)
                self.energy_manager.consume_energy(did, e_idle)
                idle_energy_step += e_idle
        self.episode_stats["total_energy"] = \
            self.episode_stats.get("total_energy", 0.0) + idle_energy_step
        self.episode_stats["idle_energy"] = \
            self.episode_stats.get("idle_energy", 0.0) + idle_energy_step

        # === Control-channel overhead (R1.7: neighbor discovery + load exchange) ===
        # Each decision period, every UAV broadcasts a status beacon (position + load + compute) to its neighbors
        # Beacon size: position 8B + load 4B + compute 4B + timestamp 4B + header 12B = 32B each
        BEACON_BYTES = 32
        period_overhead_bytes = 0.0
        for did in self.task_queues.keys():
            n_neighbors = len(self.spatial_manager.get_all_neighbors(did))
            # Broadcast to each neighbor + receive from each neighbor (symmetric)
            period_overhead_bytes += BEACON_BYTES * n_neighbors
        self.episode_stats["control_overhead_bytes"] = \
            self.episode_stats.get("control_overhead_bytes", 0.0) + period_overhead_bytes
        # Control-overhead energy: estimated using communication transmit power (base tx 0.5W, assuming a 1Mbps control channel)
        # energy = bytes*8 / (1e6 bps) * 0.5W / 3600
        ctrl_energy = (period_overhead_bytes * 8 / 1e6) * 0.5 / 3600.0
        self.episode_stats["control_overhead_energy"] = \
            self.episode_stats.get("control_overhead_energy", 0.0) + ctrl_energy

        # Generate new tasks (all drones)
        self._generate_tasks()

        # **Clean up completed tasks (only for queue management, no longer produces reward)**
        # Task rewards are already given immediately at decision time
        self._cleanup_all_drones_processing_tasks_no_reward()

        # **System-state reward (10% weight, encourages continued processing)**
        system_state_reward = self._calculate_system_state_reward() * 0.1

        # Total reward = current drone's reward (requester + partner) + system-state reward
        drl_reward = current_drone_reward + system_state_reward

        # Check end conditions (correctly distinguish terminated from truncated to fix the terminal mask of the TD target)
        # This task is continuing (a task stream keeps arriving); an episode ends purely because the simulation time window / step limit expires,
        # which is "time truncation" rather than an MDP absorbing state (termination): the terminal-state value should be bootstrapped.
        # Therefore time/step expiry always sets truncated=True and terminated stays False.
        # SB3 bootstraps correctly on truncated transitions (no terminal mask), and applies (1-done) only for terminated.
        terminated = False
        time_up = self.current_time >= self.simulation_time
        step_up = self.episode_step >= self.max_episode_steps
        truncated = bool(time_up or step_up)

        # Prevent an episode from ending too early: guarantee a minimum episode length
        if self.episode_step < 400:
            truncated = False

        # Get the new observation (still based on current_drone_id)
        observation = self._get_observation()
        info = self._get_info()

        # Update statistics (using the DRL agent's reward)
        self.episode_stats["total_reward"] += drl_reward
        info['drl_reward'] = drl_reward
        info['current_time'] = self.current_time

        return observation.to_array(), drl_reward, terminated, truncated, info

    def _get_observation_for_drone(self, drone_id: str) -> 'DroneObservation':
        """Get the current observation state for a specified UAV."""
        # Temporarily switch current_drone_id to obtain this drone's observation
        original_current_drone = self.current_drone_id
        self.current_drone_id = drone_id

        # Get the observation
        observation = self._get_observation()

        # Restore the original current_drone_id
        self.current_drone_id = original_current_drone

        return observation

    def set_shared_drl_model(self, model):
        """Set the shared DRL model to be used by all UAVs."""
        self.shared_drl_model = model

    def set_baseline_mode(self, enabled: bool):
        """Set baseline mode (scheme Y): baseline sees all neighbors + naive partitioning, without DDCI's Pareto filtering.
        DDCI (DRL) follows the original Pareto path; baseline follows the all-neighbors path, for a fair comparison."""
        self.baseline_mode = enabled

    def _select_neighbors(self, candidates, k):
        """Select K neighbors: Pareto-optimal by default; when ablate_pareto=True, select randomly (ablating the value of Pareto)."""
        if self.ablate_pareto:
            if len(candidates) <= k:
                return list(candidates)
            idx = np.random.choice(len(candidates), size=k, replace=False)
            return [candidates[i] for i in idx]
        return self.pareto_selector.select_top_k(candidates, k=k)

    def _execute_drone_action(self, drone_id: str, action: CollaborationAction) -> float:
        """
        Execute the collaboration action for a specified drone.

        V2: classify the decision by neighbor count
        - 0 neighbors: process locally directly
        - 1-2 neighbors: greedy strategy (pick high compute / low load)
        - >=3 neighbors: use the DRL action
        """
        queue = self.task_queues[drone_id]

        # Check processing capacity
        if len(queue.processing_tasks) >= queue.max_concurrent_tasks:
            return 0.0

        # Check for pending tasks
        has_pending_tasks = any(queue.priority_queues[p] for p in queue.priority_queues)
        if not has_pending_tasks:
            return 0.0

        # Get a task to process
        current_task_entry = queue.get_next_task_for_processing(self.current_time)
        if not current_task_entry:
            return 0.0

        task = current_task_entry.task

        # Get this drone's neighbors and create candidates
        all_neighbors = self.spatial_manager.get_all_neighbors(drone_id)
        candidates = []
        for neighbor_id in all_neighbors:
            try:
                distance = self.spatial_manager.calculate_distance(drone_id, neighbor_id)
                neighbor_capacity = self.drone_capacities.get(neighbor_id, 400e9)
                # Load rate: based on backlog FLOPs, consistent with the observation convention (Eq. 4)
                if neighbor_id in self.task_queues:
                    neighbor_load = self._flops_load_rate(self.task_queues[neighbor_id], neighbor_capacity)
                else:
                    neighbor_load = 0.0
                candidates.append(NeighborCandidate(neighbor_id, distance, neighbor_load, neighbor_capacity))
            except:
                pass

        num_neighbors = len(candidates)

        # === Unified deterministic Pareto Top-K selection (selected only once in the whole flow, so the action-index -> neighbor mapping is stable and reproducible) ===
        if candidates:
            selected_candidates = self._select_neighbors(candidates, k=self.k_neighbors)
            neighbors = [c.neighbor_id for c in selected_candidates]
        else:
            selected_candidates = []
            neighbors = []

        # === Classify the decision by neighbor count (all methods follow the same Pareto path, a fair starting line) ===
        if num_neighbors == 0:
            # 0 neighbors: can only process locally (partner_idx=k -> out-of-range marker for local)
            final_action = CollaborationAction(partner_idx=self.k_neighbors, layer_cut=0)
        elif num_neighbors < 3:
            # 1-2 neighbors: greedy (pick the highest effective processing capability). selected_candidates is already sorted by effective compute descending,
            # so idx 0 is the best -> consistent with the neighbors list index (fixes the original best_idx indexing into an unsorted candidate list)
            final_action = CollaborationAction(partner_idx=0, layer_cut=action.layer_cut)
        else:
            # >=3 neighbors: use the DRL partner action
            if action.partner_idx < len(neighbors):
                final_action = action
            else:
                # If DRL chose local processing (partner_idx=k -> out-of-range marker for local)
                final_action = CollaborationAction(partner_idx=self.k_neighbors, layer_cut=0)

        # === Oracle upper bound (reviewer-requested upper bound): task-level analytic enumeration of the optimal partner*cut ===
        # For all candidate partners and all candidate cuts, compute completion latency with the analytic latency calculator and pick the minimum (meeting the deadline takes priority).
        # Does not change environment state (pure forward analysis), same convention as the main table; provides a strong upper-bound proxy of "optimal partition for every task".
        if getattr(self, 'oracle_mode', False) and num_neighbors > 0 and neighbors:
            best = None  # (miss_deadline, completion_time, partner_idx, cut)
            t_local_all = task.flops / max(self.drone_capacities.get(drone_id, 400e9), 1)
            # Candidate cuts: abstract actions 0-8 cover all real candidate layers
            for pj in range(min(len(neighbors), self.k_neighbors)):
                for cut_abs in range(9):
                    pt, ct = self._calculate_collaborative_time(task, drone_id, neighbors[pj], cut_abs)
                    comp = self.current_time + pt + ct
                    miss = 1 if (hasattr(task, 'deadline') and comp > task.deadline) else 0
                    key = (miss, comp)
                    if best is None or key < best[0]:
                        best = (key, pj, cut_abs)
            # Also consider pure local (may be faster than collaboration)
            comp_local = self.current_time + t_local_all
            miss_local = 1 if (hasattr(task, 'deadline') and comp_local > task.deadline) else 0
            if best is None or (miss_local, comp_local) < best[0]:
                final_action = CollaborationAction(partner_idx=self.k_neighbors, layer_cut=0)
            else:
                final_action = CollaborationAction(partner_idx=best[1], layer_cut=best[2])

        # === Collaboration partner accept/refuse decision. An overloaded or low-battery partner refuses the request, and the initiator falls back to local ===
        if self.enable_partner_refusal and final_action.partner_idx < len(neighbors):
            candidate_partner = neighbors[final_action.partner_idx]
            if not self._partner_accepts(candidate_partner, task):
                self.episode_stats["collab_refused"] = self.episode_stats.get("collab_refused", 0) + 1
                final_action = CollaborationAction(partner_idx=self.k_neighbors, layer_cut=0)

        if final_action.partner_idx < len(neighbors):
            # Collaborative processing
            partner_id = neighbors[final_action.partner_idx]
            processing_time, comm_time = self._calculate_collaborative_time(
                task, drone_id, partner_id, final_action.layer_cut
            )

            completion_time = self.current_time + processing_time + comm_time
            reward_info = {
                'partner_id': partner_id,
                'layer_cut': final_action.layer_cut,
                'drone_id': drone_id,
                'is_local': False
            }
            requester_reward = self._calculate_reward(
                task, processing_time, comm_time, completion_time, reward_info
            )

            # Partner reward
            partner_reward = self._calculate_partner_reward(task, processing_time, partner_id)
            if partner_id not in self.pending_partner_rewards:
                self.pending_partner_rewards[partner_id] = 0.0
            self.pending_partner_rewards[partner_id] += partner_reward

            self._start_task_processing(current_task_entry, processing_time, comm_time,
                                     task, drone_id, partner_id, final_action.layer_cut, True)
            self.episode_stats["collaborative_tasks"] += 1
            immediate_reward = requester_reward
        else:
            # Local processing
            processing_time = self._calculate_independent_time(task, drone_id)
            comm_time = 0.0

            completion_time = self.current_time + processing_time
            reward_info = {
                'partner_id': None,
                'layer_cut': 0,
                'drone_id': drone_id,
                'is_local': True
            }
            immediate_reward = self._calculate_reward(
                task, processing_time, comm_time, completion_time, reward_info
            )

            self._start_task_processing(current_task_entry, processing_time, 0.0,
                                     task, drone_id, None, 0, False)
            self.episode_stats["independent_tasks"] += 1

        return immediate_reward

    def _generate_baseline_action(self, drone_id: str) -> CollaborationAction:
        """Generate a baseline action for a non-DRL-controlled drone (balanced collaboration strategy)."""
        # Get this drone's neighbor count
        neighbors = self.spatial_manager.get_all_neighbors(drone_id)
        max_partners = min(len(neighbors), self.k_neighbors)

        if max_partners == 0:
            partner_idx = 0
        else:
            # Fix: use balanced selection instead of pure random, to reduce randomness in the DRL agent's reward
            if not hasattr(self, '_baseline_selection_counts'):
                self._baseline_selection_counts = {}

            # Initialize selection counts
            available_partners = neighbors[:max_partners]
            for partner_id in available_partners:
                if partner_id not in self._baseline_selection_counts:
                    self._baseline_selection_counts[partner_id] = 0

            # Select the least-chosen collaboration partner (balanced allocation)
            min_count = min([self._baseline_selection_counts.get(p, 0) for p in available_partners])
            least_selected = [p for p in available_partners
                            if self._baseline_selection_counts.get(p, 0) == min_count]

            # Randomly pick among the least-selected partners (keep some randomness)
            selected_partner = np.random.choice(least_selected)
            partner_idx = neighbors.index(selected_partner)

            # Update the count
            self._baseline_selection_counts[selected_partner] += 1

        # The partition point is still random (this does not affect fairness)
        layer_cut = np.random.randint(1, 9)  # ResNet18: partition points 1-8

        return CollaborationAction(partner_idx=partner_idx, layer_cut=layer_cut)

    def _calculate_collaborative_time(self, task: Task, drone_id: str,
                                    partner_id: str, cut_layer: int) -> Tuple[float, float]:
        """
        Paradigm 1 (MiniBatch pipeline layer partitioning): compute the processing time and communication time of a collaborative task.

        cut_layer (action 0-8) is mapped via layer_mapper to the real partition layer {1..L-1}.
        The first actual_cut layers are computed locally, the rest on the partner, with the batch split into micro-batches for pipeline overlap.
        """
        # Action-layer index (0-8) -> mapped via layer_mapper to an optimized candidate partition layer
        actual_cut = self.layer_mapper(cut_layer)

        # Get position info
        drone_state = self.spatial_manager.get_drone_state(drone_id)
        partner_state = self.spatial_manager.get_drone_state(partner_id)

        drone_pos = drone_state.position if drone_state else (0.0, 0.0)
        partner_pos = partner_state.position if partner_state else (0.0, 0.0)

        # Compute distance
        distance = np.sqrt((drone_pos[0] - partner_pos[0])**2 + (drone_pos[1] - partner_pos[1])**2)

        # Relative speed (for Doppler, module 2): magnitude of the two UAVs' velocity vector difference
        dv = getattr(drone_state, 'velocity', (0.0, 0.0)) if drone_state else (0.0, 0.0)
        pv = getattr(partner_state, 'velocity', (0.0, 0.0)) if partner_state else (0.0, 0.0)
        relative_speed = float(np.sqrt((dv[0] - pv[0])**2 + (dv[1] - pv[1])**2))

        # Get the actual drone processing capabilities (heterogeneity supported, FLOPS)
        drone_capacity = self.drone_capacities.get(drone_id, 400e9)
        partner_capacity = self.drone_capacities.get(partner_id, 400e9)

        # Number of images M for this task (= number of micro-batches; task.flops = total_flops * M)
        batch_images = max(1, round(task.flops / max(self.total_flops, 1)))

        # === Shared-channel contention factor. Under a half-duplex shared medium, concurrent links share the air-interface time ===
        # Spatial reuse: not all links across the network interfere; use the number of concurrent collaboration links within the initiator's communication radius,
        # and cap the contention factor (limited effective contenders under CSMA spatial reuse) to avoid numerical blowup.
        active_links = self._count_active_collab_links_near(drone_id)
        contention = float(min(active_links + 1, self.max_contention_links))  # +1 to count this link

        # Choose pipeline or serial latency calculation based on enable_pipeline
        if self.enable_pipeline:
            processing_time, comm_time = self.latency_calculator.calculate_collaborative_time(
                task_flops=task.flops,
                cut_layer=actual_cut,
                distance=distance,
                drone_capacity=drone_capacity,
                partner_capacity=partner_capacity,
                relative_speed=relative_speed,
                batch_images=batch_images,
                contention_factor=contention
            )
        else:
            processing_time, comm_time = self.latency_calculator.calculate_non_pipeline_collaborative_time(
                task_flops=task.flops,
                cut_layer=actual_cut,
                distance=distance,
                drone_capacity=drone_capacity,
                partner_capacity=partner_capacity,
                relative_speed=relative_speed,
                contention_factor=contention,
                batch_images=batch_images
            )

        # Record this collaboration batch's end-to-end latency (used to report the latency distribution)
        if "batch_latencies" in self.episode_stats:
            self.episode_stats["batch_latencies"].append(float(processing_time + comm_time))

        return processing_time, comm_time

    def _count_active_collab_links_near(self, drone_id: str) -> int:
        """Count ongoing collaborative transmission links within the initiator's communication radius (shared-channel contention, including spatial reuse).

        Only concurrent collaboration links close enough to the initiator (within the communication radius) truly contend for the same air-interface medium;
        distant links do not interfere due to spatial reuse. Under the half-duplex assumption these links share the channel capacity equally.
        """
        try:
            near = set(self.spatial_manager.get_all_neighbors(drone_id))
        except Exception:
            near = set()
        near.add(drone_id)
        n = 0
        for owner, q in self.task_queues.items():
            for entry in getattr(q, 'processing_tasks', []):
                pinfo = getattr(entry, 'processing_info', None)
                if not (pinfo and pinfo.get('is_collaborative', False)):
                    continue
                # If either end of this collaboration link is within the initiator's neighborhood -> treat as contending for the same medium
                pid = pinfo.get('partner_id')
                if owner in near or (pid is not None and pid in near):
                    n += 1
        return n

    def _calculate_independent_time(self, task: Task, drone_id: str) -> float:
        """
        Compute the processing time of an independent task.

        Uses the unified latency calculator.
        Passes in the actual drone processing capability (heterogeneity supported).
        """
        drone_capacity = self.drone_capacities.get(drone_id, 1e10)
        return self.latency_calculator.calculate_independent_time(
            task_flops=task.flops,
            drone_capacity=drone_capacity
        )

    def _start_task_processing(self, task_entry, processing_time: float, comm_time: float,
                             task: Task, drone_id: str, partner_id: str, cut_layer: int,
                             is_collaborative: bool):
        """Start task processing, setting the completion time and related info."""
        # Set task processing info
        task_entry.start_time = self.current_time
        task_entry.estimated_completion_time = self.current_time + processing_time + comm_time

        # Store processing info for later reward calculation
        task_entry.processing_info = {
            'processing_time': processing_time,
            'comm_time': comm_time,
            'drone_id': drone_id,
            'partner_id': partner_id,
            'cut_layer': cut_layer,
            'is_collaborative': is_collaborative,
            'task': task
        }

        # Record performance data
        if is_collaborative:
            self.performance_calc.record_collaboration(task.id, processing_time, comm_time, True)
        else:
            self.performance_calc.record_independent_processing(task.id, processing_time)

    def _calculate_system_state_reward(self) -> float:
        """Compute a system-state reward to address reward sparsity.

        Even when no task completes, provide a feedback signal about the system state.
        Return range: [-1.0, +2.0]
        """
        # 1. Number of tasks in processing (encourages tasks being processed)
        processing_count = sum(len(q.processing_tasks) for q in self.task_queues.values())
        max_processing = len(self.task_queues) * 5  # 10 drones, each up to 5 concurrent
        processing_reward = min(processing_count / max_processing, 1.0)  # [0, 1]

        # 2. Queue load (penalize backlog)
        total_queue = 0
        for queue in self.task_queues.values():
            for priority in range(4):
                total_queue += len(queue.priority_queues[priority])

        # Lightly penalize queue backlog (not too heavy, otherwise it would prevent accepting tasks)
        # Optimization: strengthen the backlog penalty to encourage fast processing
        queue_penalty = -min(total_queue / 50.0, 2.0)  # Strengthened: 200->50, 0.5->2.0

        # 3. Load balancing (encourage even distribution)
        if len(self.task_queues) > 1:
            load_rates = []
            for queue in self.task_queues.values():
                processing = len(queue.processing_tasks)
                load_rate = processing / queue.max_concurrent_tasks
                load_rates.append(load_rate)

            load_std = np.std(load_rates)
            balance_reward = max(0, 0.5 - load_std)  # [0, 0.5]
        else:
            balance_reward = 0.0

        # Total system-state reward
        total_state_reward = processing_reward + queue_penalty + balance_reward

        return total_state_reward

    def _cleanup_all_drones_processing_tasks_no_reward(self) -> None:
        """
        Clean up completed tasks (only for queue management, no reward computed).

        New method: task rewards are already given immediately at decision time; this only does cleanup work.
        """
        total_completed_tasks = 0

        for drone_id, queue in self.task_queues.items():
            completed_entries = []

            for entry in queue.processing_tasks:
                # Check whether the task has reached its estimated completion time
                should_complete = False

                if hasattr(entry, 'estimated_completion_time') and entry.estimated_completion_time:
                    if self.current_time >= entry.estimated_completion_time:
                        should_complete = True
                elif hasattr(entry, 'start_time') and entry.start_time:
                    expected_completion = entry.start_time + 0.1
                    if self.current_time >= expected_completion:
                        should_complete = True

                # Timeout cleanup
                if hasattr(entry, 'task') and hasattr(entry.task, 'deadline'):
                    if self.current_time > entry.task.deadline:
                        should_complete = True

                if should_complete:
                    completed_entries.append(entry)

            # Process completed tasks
            for entry in completed_entries:
                # Remove from the processing queue
                queue.processing_tasks.remove(entry)

                # === Link-interruption detection (module 4, R3.8/R1.9) ===
                link_broken = False
                if hasattr(entry, 'processing_info'):
                    pinfo = entry.processing_info
                    partner_id = pinfo.get('partner_id')
                    is_collaborative = pinfo.get('is_collaborative', False)
                    if partner_id and is_collaborative:
                        try:
                            dist = self.spatial_manager.calculate_distance(drone_id, partner_id)
                            if dist > self.communication_radius:
                                link_broken = True
                        except:
                            link_broken = True
                        if link_broken:
                            self.episode_stats["link_interruptions"] = \
                                self.episode_stats.get("link_interruptions", 0) + 1

                if link_broken:
                    # === Link-interruption handling (R3.8/R1.9: hierarchical resilience mechanism) ===
                    # Priority: migration > local fallback > failure
                    task = pinfo.get('task')
                    handled = False

                    # Ablation (ablate_recovery=True): disable the hierarchical resilience mechanism (migration + fallback),
                    # a link interruption is judged a failure directly, used to demonstrate the recovery state machine's contribution (with/without recovery).
                    # Strategy B: task migration -- if another neighbor is still in range, reassign
                    other_neighbors = self.spatial_manager.get_all_neighbors(drone_id)
                    available_partners = [
                        n for n in other_neighbors
                        if n != partner_id and
                        self.spatial_manager.calculate_distance(drone_id, n) <= self.communication_radius
                    ]
                    if self.enable_recovery and available_partners and task:
                        # Migrate to the nearest available neighbor (retransmit original images)
                        new_partner = min(available_partners,
                                         key=lambda n: self.spatial_manager.calculate_distance(drone_id, n))
                        # Extra latency: retransmission communication time (simplified to 50% of the original collaboration communication)
                        migration_penalty = pinfo.get('comm_time', 0.05) * 0.5
                        entry.estimated_completion_time = self.current_time + migration_penalty + \
                            pinfo.get('processing_time', 0.1) * 0.5  # Recompute the remote portion
                        entry.start_time = self.current_time
                        # Update partner_id to the new partner (avoid the next cleanup re-detecting an interruption with the old partner)
                        pinfo['partner_id'] = new_partner
                        # Do not remove from processing_tasks; let it complete at the next cleanup
                        queue.processing_tasks.append(entry)
                        self.episode_stats["link_migrations"] = \
                            self.episode_stats.get("link_migrations", 0) + 1
                        handled = True

                    # Strategy A: local fallback -- if the deadline still has slack, recompute the partner's portion locally
                    if self.enable_recovery and not handled and task and hasattr(task, 'deadline'):
                        remaining = task.deadline - self.current_time
                        # Pipeline: the partner computes the later layers; fallback = recompute these FLOPs locally
                        actual_cut = self.layer_mapper(pinfo.get('cut_layer', 4))
                        lf = [s.flops for s in self.model_partitioner.layer_specs]
                        remote_ratio = sum(lf[actual_cut:]) / max(sum(lf), 1e-9)
                        drone_cap = self.drone_capacities.get(drone_id, 400e9)
                        fallback_time = task.flops * remote_ratio / drone_cap
                        if remaining > fallback_time:
                            # There is time; fall back to local
                            entry.estimated_completion_time = self.current_time + fallback_time
                            entry.start_time = self.current_time
                            # Clear the collaboration flag (local recompute, no longer detect interruption)
                            pinfo['is_collaborative'] = False
                            pinfo['partner_id'] = None
                            queue.processing_tasks.append(entry)
                            self.episode_stats["link_fallbacks"] = \
                                self.episode_stats.get("link_fallbacks", 0) + 1
                            handled = True

                    # Strategy C: failure -- unrecoverable (link failure, counted separately, treated as one unmet deadline)
                    if not handled:
                        entry.completion_time = self.current_time
                        queue.completed_tasks.append(entry)
                        self.episode_stats["tasks_failed"] = \
                            self.episode_stats.get("tasks_failed", 0) + 1

                    continue

                # Set the completion time (for later statistical analysis)
                entry.completion_time = entry.estimated_completion_time or self.current_time
                queue.completed_tasks.append(entry)

                # Statistics (for monitoring and performance metrics)
                if hasattr(entry, 'processing_info'):
                    info = entry.processing_info
                    completion_time = entry.completion_time

                    # Record task completion
                    self.performance_calc.record_task_completion(
                        info['task'].id, info['task'].priority, info['task'].arrival_time,
                        entry.start_time or self.current_time, completion_time, True
                    )

                    self.episode_stats["tasks_completed"] += 1
                    self.episode_stats["total_latency"] += (info['processing_time'] + info['comm_time'])
                    self.episode_stats["total_flops"] += info['task'].flops  # Accumulate FLOPs
                    total_completed_tasks += 1

        # Clean up expired tasks
        self._cleanup_expired_pending_tasks()

    def _cleanup_all_drones_processing_tasks(self) -> float:
        """Check and complete tasks that have reached their time, returning the DRL agent's reward.

        **Key fix: only count the currently controlled drone's reward to avoid reward-scale blowup**
        """
        drl_reward = 0.0
        total_completed_tasks = 0
        current_drone_completed = 0  # Number of tasks completed by the currently DRL-controlled drone

        for drone_id, queue in self.task_queues.items():
            completed_entries = []

            for entry in queue.processing_tasks:
                # Check whether the task has reached its estimated completion time OR exceeded its deadline
                should_complete = False

                # 1. Normal completion: reached the estimated completion time
                if hasattr(entry, 'estimated_completion_time') and entry.estimated_completion_time:
                    if self.current_time >= entry.estimated_completion_time:
                        should_complete = True
                elif hasattr(entry, 'start_time') and entry.start_time:
                    # Backward-compatible handling for old-style tasks
                    expected_completion = entry.start_time + 0.1
                    if self.current_time >= expected_completion:
                        should_complete = True

                # 2. Timeout cleanup: force-complete tasks past their deadline
                if hasattr(entry, 'task') and hasattr(entry.task, 'deadline'):
                    if self.current_time > entry.task.deadline:
                        should_complete = True

                if should_complete:
                    completed_entries.append(entry)

            # Process completed tasks
            for entry in completed_entries:
                # Remove from the processing queue
                queue.processing_tasks.remove(entry)

                # Set the completion time (for later statistical analysis)
                entry.completion_time = entry.estimated_completion_time or self.current_time
                queue.completed_tasks.append(entry)

                # **Fix: both collaboration parties receive a reward**
                if hasattr(entry, 'processing_info'):
                    info = entry.processing_info
                    completion_time = entry.completion_time

                    # Compute the full task reward
                    full_task_reward = self._calculate_reward(
                        info['task'], info['processing_time'],
                        info['comm_time'], completion_time, info
                    )

                    # The initiator (the task's owning drone) receives the full reward
                    if drone_id == self.current_drone_id:
                        drl_reward += full_task_reward
                        current_drone_completed += 1

                    # The partner receives a partial reward (40%)
                    # Encourages drones to actively be good collaboration partners
                    partner_id = info.get('partner_id')
                    if partner_id and partner_id == self.current_drone_id:
                        # The current drone, as a partner, receives 40% of the reward
                        partner_reward = full_task_reward * 0.4
                        drl_reward += partner_reward

                # Statistics (all drones, monitoring only)
                if hasattr(entry, 'processing_info'):
                    info = entry.processing_info
                    completion_time = entry.completion_time  # Use the already-set completion_time

                    # Record task completion
                    self.performance_calc.record_task_completion(
                        info['task'].id, info['task'].priority, info['task'].arrival_time,
                        entry.start_time or self.current_time, completion_time, True
                    )

                    self.episode_stats["tasks_completed"] += 1
                    self.episode_stats["total_latency"] += (info['processing_time'] + info['comm_time'])
                    self.episode_stats["total_flops"] += info['task'].flops  # Accumulate FLOPs
                    total_completed_tasks += 1

        # Extra cleanup: check timed-out tasks in the pending queue
        self._cleanup_expired_pending_tasks()

        # Fix: remove the idle penalty - since tasks require multiple steps to process, normal processing time should not be penalized
        # Only give a reward on task completion; when not completed the reward is 0 (no penalty)
        # if current_drone_completed == 0:
        #     drl_reward -= 0.5  # Removed: it would cause 70% of steps to get a negative reward

        return drl_reward

    def _cleanup_expired_pending_tasks(self):
        """Clean up tasks in the pending queue that are past their deadline."""
        for drone_id, queue in self.task_queues.items():
            for priority in TaskPriority:
                priority_queue = queue.priority_queues[priority]
                expired_tasks = []

                for entry in priority_queue:
                    if hasattr(entry, 'task') and hasattr(entry.task, 'deadline'):
                        if self.current_time > entry.task.deadline:
                            expired_tasks.append(entry)

                # Remove timed-out pending tasks
                for expired_entry in expired_tasks:
                    priority_queue.remove(expired_entry)
                    # Record as a failed/timed-out task
                    if hasattr(queue, 'expired_tasks'):
                        queue.expired_tasks.append(expired_entry)
                    self.episode_stats["tasks_expired"] = self.episode_stats.get("tasks_expired", 0) + 1

                    # If it is the DRL-controlled UAV, apply a deadline penalty
                    if drone_id == self.current_drone_id:
                        # Timeout penalty (given directly here, not waiting for task completion)
                        deadline_penalty = min((self.current_time - expired_entry.task.deadline) * 5.0, 12.0)
                        # Note: this should be accumulated in the main loop; only record for now
                        pass  # Do not deduct points directly here for now, to avoid complicating the reward signal
    
    def _generate_tasks(self):
        """Generate new tasks. **Optimized: a task generation rate suitable for DRL training**."""
        # **Goal: fully utilize the system and provide enough collaboration learning opportunities**
        # Unified train & test config: an imbalanced-load environment
        # Goal: half the UAVs at full load (90%+), half idle (20%-)
        # This makes the collaboration advantage clear: full-load nodes must offload, idle nodes can help
        for drone_id, generator in self.task_generators.items():
            # Moderate temporal variation (simulating task fluctuation in real scenarios)
            time_smooth_factor = 0.9 + 0.2 * np.sin(self.current_time * 0.1)  # [0.7, 1.1]

            # Imbalanced task distribution: create "hotspot" UAVs and "idle" UAVs
            # Goal: hotspots at high load (can fully offload via layer_cut=0), idle nodes at low load (receive collaboration)
            # This makes the collaboration advantage clear!
            drone_idx = int(drone_id.split('_')[1])  # Extract the number, e.g. "drone_3" -> 3

            if drone_idx < 5:
                # Hotspot UAVs (drone_0~4): high load, must offload via collaboration
                load_factor = 2.5
            else:
                # Idle UAVs (drone_5~9): low load, have spare capacity to help
                load_factor = 0.4

            # Moderate load (2.6), drop ~5-8% keeps spare compute -> collaboration offload still has a target (the main DDCI conclusion does not collapse),
            # while light contention makes "prioritizing HIGH" meaningful. Too high (3.5) would overwhelm the system and flatten the collaboration advantage.
            task_multiplier = 2.6 * 0.8 * load_factor * time_smooth_factor

            for priority in TaskPriority:
                # HIGH share ~18% (enough samples to learn a differentiated strategy without overwhelming the system). Semantics = latency-sensitive urgent small tasks.
                if priority == TaskPriority.HIGH:
                    # High priority: urgent tasks (~18%)
                    arrival_rate = 0.18
                elif priority == TaskPriority.MEDIUM:
                    # Medium priority: the main collaborative inference tasks (DRL core, source of collaboration gains) (~58%)
                    arrival_rate = 0.58
                elif priority == TaskPriority.LOW:
                    # Low priority: routine tasks (~14%)
                    arrival_rate = 0.14
                else:  # BACKGROUND
                    # Background tasks: system maintenance (~10%)
                    arrival_rate = 0.10

                # Use a Poisson distribution to generate tasks (the correct method)
                # Tasks are generated correctly even when effective_rate < 1
                effective_rate = arrival_rate * task_multiplier * self.task_rate_multiplier * 0.1  # Apply multiplier, rate multiplier, and time step
                num_tasks = np.random.poisson(effective_rate)

                for task_idx in range(num_tasks):
                    # Real same-source magnitude (R1.4/R2.2): a task = full DNN inference over M images
                    #   task.flops = real DNN total FLOPs * M (same source as the partitioner's layer FLOPs / data size)
                    #   priority is distinguished by batch size M + deadline tightness (rather than an artificial FLOPs range)
                    #   t_solo = time for a single node (reference compute) to process the task; the deadline is derived from it and automatically adapts to network scale
                    #   Tighten the deadline: make local barely sufficient/insufficient, so collaboration's 1.5x speedup translates into higher satisfaction rate
                    ref_cap = 4e11  # Reference compute ~400 GFLOPS (median of the Jetson levels)
                    # Task sizes are highly diverse (M spanning 2-32): different sizes have different optimal partition points,
                    # making "dynamic partitioning (DRL)" clearly better than "fixed partitioning (greedy/EPCTA)" -> creates a latency gap
                    if priority == TaskPriority.HIGH:
                        # HIGH = latency-sensitive urgent small tasks (fast inference on a few frames), low compute.
                        # Semantics: threat detection / emergency avoidance. Key mechanism (core of the C24 positive evidence):
                        #   slack=1.3 makes deadline ~= 1.3 * local processing time -> **served immediately, it makes it in time**,
                        #   but if a small task is queued behind a large MED (M10-25, ~3x HIGH processing time) -> queueing delay far exceeds the slack -> timeout.
                        #   Therefore: priority-scheduling jump-ahead -> HIGH completes on time (gain); FIFO ablation -> HIGH queues and times out (crashes).
                        #   The binding constraint changes from "insufficient compute" (old slack=0.5 always times out, unrelated to scheduling) to "queueing delay" (schedulable).
                        # m_scale: for light networks, enlarge the batch so the local processing time magnitude aligns (see _init_network_config)
                        M = max(2, round(np.random.randint(4, 9) * self.m_scale))
                        slack = 1.2 if self.network_type in ['yolov5m','YOLOv5m','yolov5s'] else 1.3
                    elif priority == TaskPriority.MEDIUM:
                        # Main source of collaboration gains: large tasks, local is barely insufficient, collaboration speedup can translate into satisfaction rate
                        M = max(3, round(np.random.randint(10, 25) * self.m_scale))
                        slack = 0.85 if self.network_type in ['yolov5m','YOLOv5m','yolov5s'] else 0.95
                    elif priority == TaskPriority.LOW:
                        M = max(2, round(np.random.randint(3, 9) * self.m_scale))
                        slack = 1.1 if self.network_type in ['yolov5m','YOLOv5m','yolov5s'] else 1.2
                    else:  # BACKGROUND
                        M = max(1, round(np.random.randint(2, 5) * self.m_scale))
                        slack = 1.4 if self.network_type in ['yolov5m','YOLOv5m','yolov5s'] else 1.6

                    flops = self.total_flops * M       # Real DNN FLOPs * batch
                    # The deadline is based on the initiator's own compute (not a fixed ref_cap): reflects "can it complete locally"
                    # Weak node local is slow -> deadline relatively loose (gives a collaboration opportunity); strong node local is fast -> deadline tight (it can already handle it)
                    self_cap = self.drone_capacities.get(drone_id, 400e9)
                    t_local_self = flops / self_cap     # This node's local processing time
                    base_deadline = max(0.2, t_local_self * slack)

                    deadline = self.current_time + base_deadline + np.random.uniform(0.05, 0.2)
                    # aoi_threshold: deprecated (V4 reward changed to deadline-based, this field is no longer read),
                    # kept only as a constructor argument for compatibility with the Task dataclass
                    aoi_threshold = base_deadline + np.random.uniform(0.1, 0.5)
                    drone_state = self.spatial_manager.get_drone_state(drone_id)
                    if drone_state:
                        pos = drone_state.position
                    else:
                        pos = (0.0, 0.0)

                    task = Task(
                        id=f"task_{self.current_time:.1f}_{drone_id}_{priority.name}_{task_idx}",
                        priority=priority,
                        flops=flops,
                        deadline=deadline,
                        location=pos,
                        task_type=TaskType.INFERENCE,
                        arrival_time=self.current_time,
                        aoi_threshold=aoi_threshold
                    )

                    # Add to the queue
                    self.task_queues[drone_id].add_task(task, self.current_time)

                    # Record task generation
                    self.performance_calc.record_task_generation(priority)
                    self.episode_stats["tasks_generated"] += 1

    def _flops_load_rate(self, queue, capacity_flops: float, t_window: float = 1.0) -> float:
        """
        Load rate based on backlog FLOPs, aligned with paper Eq. (4):
            l_i(t) = (F_proc + F_queue) / (C_i * T_w) in [0,1]
        Numerator = FLOPs being processed + queued, denominator = compute (FLOPS) * time window (s) = processable FLOPs
        Returns a dimensionless load rate, clipped to [0,1].
        """
        backlog_flops = queue.calculate_total_flops_load()
        capacity_flops_window = max(capacity_flops * t_window, 1e-9)
        return float(min(1.0, backlog_flops / capacity_flops_window))

    def _get_observation(self) -> DroneObservation:
        """
        Get the current UAV's observation state V3.

        Observation space: 15-dim (K=3)
        - Self state (6-dim): flops, queue_load, busy_rate, priority, urgency, self_capacity
        - Neighbor state (6-dim): 3 neighbors * (capacity, load)

        Decision logic:
        - 0 neighbors: process locally directly
        - 1-2 neighbors: greedy strategy
        - >=3 neighbors: DRL decision after Pareto filtering
        """
        drone_id = self.current_drone_id
        queue = self.task_queues[drone_id]

        # === Self state ===
        current_task = queue.peek_next_task()

        if current_task:
            task = current_task.task
            flops_norm = min(1.0, task.flops / 4e11)  # Normalize to [0,1] (upper bound 4e11 after x40)

            # Task priority
            priority_map = {
                TaskPriority.HIGH: 3,
                TaskPriority.MEDIUM: 2,
                TaskPriority.LOW: 1,
                TaskPriority.BACKGROUND: 0
            }
            task_priority_norm = priority_map.get(task.priority, 1) / 3.0

            # Deadline urgency
            time_to_deadline = max(0.0, task.deadline - self.current_time)
            total_time_window = max(1.0, task.deadline - task.arrival_time)
            deadline_urgency = 1.0 - min(1.0, time_to_deadline / total_time_window)
        else:
            flops_norm = 0.0
            task_priority_norm = 0.0
            deadline_urgency = 0.0

        # Queue load rate: load based on backlog FLOPs, aligned with paper Eq. (4)
        # l = (F_proc + F_queue) / (C_i * T_w)
        self_cap_for_load = self.drone_capacities.get(drone_id, 400e9)
        queue_load = self._flops_load_rate(queue, self_cap_for_load)

        # Busy rate
        processing_count = len(queue.processing_tasks)
        busy_rate = processing_count / queue.max_concurrent_tasks

        # Own compute capability (normalized, with 800 GFLOPS as the upper bound, the strongest level after x40)
        self_capacity = self.drone_capacities.get(drone_id, 400e9)
        self_capacity_norm = min(1.0, self_capacity / 8e11)

        # === Neighbor info ===
        all_neighbors = self.spatial_manager.get_all_neighbors(drone_id)

        # Build the neighbor candidate list
        candidates = []
        for neighbor_id in all_neighbors:
            try:
                distance = self.spatial_manager.calculate_distance(drone_id, neighbor_id)

                # Load rate: load based on backlog FLOPs, aligned with paper Eq. (4)
                # l = (F_proc + F_queue) / (C_i * T_w)
                if neighbor_id in self.task_queues:
                    neighbor_queue = self.task_queues[neighbor_id]
                    neighbor_cap = self.drone_capacities.get(neighbor_id, 400e9)
                    neighbor_load = self._flops_load_rate(neighbor_queue, neighbor_cap)
                else:
                    neighbor_load = 0.0

                # Get the neighbor's compute capability (FLOPS)
                neighbor_capacity = self.drone_capacities.get(neighbor_id, 400e9)

                candidates.append(NeighborCandidate(neighbor_id, distance, neighbor_load, neighbor_capacity))
            except:
                pass

        # Pareto-select the TOP-K neighbors
        if candidates:
            selected_candidates = self._select_neighbors(candidates, k=self.k_neighbors)
        else:
            selected_candidates = []

        # Build neighbor features: [distance, load, compute] (consistent with the three Pareto objectives)
        neighbor_distances = []
        neighbor_loads = []
        neighbor_capacities = []

        for i in range(self.k_neighbors):
            if i < len(selected_candidates):
                candidate = selected_candidates[i]
                # Distance normalization (d / R_comm)
                dist_norm = min(1.0, candidate.distance / max(self.communication_radius, 1e-9))
                # Compute normalization (with 800 GFLOPS as the upper bound, the strongest level after x40)
                cap_norm = min(1.0, candidate.capacity / 8e11)
                neighbor_distances.append(dist_norm)
                neighbor_loads.append(min(1.0, candidate.load))
                neighbor_capacities.append(cap_norm)
            else:
                # Empty slots are filled as worst-on-all-three-objectives (implicit action masking): distance=1 (farthest), load=1 (fullest), compute=0 (weakest).
                # This way Pareto/policy treats a filler slot as the worst candidate in the observation and will not mis-select it;
                # combined with the level-based redirection in _execute_drone_action (0 neighbors -> local, out-of-range partner_idx -> local),
                # sparse/zero-neighbor states are handled correctly without changing the action-space dimension.
                neighbor_distances.append(1.0)
                neighbor_loads.append(1.0)
                neighbor_capacities.append(0.0)

        # Own remaining battery ratio (energy-aware decision, R1.6/R3.11)
        battery_pct = self.energy_manager.get_battery_percentage(drone_id)

        # Priority ablation: zero out priority and deadline_urgency to demonstrate the role of these two dimensions
        if self.ablate_priority:
            task_priority_norm = 0.0
            deadline_urgency = 0.0
        # Ablate deadline_urgency separately (split from priority, isolating the contribution of the deadline state feature)
        if self.ablate_deadline_urgency:
            deadline_urgency = 0.0

        return DroneObservation(
            flops_norm=flops_norm,
            queue_load=queue_load,
            busy_rate=busy_rate,
            task_priority_norm=task_priority_norm,
            deadline_urgency=deadline_urgency,
            self_capacity_norm=self_capacity_norm,
            battery_pct=battery_pct,
            neighbor_distances=neighbor_distances,
            neighbor_loads=neighbor_loads,
            neighbor_capacities=neighbor_capacities
        )
        
        
    def _calculate_reward(self, task: Task, processing_time: float,
                         comm_time: float, completion_time: float, info: dict = None) -> float:
        """
        V4 reward function (route A: deadline-based, aligned with paper Eq. (17), 4 terms):
            R = w_p * r_comp - alpha*l_deadline - beta_E*E - beta_C*c_comm

        The three independent dimensions of communication are modeled separately:
        - Communication latency -> enters t_actual -> r_comp (task timeliness)
        - Communication energy -> enters E (battery consumption)
        - Communication channel occupancy -> c_comm (shared-spectrum resource cost, addressing R1.3 wireless resource management)
        Terms:
        - r_comp     completion reward, t_ideal=F/C_i (real compute, fictitious eta removed)
        - l_deadline deadline penalty max(0, t_end - D)
        - E          energy penalty (compute + communication energy, normalized by E_REF; + low-battery penalty)
        - c_comm     channel resource occupancy (real transmitted volume * distance factor, local=0)
        The participation reward r_part is sent separately to the partner by _calculate_partner_reward.
        Return range: [-20, +30]
        """
        # Reward weights (lifted to the constructor's self.reward_coeffs to support coefficient sensitivity analysis; defaults unchanged)
        R_BASE = self.reward_coeffs['R_BASE']  # Completion-reward base (speedup coefficient)
        ALPHA = self.reward_coeffs['ALPHA']    # Deadline penalty coefficient
        BETA_E = self.reward_coeffs['BETA_E']  # Energy penalty coefficient
        BETA_C = self.reward_coeffs['BETA_C']  # Communication channel-occupancy coefficient
        D_REF = self.reward_coeffs['D_REF']    # Channel-occupancy reference transmitted volume (MB)
        E_REF = self.reward_coeffs['E_REF']    # Energy normalization baseline (Wh)

        drone_id = info.get('drone_id') if info else None
        partner_id = info.get('partner_id') if info else None
        is_local = info.get('is_local', True) if info else True

        # Get UAV capabilities (FLOPS)
        drone_capacity = self.drone_capacities.get(drone_id, 400e9) if drone_id else 400e9
        partner_capacity = self.drone_capacities.get(partner_id, 400e9) if partner_id else 400e9

        # === 1. Completion reward (main metric = latency: uses speedup relative to local, strongly monotonic in latency) ===
        t_actual = processing_time + comm_time
        t_local = task.flops / max(drone_capacity, 1e-9)   # Initiator's local solo time
        # Speedup: the faster the collaboration (smaller t_actual) the higher the reward, strictly monotonic. Local baseline speedup=1 -> r_comp=0
        # speedup upper-bound clip (avoids r_comp becoming unbounded as t_actual->0; physically the speedup cannot exceed the order of the number of collaborating nodes)
        SPEEDUP_CAP = self.reward_coeffs.get('SPEEDUP_CAP', 5.0)
        speedup = t_local / max(t_actual, 1e-9)
        speedup = min(speedup, SPEEDUP_CAP)   # Bounded
        r_comp = R_BASE * (speedup - 1.0)   # Positive reward if faster than local, negative if slower, strongly and monotonically correlated with latency

        # === 2. Deadline penalty (replaces the original AOI timeout) ===
        lateness = max(0.0, completion_time - task.deadline)
        deadline_pen = ALPHA * lateness
        if completion_time > task.deadline:
            self.episode_stats["deadline_violations"] = self.episode_stats.get("deadline_violations", 0) + 1
        else:
            self.episode_stats["deadline_met"] = self.episode_stats.get("deadline_met", 0) + 1

        # === 3. Energy penalty (explicit term, and actually deducts from the battery) ===
        distance = 0.0
        if partner_id and not is_local:
            distance = self.spatial_manager.calculate_distance(drone_id, partner_id)
        cut_layer = info.get('cut_layer', 4) if info else 4
        # Action-layer index -> mapped via layer_mapper to the real partition layer
        actual_cut = self.layer_mapper(cut_layer)
        # FLOPs ratio processed locally (first actual_cut layers) = cut_ratio
        layer_flops = [s.flops for s in self.model_partitioner.layer_specs]
        local_ratio = sum(layer_flops[:actual_cut]) / max(sum(layer_flops), 1e-9)

        # Pipeline communication data size: the partition layer's intermediate feature map * number of micro-batches (number of images M)
        batch_images = max(1, round(task.flops / max(self.total_flops, 1)))
        cut_data_mb = self.model_partitioner.layer_specs[min(actual_cut, self.num_layers)-1].data_size_bytes / (1024*1024)
        data_to_send_mb = cut_data_mb * batch_images

        energy_info = self.energy_model.calculate_task_energy(
            task_flops=task.flops,
            drone_capacity_gflops=drone_capacity / 1e9,
            partner_capacity_gflops=partner_capacity / 1e9,
            cut_ratio=local_ratio,
            distance_m=distance,
            data_size_mb=data_to_send_mb,
            bandwidth_mbps=self.bandwidth_mbps,
            is_local=is_local
        )
        task_energy = energy_info['total_energy']           # System total energy (including partner), for statistical reporting
        initiator_energy = energy_info.get('initiator_energy', task_energy)  # Initiator energy, deducted from battery
        # consume_energy returns whether the charge was sufficient; False = battery-depletion violation, counted into the violation rate
        if not self.energy_manager.consume_energy(drone_id, initiator_energy):
            self.episode_stats["battery_violations"] = \
                self.episode_stats.get("battery_violations", 0) + 1
        self.episode_stats["total_energy"] = self.episode_stats.get("total_energy", 0.0) + task_energy
        # The partner also deducts its own compute energy from its battery (system-realistic)
        partner_e = energy_info.get('partner_compute_energy', 0.0)
        if partner_id and partner_e > 0:
            if not self.energy_manager.consume_energy(partner_id, partner_e):
                self.episode_stats["battery_violations"] = \
                    self.episode_stats.get("battery_violations", 0) + 1

        energy_pen = BETA_E * min(1.0, task_energy / E_REF)

        # Extra low-battery penalty (a soft implementation of the energy-budget constraint C6)
        battery_pct = self.energy_manager.get_battery_percentage(drone_id)
        if battery_pct < 0.2:
            energy_pen += 5.0 * (0.2 - battery_pct) / 0.2

        # === 4. Communication channel occupancy (real transmitted volume * distance factor, local=0) ===
        # Distinct from latency (r_comp) and energy (E): this is the externality cost of occupying shared spectrum (R1.3)
        if is_local or not partner_id:
            comm_cost = 0.0
        else:
            # Reuse the real transmitted volume data_to_send_mb already computed in the energy term (partition-layer intermediate features * batch)
            dist_factor = 1.0 + distance / max(self.communication_radius, 1e-9)
            comm_cost = (data_to_send_mb / D_REF) * dist_factor
        comm_pen = BETA_C * comm_cost

        # === Priority weighting (widen the distinction, aids the priority ablation) ===
        priority_weights = {
            TaskPriority.HIGH: 4.0,
            TaskPriority.MEDIUM: 2.0,
            TaskPriority.LOW: 1.0,
            TaskPriority.BACKGROUND: 0.5
        }
        # Reward-component ablation: set w_p=1 so all priorities are equally weighted, isolating the contribution of "reward priority weighting"
        w_p = 1.0 if self.ablate_reward_priority else priority_weights.get(task.priority, 1.0)

        # === Combination (4 terms, aligned with paper Eq. 17) ===
        # Reinforcement (scheme A): w_p acts on the deadline penalty term (rather than r_comp).
        # Rationale: w_p*r_comp only encourages "finding collaboration for high priority", not directly "completing high priority on time";
        # and high-priority small tasks can be done via collaboration or locally, so forcing collaboration is actually harmful. After switching to w_p*deadline_pen,
        # "missing a high-priority deadline" is heavily penalized by priority (HIGH 4x) -> the model learns to prioritize completing HIGH on time,
        # whether via collaboration or locally. Directly aligns with the paper's claim that "priority yields high-priority gains".
        total_reward = r_comp - w_p * deadline_pen - energy_pen - comm_pen
        final_reward = np.clip(total_reward, -20.0, 30.0)

        return float(final_reward)

    def _calculate_load_balance_reward(self) -> float:
        """
        Compute the load-balancing reward (old version, deprecated).
        Kept for compatibility.
        """
        return self._calculate_load_balance_reward_v2()

    def _calculate_load_balance_reward_v2(self) -> float:
        """
        V2 load-balancing reward: remove idle suppression.

        Improvements:
        1. Raise the maximum reward (+10 -> +15)
        2. Remove suppression while idle (always give the full reward)
        3. Widen the reward range ([-5,+10] -> [-6,+15])

        Return range: [-6.0, +15.0]
        """
        if len(self.task_queues) <= 1:
            return 0.0

        # Collect all drones' load rates
        load_rates = []
        for queue in self.task_queues.values():
            processing = len(queue.processing_tasks)
            queued = sum(len(queue.priority_queues[p]) for p in range(4))
            total_load = processing + queued
            max_capacity = queue.max_concurrent_tasks + 20
            load_rate = total_load / max_capacity
            load_rates.append(load_rate)

        load_std = np.std(load_rates)

        # Reward calculation (raised tiers)
        if load_std < 0.1:
            balance_reward = +15.0  # Raised (was +10.0)
        elif load_std < 0.2:
            balance_reward = +10.0 - (load_std - 0.1) * 40.0  # [+10, +6]
        elif load_std < 0.3:
            balance_reward = +4.0 - (load_std - 0.2) * 15.0   # [+4, +2.5]
        elif load_std < 0.5:
            balance_reward = 0.0 - (load_std - 0.3) * 5.0    # [0, -1.0]
        else:
            balance_reward = -2.0 - min((load_std - 0.5) * 8.0, 4.0)  # [-2, -6]

        # Remove suppression while idle
        # Previously: if load_mean < 0.2: balance_reward *= 0.5
        # Changed to: always give the full balance reward to encourage learning

        return np.clip(balance_reward, -6.0, 15.0)

    def _partner_accepts(self, partner_id: str, task: Task) -> bool:
        """
        Collaboration partner accept/refuse mechanism (an environment-enforced rule, not a policy action).

        Note: this is a deterministic admission rule built into the environment, not an independent action output by the policy network;
        the paper accordingly removes the "participation zeta" term and the learnable "anti-refusal" formulation, describing it faithfully
        as admission control. The selected partner does not accept unconditionally: it refuses collaboration requests when it is overloaded or low on battery,
        avoiding offloading tasks to a node that cannot bear them (reflecting realistic self-interested/self-preserving behavior).

        Refusal conditions (refuse if any holds):
        - Partner queue load rate > accept_load_thresh (default 0.9, near full)
        - Partner concurrent processing slots are full
        - Partner battery < accept_batt_thresh (default 0.1, low-battery self-preservation)
        Returns True=accept, False=refuse.
        """
        partner_queue = self.task_queues.get(partner_id)
        if partner_queue is None:
            return False
        # Concurrent slots are full -> refuse
        if len(partner_queue.processing_tasks) >= partner_queue.max_concurrent_tasks:
            return False
        # Low-battery self-preservation -> refuse (independent of priority, a hard constraint)
        batt = self.energy_manager.get_battery_percentage(partner_id)
        if batt < self.accept_batt_thresh:
            return False

        cap = self.drone_capacities.get(partner_id, 400e9)
        partner_load = self._flops_load_rate(partner_queue, cap)

        # === Reinforcement (scheme B1): priority-aware acceptance threshold (resource-contention arbitration) ===
        # Problem: under contention, fast partners are filled by large MED tasks, HIGH cannot grab one -> timeout.
        # Solution: adjust the partner's load acceptance threshold by the initiating task's priority -- a HIGH request is accepted even if the partner is fairly busy
        # (HIGH preferentially locks in fast partners); a LOW/BG request is refused once the partner reaches medium load (yielding to potential HIGH).
        # Ablation (ablate_priority_arbitration=True): all priorities use the same threshold, HIGH is no longer prioritized.
        if self.ablate_priority_arbitration:
            eff_thresh = self.accept_load_thresh
        else:
            # Contention arbitration: tighten low-priority occupancy of partners (LOW/BG refused earlier), freeing fast-node compute for HIGH.
            # HIGH/MED keep the baseline threshold (do not force HIGH onto busy nodes -- a HIGH small task crowding a busy node is actually slower).
            # Effect: low priority no longer preempts fast partners -> HIGH more easily finds a lightly-loaded fast partner or completes quickly locally.
            prio_thresh_scale = {
                TaskPriority.HIGH: 1.0,        # Baseline (no increase)
                TaskPriority.MEDIUM: 1.0,      # Baseline
                TaskPriority.LOW: 0.55,        # Greatly tightened -> refuse LOW at light-to-medium load
                TaskPriority.BACKGROUND: 0.4,  # Refuse BG earliest, freeing fast nodes for HIGH/MED
            }
            eff_thresh = self.accept_load_thresh * prio_thresh_scale.get(task.priority, 1.0)
            eff_thresh = min(eff_thresh, 1.0)

        if partner_load > eff_thresh:
            return False
        return True

    def _calculate_partner_reward(self, task: Task, processing_time: float,
                                  partner_id: str) -> float:
        """
        Compute the partner's reward (fixes the issue of partners receiving no reward).

        The partner should receive:
        1. A base cooperation reward (encourages helping others)
        2. An efficiency reward (the faster the processing, the higher the reward)
        3. A load reward (helping while busy earns an extra reward)

        Args:
            task: task object
            processing_time: processing time (seconds)
            partner_id: partner ID

        Returns:
            The partner's reward value [0, +10]
        """
        # 1. Base reward: successfully helping another complete a task
        priority_weights = {
            TaskPriority.HIGH: 2.0,
            TaskPriority.MEDIUM: 1.5,
            TaskPriority.LOW: 1.0,
            TaskPriority.BACKGROUND: 0.5
        }
        base_reward = 1.0 * priority_weights.get(task.priority, 1.0)

        # 2. Efficiency reward: the faster the processing, the higher the reward
        # Assume 0.05s is a fast processing time and 0.15s is slow
        if processing_time < 0.05:
            efficiency_bonus = 2.0  # Very fast
        elif processing_time < 0.10:
            efficiency_bonus = 1.0  # Normal
        else:
            efficiency_bonus = 0.0  # Slow

        # 3. Load reward: helping while busy earns an extra reward
        partner_queue = self.task_queues.get(partner_id)
        if partner_queue:
            processing_count = len(partner_queue.processing_tasks)
            total_queued = sum(len(partner_queue.priority_queues[p])
                              for p in range(4))
            partner_load = (processing_count + total_queued) / \
                          (partner_queue.max_concurrent_tasks + 20)

            if partner_load > 0.7:
                load_bonus = 2.0  # Very busy yet helping, high reward
            elif partner_load > 0.5:
                load_bonus = 1.5  # Medium load
            elif partner_load > 0.3:
                load_bonus = 1.0  # Light load
            else:
                load_bonus = 0.8  # Idle (reward slightly lower, because it is too easy)
        else:
            load_bonus = 1.0

        # Combined reward
        total_partner_reward = (base_reward + efficiency_bonus) * load_bonus

        # Clip to range [0, +10]
        return np.clip(total_partner_reward, 0.0, 10.0)

    def _get_info(self) -> dict:
        """Get extra info. **Adds status info for all drones**."""
        # Collect the queue state of all drones
        drone_queue_states = {}
        total_pending_tasks = 0
        total_processing_tasks = 0

        for drone_id, queue in self.task_queues.items():
            queue_lengths, queue_load, busy_rate = queue.get_queue_state(self.current_time)
            pending_tasks = sum(queue_lengths)
            processing_tasks = len(queue.processing_tasks)

            drone_queue_states[drone_id] = {
                'pending_tasks': pending_tasks,
                'processing_tasks': processing_tasks,
                'completed_tasks': len(queue.completed_tasks),
                'busy_rate': busy_rate
            }

            total_pending_tasks += pending_tasks
            total_processing_tasks += processing_tasks

        # === Reliability convention with "all arrived tasks" as the denominator ===
        s = self.episode_stats
        met = s.get("deadline_met", 0)
        viol = s.get("deadline_violations", 0)
        expired = s.get("tasks_expired", 0)   # Pending-queue timeout drops (drop)
        failed = s.get("tasks_failed", 0)     # Collaboration-link failures, unrecoverable (failure)
        arrived = s.get("tasks_generated", 0)
        # Denominator = all arrived tasks; timeout drops and link failures both count as unmet (miss), no longer vanishing from the denominator
        denom_all = max(1, met + viol + expired + failed)
        deadline_sat_all = met / denom_all           # Deadline satisfaction rate under the strict denominator
        failure_rate = failed / max(1, arrived)       # Link failure rate (reported separately)
        drop_rate = expired / max(1, arrived)         # Timeout drop rate (reported separately)

        # === Constraint violation rate (battery/queue) ===
        battery_viol = s.get("battery_violations", 0)
        battery_violation_rate = battery_viol / max(1, arrived)
        # Queue-level drops/preemptions (counted inside task_queue, passed through in aggregate)
        queue_dropped = sum(getattr(q, 'total_dropped', 0) for q in self.task_queues.values())
        queue_preempted = sum(getattr(q, 'total_preempted', 0) for q in self.task_queues.values())

        return {
            "current_time": self.current_time,
            "episode_step": self.episode_step,
            "tasks_completed": self.episode_stats["tasks_completed"],
            "collaborative_tasks": self.episode_stats["collaborative_tasks"],
            "independent_tasks": self.episode_stats["independent_tasks"],
            "total_reward": self.episode_stats["total_reward"],
            "avg_latency": (self.episode_stats["total_latency"] /
                           max(1, self.episode_stats["tasks_completed"])),
            "communication_ratio": (self.episode_stats["collaborative_tasks"] /
                                   max(1, self.episode_stats["tasks_completed"])),
            "total_flops": self.episode_stats["total_flops"],  # Added: total FLOPs
            # === Reliability statistics (all arrived tasks as the denominator) ===
            "tasks_generated": arrived,
            "tasks_expired": expired,
            "tasks_failed": failed,
            "deadline_met": met,
            "deadline_violations": viol,
            "deadline_sat_all": deadline_sat_all,   # Deadline satisfaction rate under the strict denominator
            "failure_rate": failure_rate,           # Link failure rate
            "drop_rate": drop_rate,                 # Timeout drop rate
            "collab_refused": s.get("collab_refused", 0),
            "link_fallbacks": s.get("link_fallbacks", 0),
            # === Constraint violation rate ===
            "battery_violations": battery_viol,
            "battery_violation_rate": battery_violation_rate,
            "queue_dropped": queue_dropped,
            "queue_preempted": queue_preempted,
            # === Energy breakdown ===
            "total_energy": s.get("total_energy", 0.0),
            "idle_energy": s.get("idle_energy", 0.0),
            "link_migrations": s.get("link_migrations", 0),
            "link_interruptions": s.get("link_interruptions", 0),
            # **Added: all drone states**
            "drone_states": drone_queue_states,
            "total_pending_tasks": total_pending_tasks,
            "total_processing_tasks": total_processing_tasks,
            "system_utilization": total_processing_tasks / (len(self.task_queues) * 5)  # 5 is max_concurrent_tasks
        }

    def render(self, mode='human'):
        """Render the environment (optional implementation)."""
        if mode == 'human':
            info = self._get_info()
            print(f"Time: {info['current_time']:.1f}s | "
                  f"Completed: {info['tasks_completed']} | "
                  f"Collaboration rate: {info['communication_ratio']:.1%} | "
                  f"Total reward: {info['total_reward']:.1f}")

    def close(self):
        """Close the environment."""
        pass


if __name__ == "__main__":
    # Test the environment
    print("Testing the DroneCollaborationEnv environment...")

    # Create the environment
    env = DroneCollaborationEnv(num_drones=5, simulation_time=10.0)

    print(f"State space dimension: {env.observation_space.shape}")
    print(f"Action space size: {env.action_space.n}")

    # Run a few test steps
    obs, info = env.reset()
    print(f"Initial observation: {obs}")
    print(f"Initial info: {info}")

    total_reward = 0.0
    for step in range(10):
        action = env.action_space.sample()  # Random action
        obs, reward, terminated, truncated, info = env.step(action)
        total_reward += reward

        print(f"Step {step+1}: action={action}, reward={reward:.2f}, completed tasks={info['tasks_completed']}")

        if terminated or truncated:
            break

    print(f"Test complete, total reward: {total_reward:.2f}")
    env.close()