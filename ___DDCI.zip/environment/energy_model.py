"""
Drone energy consumption model

Models three types of energy consumption:
1. Compute energy: related to FLOPS and compute capacity
2. Communication energy: related to data size and distance
3. Idle energy: base power consumption
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Dict, Optional


@dataclass
class DroneEnergyConfig:
    """Drone energy consumption configuration"""
    # Compute power coefficients (re-calibrated for the 160-800 GFLOPS range after compute capacity x40)
    # Power model P = base_power + k_compute · cap_gflops^1.3
    # Calibration points: cap=472 (Jetson Nano) -> ~10W, cap=160 -> ~4W, cap=800 -> ~18W (TX2 range)
    compute_power_base: float = 2.0      # Base compute power (W)
    compute_power_per_gflops: float = 0.0027  # k_compute, super-linear coefficient

    # Communication power (W)
    tx_power_base: float = 0.5  # Base transmit power 0.5W
    tx_power_per_100m: float = 0.3  # Extra power per 100m: 0.3W
    rx_power: float = 0.3  # Receive power 0.3W (collaborator's feature-map receive energy, typical WiFi RX value)

    # Idle power (W)
    idle_power: float = 1.0  # 1W when idle

    # Battery capacity (Wh)
    battery_capacity_wh: float = 100.0  # 100Wh battery

    # Energy efficiency factor (higher-capacity nodes are more energy efficient)
    efficiency_factor: float = 1.0  # 1.0 is the baseline


@dataclass
class DroneEnergyState:
    """Drone energy state"""
    battery_remaining_wh: float  # Remaining battery (Wh)
    battery_capacity_wh: float  # Battery capacity (Wh)
    total_energy_consumed_wh: float = 0.0  # Cumulative consumption (Wh)

    @property
    def battery_percentage(self) -> float:
        """Battery percentage [0, 1]"""
        return self.battery_remaining_wh / self.battery_capacity_wh

    @property
    def is_low_battery(self) -> bool:
        """Whether battery is low (<20%)"""
        return self.battery_percentage < 0.2

    @property
    def is_critical_battery(self) -> bool:
        """Whether battery is critical (<10%)"""
        return self.battery_percentage < 0.1


class DroneEnergyModel:
    """
    Drone energy consumption model

    Energy computation:
    - Compute energy = FLOPS * power coefficient / efficiency factor
    - Communication energy = (base power + distance power) * transmission time
    - Idle energy = idle power * idle time
    """

    def __init__(self, config: Optional[DroneEnergyConfig] = None):
        self.config = config or DroneEnergyConfig()

    def calculate_compute_energy(
        self,
        flops: float,
        drone_capacity_gflops: float,
        efficiency_factor: float = 1.0
    ) -> float:
        """
        Compute the compute energy (non-linear power model)

        Power model: P = base + k * capacity^1.3
        - Emulates the DVFS effect: high-frequency / high-capacity nodes have super-linear power growth
        - But processing time shrinks linearly, so high-capacity nodes are more energy efficient
        - Low-capacity node (4 GFLOPS): ~9.9W, efficiency 0.40 GFLOPS/W
        - High-capacity node (20 GFLOPS): ~35.5W, efficiency 0.56 GFLOPS/W

        Args:
            flops: Computation amount (FLOPS)
            drone_capacity_gflops: Drone compute capacity (GFLOPS/s)
            efficiency_factor: Energy efficiency factor

        Returns:
            Energy consumption (Wh)
        """
        # Compute time (seconds)
        compute_time_s = flops / (drone_capacity_gflops * 1e9)

        # Non-linear power model: P = base_power + k_compute * capacity^1.3
        # (re-calibrated for compute capacity x40: P ≈ 10W at cap ~472 GFLOPS, Jetson Nano range)
        # Make power grow faster than linear but slower than quadratic, so high-capacity nodes are more efficient
        base_power_w = self.config.compute_power_base
        dynamic_power_w = self.config.compute_power_per_gflops * (drone_capacity_gflops ** 1.3)

        compute_power_w = base_power_w + dynamic_power_w

        # Apply energy efficiency factor
        effective_power_w = compute_power_w / efficiency_factor

        # Energy (Wh) = power * time / 3600
        energy_wh = effective_power_w * compute_time_s / 3600.0

        return energy_wh

    def calculate_comm_energy(
        self,
        data_size_mb: float,
        distance_m: float,
        bandwidth_mbps: float
    ) -> Dict[str, float]:
        """
        Compute communication energy (counts both transmitter and receiver energy)

        Args:
            data_size_mb: Data size (MB)
            distance_m: Communication distance (m)
            bandwidth_mbps: Bandwidth (Mbps)

        Returns:
            {'tx_energy': transmitter energy (Wh), 'rx_energy': receiver energy (Wh)}
        """
        # Transmission time (seconds)
        transmission_time_s = (data_size_mb * 8) / bandwidth_mbps

        # Transmit power (W) = base power + distance-related power
        tx_power_w = (
            self.config.tx_power_base +
            (distance_m / 100.0) * self.config.tx_power_per_100m
        )
        # Receive power (W): fixed receive-chain power independent of distance
        rx_power_w = self.config.rx_power

        # Energy (Wh) = power * time / 3600
        tx_energy_wh = tx_power_w * transmission_time_s / 3600.0
        rx_energy_wh = rx_power_w * transmission_time_s / 3600.0

        return {'tx_energy': tx_energy_wh, 'rx_energy': rx_energy_wh}

    def calculate_idle_energy(self, idle_time_s: float) -> float:
        """
        Compute idle energy

        Args:
            idle_time_s: Idle time (seconds)

        Returns:
            Energy consumption (Wh)
        """
        return self.config.idle_power * idle_time_s / 3600.0

    def calculate_task_energy(
        self,
        task_flops: float,
        drone_capacity_gflops: float,
        partner_capacity_gflops: float,
        cut_ratio: float,
        distance_m: float,
        data_size_mb: float,
        bandwidth_mbps: float,
        is_local: bool = False
    ) -> Dict[str, float]:
        """
        Compute the total energy of completing one task

        Args:
            task_flops: Task computation amount
            drone_capacity_gflops: Local compute capacity
            partner_capacity_gflops: Collaborator compute capacity
            cut_ratio: Partition ratio (fraction processed locally)
            distance_m: Distance to the collaborator
            data_size_mb: Transmitted data size
            bandwidth_mbps: Bandwidth
            is_local: Whether processed locally

        Returns:
            Dict with energy details
        """
        if is_local:
            # Local processing: compute energy only
            compute_energy = self.calculate_compute_energy(
                task_flops, drone_capacity_gflops
            )
            return {
                'compute_energy': compute_energy,
                'comm_energy': 0.0,
                'partner_compute_energy': 0.0,
                'initiator_energy': compute_energy,
                'total_energy': compute_energy
            }
        else:
            # Collaborative processing
            # Local compute energy (Part A: first cut layers, cut_ratio fraction)
            local_flops = task_flops * cut_ratio
            local_compute_energy = self.calculate_compute_energy(
                local_flops, drone_capacity_gflops
            )

            # Communication energy (initiator transmit tx + collaborator receive rx)
            comm = self.calculate_comm_energy(
                data_size_mb, distance_m, bandwidth_mbps
            )
            tx_energy = comm['tx_energy']
            rx_energy = comm['rx_energy']

            # Collaborator compute energy (Part B: later layers, 1-cut_ratio fraction, using collaborator capacity)
            remote_flops = task_flops * (1.0 - cut_ratio)
            partner_compute_energy = self.calculate_compute_energy(
                remote_flops, partner_capacity_gflops
            )

            # Initiator-side energy (drawn from initiator battery: local compute + transmit)
            initiator_energy = local_compute_energy + tx_energy
            # Collaborator-side energy (drawn from collaborator battery: remote compute + receive)
            partner_energy = partner_compute_energy + rx_energy
            # System total energy (honest accounting: compute (local + remote) + communication (transmit + receive))
            total_energy = local_compute_energy + tx_energy + rx_energy + partner_compute_energy

            return {
                'compute_energy': local_compute_energy,
                'comm_energy': tx_energy + rx_energy,   # Total communication energy (tx+rx)
                'tx_energy': tx_energy,
                'rx_energy': rx_energy,
                'partner_compute_energy': partner_energy,  # Includes collaborator receive energy
                'initiator_energy': initiator_energy,
                'total_energy': total_energy  # System total energy (compute + bidirectional communication)
            }


class DroneEnergyManager:
    """
    Drone energy manager

    Manages the energy state of multiple drones
    """

    def __init__(self, num_drones: int = 10, battery_capacity_wh: float = 100.0):
        self.num_drones = num_drones
        self.battery_capacity_wh = battery_capacity_wh
        self.energy_model = DroneEnergyModel()

        # Initialize the energy state of each drone
        self.drone_states: Dict[str, DroneEnergyState] = {}
        self._init_drone_states()

    def _init_drone_states(self):
        """Initialize the energy state of all drones"""
        for i in range(self.num_drones):
            drone_id = f"drone_{i}"
            self.drone_states[drone_id] = DroneEnergyState(
                battery_remaining_wh=self.battery_capacity_wh,
                battery_capacity_wh=self.battery_capacity_wh
            )

    def consume_energy(self, drone_id: str, energy_wh: float) -> bool:
        """
        Consume energy

        Args:
            drone_id: Drone ID
            energy_wh: Energy consumed (Wh)

        Returns:
            Whether it succeeded (whether the battery was sufficient)
        """
        if drone_id not in self.drone_states:
            return False

        state = self.drone_states[drone_id]

        if state.battery_remaining_wh < energy_wh:
            # Insufficient battery
            state.battery_remaining_wh = 0
            return False

        state.battery_remaining_wh -= energy_wh
        state.total_energy_consumed_wh += energy_wh
        return True

    def get_battery_percentage(self, drone_id: str) -> float:
        """Get battery percentage"""
        if drone_id not in self.drone_states:
            return 0.0
        return self.drone_states[drone_id].battery_percentage

    def get_total_energy_consumed(self) -> float:
        """Get the total energy consumption of all drones"""
        return sum(s.total_energy_consumed_wh for s in self.drone_states.values())

    def get_average_battery_percentage(self) -> float:
        """Get the average battery percentage"""
        if not self.drone_states:
            return 0.0
        return np.mean([s.battery_percentage for s in self.drone_states.values()])

    def reset(self):
        """Reset the energy state of all drones"""
        self._init_drone_states()

    def get_energy_stats(self) -> Dict:
        """Get energy statistics"""
        percentages = [s.battery_percentage for s in self.drone_states.values()]
        consumed = [s.total_energy_consumed_wh for s in self.drone_states.values()]

        return {
            'avg_battery_percentage': np.mean(percentages),
            'min_battery_percentage': np.min(percentages),
            'max_battery_percentage': np.max(percentages),
            'total_energy_consumed': sum(consumed),
            'avg_energy_consumed': np.mean(consumed),
            'low_battery_count': sum(1 for s in self.drone_states.values() if s.is_low_battery),
            'critical_battery_count': sum(1 for s in self.drone_states.values() if s.is_critical_battery)
        }
