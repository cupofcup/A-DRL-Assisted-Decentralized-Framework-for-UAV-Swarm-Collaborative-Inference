"""
Spatial manager: handles drone positions, mobility, and spatial topology.

Based on the mathematical model in CLAUDE.md:
- Position coordinates: p_i(t) in R^2
- Neighbor set: N_i(t) = {u_j : ||p_i(t) - p_j(t)|| <= R_comm, j != i}
- Distance computation: d_{i,j} = ||p_i(t) - p_j(t)||
"""

import math
import numpy as np
from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass, field
from enum import Enum
import time

class MovementPattern(Enum):
    """Drone movement patterns."""
    STATIONARY = "stationary"      # Stationary
    RANDOM_WALK = "random_walk"    # Random walk
    CIRCULAR = "circular"          # Circular trajectory
    LINEAR = "linear"             # Linear motion
    FORMATION = "formation"       # Formation flight
    TASK_AWARE = "task_aware"     # Task-aware / coverage movement (R1.5)

@dataclass
class DroneState:
    """Drone spatial state."""
    drone_id: str
    position: Tuple[float, float]
    velocity: Tuple[float, float] = (0.0, 0.0)  # m/s
    heading: float = 0.0          # radians, 0 points due east
    altitude: float = 100.0       # meters, altitude above ground
    communication_radius: float = 200.0  # communication radius
    last_update_time: float = field(default_factory=time.time)

    # Motion parameters
    movement_pattern: MovementPattern = MovementPattern.STATIONARY
    target_position: Optional[Tuple[float, float]] = None
    max_speed: float = 20.0       # m/s, maximum speed

    # State flags
    is_active: bool = True
    battery_level: float = 1.0    # 0-1, battery level
    processing_load: float = 0.0  # 0-1, compute load

@dataclass
class SpatialConfiguration:
    """Spatial configuration parameters."""
    area_bounds: Tuple[Tuple[float, float], Tuple[float, float]] = ((-1000, -1000), (1000, 1000))
    default_comm_radius: float = 200.0  # default communication radius
    position_update_interval: float = 1.0  # position update interval (seconds)
    enable_mobility: bool = True
    collision_avoidance_radius: float = 10.0  # collision avoidance radius

    # Environment parameters
    wind_speed: float = 0.0       # m/s
    wind_direction: float = 0.0   # radians
    terrain_factor: float = 1.0   # terrain influence factor

class SpatialManager:
    """
    Core spatial manager class.

    Responsibilities:
    1. Drone position management and real-time updates
    2. Neighbor discovery and topology maintenance
    3. Mobility modeling and path planning
    4. Spatial constraints and collision detection
    5. Integration with the communication module
    """
    
    def __init__(self, config: SpatialConfiguration = None):
        self.config = config or SpatialConfiguration()
        
        # Core data structures
        self.drones: Dict[str, DroneState] = {}
        self.neighbor_graph: Dict[str, Set[str]] = {}

        # Performance optimization: spatial index
        self.grid_size = 100.0  # grid cell size, used for spatial partitioning
        self.spatial_grid: Dict[Tuple[int, int], Set[str]] = {}

        # Time management
        self.current_time = 0.0
        self.last_update_time = 0.0

        # Statistics
        self.topology_changes = 0
        self.position_updates = 0
        
    def register_drone(self, drone_id: str, initial_position: Tuple[float, float],
                      comm_radius: float = None, movement_pattern: MovementPattern = MovementPattern.STATIONARY) -> bool:
        """Register a new drone."""
        if drone_id in self.drones:
            return False

        # Check whether the position is within bounds
        if not self._is_position_valid(initial_position):
            raise ValueError(f"Position {initial_position} is outside area bounds")

        # Create the drone state
        drone_state = DroneState(
            drone_id=drone_id,
            position=initial_position,
            communication_radius=comm_radius or self.config.default_comm_radius,
            movement_pattern=movement_pattern
        )

        # Register with the manager
        self.drones[drone_id] = drone_state
        self.neighbor_graph[drone_id] = set()

        # Update the spatial index
        self._update_spatial_index(drone_id, initial_position)
        
        print(f"Registered drone {drone_id} at position {initial_position}")
        return True
        
    def unregister_drone(self, drone_id: str) -> bool:
        """Unregister a drone."""
        if drone_id not in self.drones:
            return False

        # Remove from the spatial index
        old_pos = self.drones[drone_id].position
        self._remove_from_spatial_index(drone_id, old_pos)

        # Remove all connections from the neighbor graph
        for neighbor_id in self.neighbor_graph[drone_id]:
            self.neighbor_graph[neighbor_id].discard(drone_id)

        # Remove the drone
        del self.drones[drone_id]
        del self.neighbor_graph[drone_id]
        
        self.topology_changes += 1
        print(f"Unregistered drone {drone_id}")
        return True
        
    def update_drone_position(self, drone_id: str, new_position: Tuple[float, float],
                            new_velocity: Tuple[float, float] = (0.0, 0.0)) -> bool:
        """Update a drone's position."""
        if drone_id not in self.drones:
            return False

        if not self._is_position_valid(new_position):
            return False

        drone = self.drones[drone_id]
        old_position = drone.position

        # Update position and velocity
        drone.position = new_position
        drone.velocity = new_velocity
        drone.last_update_time = time.time()

        # Compute the heading angle
        if new_velocity[0] != 0 or new_velocity[1] != 0:
            drone.heading = math.atan2(new_velocity[1], new_velocity[0])

        # Update the spatial index
        self._remove_from_spatial_index(drone_id, old_position)
        self._update_spatial_index(drone_id, new_position)
        
        self.position_updates += 1
        return True
        
    def get_neighbors_within_range(self, drone_id: str, range_meters: float = None) -> List[str]:
        """Get the list of neighbors within the given range."""
        if drone_id not in self.drones:
            return []

        drone = self.drones[drone_id]
        search_radius = range_meters or drone.communication_radius
        drone_pos = drone.position

        neighbors = []

        # Use the spatial index to speed up the search
        candidate_cells = self._get_nearby_cells(drone_pos, search_radius)
        
        for cell in candidate_cells:
            if cell not in self.spatial_grid:
                continue
                
            for candidate_id in self.spatial_grid[cell]:
                if candidate_id == drone_id:
                    continue
                    
                candidate_pos = self.drones[candidate_id].position
                distance = self._calculate_distance(drone_pos, candidate_pos)
                
                if distance <= search_radius and self.drones[candidate_id].is_active:
                    neighbors.append(candidate_id)
                    
        return neighbors
        
    def get_all_neighbors(self, drone_id: str) -> List[str]:
        """Get all neighbors (within communication range)."""
        return self.get_neighbors_within_range(drone_id)

    def calculate_distance(self, drone_a: str, drone_b: str) -> float:
        """Compute the distance between two drones."""
        if drone_a not in self.drones or drone_b not in self.drones:
            return float('inf')
            
        pos_a = self.drones[drone_a].position
        pos_b = self.drones[drone_b].position
        
        return self._calculate_distance(pos_a, pos_b)
        
    def update_topology(self) -> int:
        """Update the network topology. Returns the number of topology changes."""
        changes = 0

        # Rebuild the neighbor list for each active drone
        for drone_id in self.drones:
            if not self.drones[drone_id].is_active:
                continue

            old_neighbors = self.neighbor_graph[drone_id].copy()
            new_neighbors = set(self.get_all_neighbors(drone_id))

            # Check for changes
            if old_neighbors != new_neighbors:
                changes += 1
                self.neighbor_graph[drone_id] = new_neighbors

                # Ensure symmetry
                for neighbor_id in new_neighbors:
                    self.neighbor_graph[neighbor_id].add(drone_id)

                for old_neighbor_id in old_neighbors - new_neighbors:
                    self.neighbor_graph[old_neighbor_id].discard(drone_id)
                    
        self.topology_changes += changes
        return changes
        
    def simulate_movement(self, time_step: float) -> None:
        """Simulate drone movement."""
        if not self.config.enable_mobility:
            return

        self.current_time += time_step
        
        for drone_id, drone in self.drones.items():
            if not drone.is_active:
                continue
                
            new_position = self._calculate_next_position(drone, time_step)
            new_velocity = self._calculate_velocity(drone, time_step)
            
            self.update_drone_position(drone_id, new_position, new_velocity)
            
    def _calculate_next_position(self, drone: DroneState, time_step: float) -> Tuple[float, float]:
        """Compute the next position."""
        current_pos = drone.position
        current_vel = drone.velocity

        if drone.movement_pattern == MovementPattern.STATIONARY:
            return current_pos

        elif drone.movement_pattern == MovementPattern.RANDOM_WALK:
            # Random walk
            angle_change = np.random.uniform(-np.pi/4, np.pi/4)  # +/-45 degrees
            speed = min(np.random.uniform(0, drone.max_speed), drone.max_speed)
            
            new_angle = drone.heading + angle_change
            vel_x = speed * math.cos(new_angle)
            vel_y = speed * math.sin(new_angle)
            
            new_x = current_pos[0] + vel_x * time_step
            new_y = current_pos[1] + vel_y * time_step
            
        elif drone.movement_pattern == MovementPattern.LINEAR:
            # Linear motion
            new_x = current_pos[0] + current_vel[0] * time_step
            new_y = current_pos[1] + current_vel[1] * time_step

        elif drone.movement_pattern == MovementPattern.CIRCULAR:
            # Circular trajectory
            radius = 50.0  # 50-meter radius
            angular_speed = 0.1  # rad/s

            center_x, center_y = 0.0, 0.0  # circle center
            angle = self.current_time * angular_speed
            
            new_x = center_x + radius * math.cos(angle)
            new_y = center_y + radius * math.sin(angle)
            
        else:  # TARGET_POSITION or TASK_AWARE
            if drone.movement_pattern == MovementPattern.TASK_AWARE:
                # Task-aware / coverage movement (R1.5):
                # 1. With a target (task hotspot), move toward it + small random perturbation (avoid straight lines)
                # 2. Without a target, perform a random patrol with inertia (cover the area)
                # 3. Repulsion force: move away from other UAVs that are too close (avoid clustering, maintain coverage)
                repulsion_radius = 60.0  # repulsion radius (meters)
                repulsion_strength = 0.3  # repulsion force weight

                # Repulsion force: move away from neighbors that are too close
                rep_x, rep_y = 0.0, 0.0
                for other_id, other_drone in self.drones.items():
                    if other_id == drone.drone_id or not other_drone.is_active:
                        continue
                    dx = current_pos[0] - other_drone.position[0]
                    dy = current_pos[1] - other_drone.position[1]
                    d = math.sqrt(dx**2 + dy**2)
                    if 0 < d < repulsion_radius:
                        # Inverse-proportional repulsion
                        rep_x += (dx / d) * (repulsion_radius - d) / repulsion_radius
                        rep_y += (dy / d) * (repulsion_radius - d) / repulsion_radius

                if drone.target_position:
                    # Task hotspot present: move toward target + repulsion + small perturbation
                    target_x, target_y = drone.target_position
                    dx = target_x - current_pos[0]
                    dy = target_y - current_pos[1]
                    distance = math.sqrt(dx**2 + dy**2)
                    if distance > 2.0:
                        # Normalized direction + repulsion + random perturbation
                        dir_x = dx / distance + rep_x * repulsion_strength
                        dir_y = dy / distance + rep_y * repulsion_strength
                        # Add a small random perturbation to avoid head-on collisions
                        dir_x += np.random.uniform(-0.2, 0.2)
                        dir_y += np.random.uniform(-0.2, 0.2)
                        norm = math.sqrt(dir_x**2 + dir_y**2) or 1.0
                        speed = min(drone.max_speed, distance / time_step)
                        new_x = current_pos[0] + (dir_x / norm) * speed * time_step
                        new_y = current_pos[1] + (dir_y / norm) * speed * time_step
                    else:
                        # Target reached, clear it
                        drone.target_position = None
                        new_x, new_y = current_pos
                else:
                    # No target: random patrol with inertia (like random-walk but smoother) + repulsion
                    angle_change = np.random.uniform(-np.pi/6, np.pi/6)  # +/-30 degrees (smoother)
                    speed = np.random.uniform(drone.max_speed * 0.3, drone.max_speed * 0.7)
                    new_angle = drone.heading + angle_change
                    dir_x = math.cos(new_angle) + rep_x * repulsion_strength
                    dir_y = math.sin(new_angle) + rep_y * repulsion_strength
                    norm = math.sqrt(dir_x**2 + dir_y**2) or 1.0
                    new_x = current_pos[0] + (dir_x / norm) * speed * time_step
                    new_y = current_pos[1] + (dir_y / norm) * speed * time_step

            elif drone.target_position:
                # Move toward the target position
                target_x, target_y = drone.target_position
                dx = target_x - current_pos[0]
                dy = target_y - current_pos[1]

                distance = math.sqrt(dx**2 + dy**2)
                if distance > 1.0:  # if the distance is greater than 1 meter
                    # Normalized direction vector
                    move_distance = min(drone.max_speed * time_step, distance)
                    new_x = current_pos[0] + (dx / distance) * move_distance
                    new_y = current_pos[1] + (dy / distance) * move_distance
                else:
                    new_x, new_y = target_x, target_y
            else:
                new_x, new_y = current_pos

        # Boundary check
        min_x, min_y = self.config.area_bounds[0]
        max_x, max_y = self.config.area_bounds[1]
        
        new_x = max(min_x, min(max_x, new_x))
        new_y = max(min_y, min(max_y, new_y))
        
        return (new_x, new_y)
        
    def _calculate_velocity(self, drone: DroneState, time_step: float) -> Tuple[float, float]:
        """Compute the velocity vector."""
        old_pos = drone.position
        new_pos = self._calculate_next_position(drone, time_step)
        
        vel_x = (new_pos[0] - old_pos[0]) / time_step if time_step > 0 else 0
        vel_y = (new_pos[1] - old_pos[1]) / time_step if time_step > 0 else 0
        
        return (vel_x, vel_y)
        
    def _is_position_valid(self, position: Tuple[float, float]) -> bool:
        """Check whether the position is valid."""
        x, y = position
        min_x, min_y = self.config.area_bounds[0]
        max_x, max_y = self.config.area_bounds[1]
        
        return min_x <= x <= max_x and min_y <= y <= max_y
        
    def _calculate_distance(self, pos1: Tuple[float, float], pos2: Tuple[float, float]) -> float:
        """Compute the Euclidean distance."""
        return math.sqrt((pos2[0] - pos1[0])**2 + (pos2[1] - pos1[1])**2)
        
    def _get_grid_cell(self, position: Tuple[float, float]) -> Tuple[int, int]:
        """Get the grid cell corresponding to a position."""
        x, y = position
        cell_x = int(x // self.grid_size)
        cell_y = int(y // self.grid_size)
        return (cell_x, cell_y)
        
    def _get_nearby_cells(self, position: Tuple[float, float], radius: float) -> List[Tuple[int, int]]:
        """Get all grid cells within the given radius."""
        cells = []
        center_cell = self._get_grid_cell(position)

        # Compute the range of grid cells to check
        cell_radius = int(math.ceil(radius / self.grid_size))
        
        for dx in range(-cell_radius, cell_radius + 1):
            for dy in range(-cell_radius, cell_radius + 1):
                cell = (center_cell[0] + dx, center_cell[1] + dy)
                cells.append(cell)
                
        return cells
        
    def _update_spatial_index(self, drone_id: str, position: Tuple[float, float]) -> None:
        """Update the spatial index."""
        cell = self._get_grid_cell(position)
        
        if cell not in self.spatial_grid:
            self.spatial_grid[cell] = set()
            
        self.spatial_grid[cell].add(drone_id)
        
    def _remove_from_spatial_index(self, drone_id: str, position: Tuple[float, float]) -> None:
        """Remove from the spatial index."""
        cell = self._get_grid_cell(position)

        if cell in self.spatial_grid:
            self.spatial_grid[cell].discard(drone_id)

            # Clean up empty grid cells
            if not self.spatial_grid[cell]:
                del self.spatial_grid[cell]

    def get_drone_state(self, drone_id: str) -> Optional[DroneState]:
        """Get a drone's state."""
        return self.drones.get(drone_id)

    def get_all_active_drones(self) -> List[str]:
        """Get all active drones."""
        return [drone_id for drone_id, drone in self.drones.items() if drone.is_active]

    def get_network_topology(self) -> Dict[str, List[str]]:
        """Get the current network topology."""
        return {drone_id: list(neighbors) for drone_id, neighbors in self.neighbor_graph.items()}

    def get_spatial_statistics(self) -> Dict:
        """Get spatial statistics."""
        if not self.drones:
            return {"total_drones": 0}
            
        positions = [drone.position for drone in self.drones.values()]

        # Compute the centroid
        center_x = sum(pos[0] for pos in positions) / len(positions)
        center_y = sum(pos[1] for pos in positions) / len(positions)

        # Compute the average number of neighbors
        neighbor_counts = [len(neighbors) for neighbors in self.neighbor_graph.values()]
        avg_neighbors = sum(neighbor_counts) / len(neighbor_counts) if neighbor_counts else 0

        # Compute network connectivity
        total_possible_connections = len(self.drones) * (len(self.drones) - 1) // 2
        actual_connections = sum(len(neighbors) for neighbors in self.neighbor_graph.values()) // 2
        connectivity = actual_connections / total_possible_connections if total_possible_connections > 0 else 0
        
        return {
            "total_drones": len(self.drones),
            "active_drones": len(self.get_all_active_drones()),
            "center_position": (center_x, center_y),
            "average_neighbors": avg_neighbors,
            "network_connectivity": connectivity,
            "topology_changes": self.topology_changes,
            "position_updates": self.position_updates,
            "spatial_grid_cells": len(self.spatial_grid)
        }


if __name__ == "__main__":
    # Test the spatial manager
    print("Testing Spatial Manager...")
    print("=" * 60)

    # Create the configuration
    config = SpatialConfiguration(
        area_bounds=((-500, -500), (500, 500)),
        default_comm_radius=150.0,
        enable_mobility=True
    )
    
    # Create the manager
    manager = SpatialManager(config)

    # Register a few drones
    drone_configs = [
        ("Drone1", (0, 0), MovementPattern.STATIONARY),
        ("Drone2", (100, 0), MovementPattern.RANDOM_WALK),
        ("Drone3", (0, 100), MovementPattern.CIRCULAR),
        ("Drone4", (50, 50), MovementPattern.LINEAR),
        ("Drone5", (-100, -100), MovementPattern.RANDOM_WALK)
    ]
    
    print("Registering drones:")
    for drone_id, pos, pattern in drone_configs:
        success = manager.register_drone(drone_id, pos, movement_pattern=pattern)
        print(f"  {drone_id}: {'Success' if success else 'Failed'}")
        
    print()
    
    # Initial topology
    manager.update_topology()
    print("Initial Network Topology:")
    topology = manager.get_network_topology()
    for drone_id, neighbors in topology.items():
        print(f"  {drone_id}: {neighbors}")
        
    print()
    
    # Test neighbor discovery
    print("Neighbor Discovery Test:")
    test_drone = "Drone1"
    neighbors = manager.get_all_neighbors(test_drone)
    print(f"  {test_drone} neighbors: {neighbors}")
    
    for neighbor_id in neighbors:
        distance = manager.calculate_distance(test_drone, neighbor_id)
        print(f"    Distance to {neighbor_id}: {distance:.1f}m")
        
    print()
    
    # Simulate movement
    print("Simulating movement for 10 seconds...")
    for t in range(10):
        manager.simulate_movement(1.0)  # 1-second time step

        if t % 3 == 0:  # update the topology every 3 seconds
            changes = manager.update_topology()
            if changes > 0:
                print(f"  Time {t}s: {changes} topology changes detected")
                
    print()
    
    # Final statistics
    stats = manager.get_spatial_statistics()
    print("Final Statistics:")
    print("-" * 40)
    for key, value in stats.items():
        if isinstance(value, float):
            print(f"  {key}: {value:.2f}")
        elif isinstance(value, tuple):
            print(f"  {key}: ({value[0]:.1f}, {value[1]:.1f})")
        else:
            print(f"  {key}: {value}")
            
    print()
    print("Spatial manager ready for neighbor discovery integration!")