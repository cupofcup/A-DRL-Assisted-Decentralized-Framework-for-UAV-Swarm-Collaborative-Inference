"""
Base configuration classes and validator.

Provides the base structure and validation functionality for configurations.
"""

import json
import yaml
from typing import Dict, Any, Optional, Type, List, Union
from dataclasses import dataclass, field, asdict
from abc import ABC, abstractmethod
import os
from pathlib import Path


class ConfigValidator:
    """Configuration validator."""

    @staticmethod
    def validate_positive_number(value: Union[int, float], name: str) -> Union[int, float]:
        """Validate a positive number."""
        if value <= 0:
            raise ValueError(f"{name} must be positive, got {value}")
        return value
        
    @staticmethod
    def validate_range(value: Union[int, float], min_val: float, max_val: float, name: str) -> Union[int, float]:
        """Validate that a value is within a numeric range."""
        if not (min_val <= value <= max_val):
            raise ValueError(f"{name} must be in range [{min_val}, {max_val}], got {value}")
        return value
        
    @staticmethod
    def validate_probability(value: float, name: str) -> float:
        """Validate a probability value."""
        return ConfigValidator.validate_range(value, 0.0, 1.0, name)
        
    @staticmethod
    def validate_list_length(lst: List, min_length: int, max_length: Optional[int], name: str) -> List:
        """Validate the length of a list."""
        if len(lst) < min_length:
            raise ValueError(f"{name} must have at least {min_length} elements, got {len(lst)}")
        if max_length is not None and len(lst) > max_length:
            raise ValueError(f"{name} must have at most {max_length} elements, got {len(lst)}")
        return lst
        
    @staticmethod
    def validate_file_exists(path: str, name: str) -> str:
        """Validate that a file exists."""
        if not os.path.exists(path):
            raise FileNotFoundError(f"{name} file not found: {path}")
        return path


@dataclass
class BaseConfig(ABC):
    """Base configuration class."""

    def validate(self) -> None:
        """Validate configuration parameters. Subclasses should override this method."""
        pass

    def to_dict(self) -> Dict[str, Any]:
        """Convert to a dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BaseConfig':
        """Create a configuration from a dictionary."""
        return cls(**data)

    def save_to_file(self, filepath: str) -> None:
        """Save to a file."""
        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        data = self.to_dict()
        
        if filepath.suffix.lower() == '.json':
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        elif filepath.suffix.lower() in ['.yml', '.yaml']:
            with open(filepath, 'w', encoding='utf-8') as f:
                yaml.safe_dump(data, f, default_flow_style=False, allow_unicode=True)
        else:
            raise ValueError(f"Unsupported file format: {filepath.suffix}")
            
    @classmethod
    def load_from_file(cls, filepath: str) -> 'BaseConfig':
        """Load a configuration from a file."""
        filepath = Path(filepath)
        
        if not filepath.exists():
            raise FileNotFoundError(f"Config file not found: {filepath}")
            
        if filepath.suffix.lower() == '.json':
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
        elif filepath.suffix.lower() in ['.yml', '.yaml']:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
        else:
            raise ValueError(f"Unsupported file format: {filepath.suffix}")
            
        config = cls.from_dict(data)
        config.validate()
        return config
        
    def update_from_dict(self, updates: Dict[str, Any]) -> None:
        """Update the configuration from a dictionary."""
        for key, value in updates.items():
            if hasattr(self, key):
                setattr(self, key, value)
            else:
                raise ValueError(f"Unknown config parameter: {key}")
        self.validate()
        
    def merge_with(self, other: 'BaseConfig') -> 'BaseConfig':
        """Merge with another configuration."""
        if not isinstance(other, self.__class__):
            raise TypeError(f"Cannot merge {type(self)} with {type(other)}")
            
        self_dict = self.to_dict()
        other_dict = other.to_dict()
        
        # Recursively merge the dictionaries
        merged = self._merge_dicts(self_dict, other_dict)
        
        result = self.__class__.from_dict(merged)
        result.validate()
        return result
        
    def _merge_dicts(self, dict1: Dict[str, Any], dict2: Dict[str, Any]) -> Dict[str, Any]:
        """Recursively merge two dictionaries."""
        result = dict1.copy()
        
        for key, value in dict2.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_dicts(result[key], value)
            else:
                result[key] = value
                
        return result
        
    def get_summary(self) -> str:
        """Get a summary of the configuration."""
        lines = []
        lines.append(f"{self.__class__.__name__} Configuration:")
        lines.append("-" * 40)
        
        data = self.to_dict()
        for key, value in data.items():
            if isinstance(value, dict):
                lines.append(f"{key}:")
                for sub_key, sub_value in value.items():
                    lines.append(f"  {sub_key}: {sub_value}")
            elif isinstance(value, list):
                lines.append(f"{key}: [{len(value)} items]")
            else:
                lines.append(f"{key}: {value}")
                
        return "\n".join(lines)


if __name__ == "__main__":
    # Test the base configuration classes
    print("Testing base configuration classes...")

    # Test the validator
    validator = ConfigValidator()

    # Positive number validation
    try:
        validator.validate_positive_number(5.0, "test_param")
        print("✓ Positive number validation passed")
    except ValueError as e:
        print(f"✗ Positive number validation failed: {e}")

    # Probability validation
    try:
        validator.validate_probability(0.5, "prob")
        print("✓ Probability validation passed")
    except ValueError as e:
        print(f"✗ Probability validation failed: {e}")

    # Range validation
    try:
        validator.validate_range(10, 5, 15, "range_param")
        print("✓ Range validation passed")
    except ValueError as e:
        print(f"✗ Range validation failed: {e}")

    print("\nBase configuration class tests complete!")