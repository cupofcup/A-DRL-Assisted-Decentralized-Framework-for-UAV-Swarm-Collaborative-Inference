"""
Collaboration configuration module.

Provides collaboration parameter configuration based on the collaboration
decision mechanism in CLAUDE.md.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from .base_config import BaseConfig, ConfigValidator


@dataclass
class CollaborationConfig(BaseConfig):
    """Collaboration configuration class."""

    # Basic collaboration parameters
    enable_collaboration: bool = True  # Enable collaboration
    collaboration_probability: float = 0.3  # Collaboration probability
    max_collaboration_distance: float = 200.0  # Maximum collaboration distance (meters)

    # Top-K candidate selection (based on the CLAUDE.md design)
    candidate_selection_k: int = 3  # Number of candidates K
    candidate_selection_method: str = "utility_based"  # Candidate selection method

    # Utility function weights (based on the CLAUDE.md formula)
    utility_weights: Dict[str, float] = field(default_factory=lambda: {
        "load": 0.4,        # w_1: load weight
        "distance": 0.3,    # w_2: distance weight
        "capacity": 0.2,    # w_3: capacity weight
        "reliability": 0.1  # reliability weight
    })

    # Collaboration decision parameters
    collaboration_threshold: float = 0.7  # Collaboration threshold
    collaboration_timeout: float = 5.0  # Collaboration timeout (seconds)
    max_retries: int = 2  # Maximum number of retries

    # Model partition parameters (based on the ResNet8-layer design)
    model_layers: int = 8  # Total number of layers
    min_layers_local: int = 1  # Minimum number of layers processed locally
    max_layers_local: int = 7  # Maximum number of layers processed locally
    preferred_split_points: List[int] = field(default_factory=lambda: [2, 4, 6])  # Preferred partition points

    # Communication optimization parameters
    enable_compression: bool = True  # Enable data compression
    compression_ratio: float = 0.7  # Compression ratio
    max_communication_delay: float = 2.0  # Maximum communication delay (seconds)

    # Load balancing parameters
    enable_load_balancing: bool = True  # Enable load balancing
    load_balancing_strategy: str = "weighted_random"  # Load balancing strategy
    rebalance_frequency: float = 2.0  # Rebalance frequency (seconds)

    # Collaboration quality control
    enable_quality_control: bool = True  # Enable quality control
    min_success_rate: float = 0.8  # Minimum success rate
    quality_update_interval: float = 5.0  # Quality evaluation update interval

    # Fault handling parameters
    enable_fault_tolerance: bool = True  # Enable fault tolerance
    failure_detection_timeout: float = 3.0  # Failure detection timeout
    backup_selection_method: str = "next_best"  # Backup selection method

    def validate(self) -> None:
        """Validate the collaboration configuration."""
        # Basic parameter validation
        ConfigValidator.validate_probability(self.collaboration_probability, "collaboration_probability")
        ConfigValidator.validate_positive_number(self.max_collaboration_distance, "max_collaboration_distance")

        # Candidate selection validation
        ConfigValidator.validate_positive_number(self.candidate_selection_k, "candidate_selection_k")
        if self.candidate_selection_k > 10:  # Reasonable upper limit
            raise ValueError("candidate_selection_k should not exceed 10 for performance")

        valid_selection_methods = ["utility_based", "distance_based", "random", "round_robin"]
        if self.candidate_selection_method not in valid_selection_methods:
            raise ValueError(f"candidate_selection_method must be one of {valid_selection_methods}")

        # Utility function weight validation
        weight_sum = sum(self.utility_weights.values())
        if abs(weight_sum - 1.0) > 0.01:  # Allow a small tolerance
            raise ValueError(f"utility_weights must sum to 1.0, got {weight_sum}")

        for weight_name, weight_value in self.utility_weights.items():
            ConfigValidator.validate_range(weight_value, 0.0, 1.0, f"utility_weights[{weight_name}]")

        # Collaboration decision validation
        ConfigValidator.validate_range(self.collaboration_threshold, 0.0, 1.0, "collaboration_threshold")
        ConfigValidator.validate_positive_number(self.collaboration_timeout, "collaboration_timeout")
        ConfigValidator.validate_positive_number(self.max_retries, "max_retries")

        # Model partition validation
        ConfigValidator.validate_positive_number(self.model_layers, "model_layers")
        ConfigValidator.validate_positive_number(self.min_layers_local, "min_layers_local")
        ConfigValidator.validate_positive_number(self.max_layers_local, "max_layers_local")

        if self.min_layers_local >= self.max_layers_local:
            raise ValueError("min_layers_local must be less than max_layers_local")
        if self.max_layers_local >= self.model_layers:
            raise ValueError("max_layers_local must be less than model_layers")

        # Validate preferred partition points
        for point in self.preferred_split_points:
            if not (self.min_layers_local <= point <= self.max_layers_local):
                raise ValueError(f"preferred_split_point {point} not in valid range")

        # Communication optimization validation
        if self.enable_compression:
            ConfigValidator.validate_range(self.compression_ratio, 0.1, 1.0, "compression_ratio")
        ConfigValidator.validate_positive_number(self.max_communication_delay, "max_communication_delay")

        # Load balancing validation
        if self.enable_load_balancing:
            valid_strategies = ["round_robin", "weighted_random", "least_loaded", "proportional"]
            if self.load_balancing_strategy not in valid_strategies:
                raise ValueError(f"load_balancing_strategy must be one of {valid_strategies}")
            ConfigValidator.validate_positive_number(self.rebalance_frequency, "rebalance_frequency")

        # Quality control validation
        if self.enable_quality_control:
            ConfigValidator.validate_range(self.min_success_rate, 0.0, 1.0, "min_success_rate")
            ConfigValidator.validate_positive_number(self.quality_update_interval, "quality_update_interval")

        # Fault handling validation
        if self.enable_fault_tolerance:
            ConfigValidator.validate_positive_number(self.failure_detection_timeout, "failure_detection_timeout")
            valid_backup_methods = ["next_best", "random", "least_loaded", "highest_reliability"]
            if self.backup_selection_method not in valid_backup_methods:
                raise ValueError(f"backup_selection_method must be one of {valid_backup_methods}")


@dataclass
class CommunicationConfig(BaseConfig):
    """Communication configuration class."""

    # Basic communication parameters
    base_communication_range: float = 200.0  # Base communication range (meters)
    communication_protocol: str = "wireless"  # Communication protocol

    # Bandwidth and latency model (based on the CLAUDE.md communication cost formula)
    base_bandwidth: float = 100.0  # Base bandwidth (Mbps)
    base_latency: float = 0.001  # Base latency (seconds)
    distance_factor: float = 1e-6  # Distance factor (seconds/meter)
    network_factor: float = 1.0  # Network factor

    # Data transmission parameters
    max_packet_size: float = 1.0  # Maximum packet size (MB)
    transmission_reliability: float = 0.95  # Transmission reliability
    acknowledgment_timeout: float = 1.0  # Acknowledgment timeout (seconds)

    # Congestion control
    enable_congestion_control: bool = True  # Enable congestion control
    congestion_window_size: int = 10  # Congestion window size
    congestion_threshold: float = 0.8  # Congestion threshold

    # Multi-hop communication
    enable_multi_hop: bool = True  # Enable multi-hop communication
    max_hops: int = 3  # Maximum number of hops
    hop_penalty_factor: float = 0.1  # Hop penalty factor

    # QoS parameters
    enable_qos: bool = True  # Enable quality-of-service control
    priority_queues: Dict[str, float] = field(default_factory=lambda: {
        "high": 1.0,     # High-priority queue weight
        "medium": 0.6,   # Medium-priority queue weight
        "low": 0.3,      # Low-priority queue weight
        "background": 0.1  # Background queue weight
    })

    def validate(self) -> None:
        """Validate the communication configuration."""
        # Basic parameter validation
        ConfigValidator.validate_positive_number(self.base_communication_range, "base_communication_range")
        ConfigValidator.validate_positive_number(self.base_bandwidth, "base_bandwidth")
        ConfigValidator.validate_positive_number(self.base_latency, "base_latency")
        ConfigValidator.validate_positive_number(self.distance_factor, "distance_factor")
        ConfigValidator.validate_positive_number(self.network_factor, "network_factor")

        valid_protocols = ["wireless", "cellular", "satellite", "mesh"]
        if self.communication_protocol not in valid_protocols:
            raise ValueError(f"communication_protocol must be one of {valid_protocols}")

        # Data transmission validation
        ConfigValidator.validate_positive_number(self.max_packet_size, "max_packet_size")
        ConfigValidator.validate_probability(self.transmission_reliability, "transmission_reliability")
        ConfigValidator.validate_positive_number(self.acknowledgment_timeout, "acknowledgment_timeout")

        # Congestion control validation
        if self.enable_congestion_control:
            ConfigValidator.validate_positive_number(self.congestion_window_size, "congestion_window_size")
            ConfigValidator.validate_range(self.congestion_threshold, 0.0, 1.0, "congestion_threshold")

        # Multi-hop communication validation
        if self.enable_multi_hop:
            ConfigValidator.validate_positive_number(self.max_hops, "max_hops")
            if self.max_hops > 5:  # Reasonable upper limit
                raise ValueError("max_hops should not exceed 5 for practical reasons")
            ConfigValidator.validate_positive_number(self.hop_penalty_factor, "hop_penalty_factor")

        # QoS validation
        if self.enable_qos:
            for queue_name, weight in self.priority_queues.items():
                ConfigValidator.validate_positive_number(weight, f"priority_queues[{queue_name}]")

    def calculate_communication_time(self, data_size: float, distance: float) -> float:
        """
        Calculate the communication time.
        Based on the CLAUDE.md formula: comm_time = data_size * distance * network_factor
        """
        if data_size <= 0 or distance <= 0:
            return 0.0

        # Base latency
        base_time = self.base_latency

        # Transmission time (accounting for bandwidth)
        transmission_time = data_size * 8 / self.base_bandwidth  # Convert to seconds

        # Distance-related delay
        distance_delay = distance * self.distance_factor * self.network_factor

        return base_time + transmission_time + distance_delay

    def get_effective_bandwidth(self, distance: float, hop_count: int = 1) -> float:
        """Get the effective bandwidth."""
        # Distance attenuation
        distance_factor = max(0.1, 1.0 - distance / (self.base_communication_range * 2))

        # Multi-hop penalty
        hop_factor = 1.0
        if self.enable_multi_hop and hop_count > 1:
            hop_factor = max(0.1, 1.0 - (hop_count - 1) * self.hop_penalty_factor)

        return self.base_bandwidth * distance_factor * hop_factor


def create_collaboration_scenarios() -> Dict[str, CollaborationConfig]:
    """Create collaboration scenario configurations."""
    configs = {}

    # Standard collaboration configuration
    configs["standard"] = CollaborationConfig(
        enable_collaboration=True,
        collaboration_probability=0.3,
        candidate_selection_k=3,
        utility_weights={"load": 0.4, "distance": 0.3, "capacity": 0.2, "reliability": 0.1}
    )
    
    # High collaboration frequency configuration
    configs["high_collaboration"] = CollaborationConfig(
        enable_collaboration=True,
        collaboration_probability=0.6,
        candidate_selection_k=5,
        max_collaboration_distance=250.0,
        utility_weights={"load": 0.5, "distance": 0.2, "capacity": 0.2, "reliability": 0.1},
        enable_load_balancing=True,
        rebalance_frequency=1.0
    )
    
    # Conservative collaboration configuration (prioritizes local processing)
    configs["conservative"] = CollaborationConfig(
        enable_collaboration=True,
        collaboration_probability=0.1,
        collaboration_threshold=0.8,  # Higher collaboration threshold
        candidate_selection_k=2,
        max_collaboration_distance=150.0,
        utility_weights={"load": 0.6, "distance": 0.4, "capacity": 0.0, "reliability": 0.0}
    )

    # Fault-tolerance-first configuration
    configs["fault_tolerant"] = CollaborationConfig(
        enable_collaboration=True,
        collaboration_probability=0.4,
        candidate_selection_k=4,  # More candidates
        enable_fault_tolerance=True,
        failure_detection_timeout=2.0,
        max_retries=3,
        enable_quality_control=True,
        min_success_rate=0.9,
        utility_weights={"load": 0.3, "distance": 0.2, "capacity": 0.2, "reliability": 0.3}
    )

    # Low-latency configuration
    configs["low_latency"] = CollaborationConfig(
        enable_collaboration=True,
        collaboration_probability=0.5,
        collaboration_timeout=2.0,  # Shorter timeout
        max_communication_delay=1.0,
        candidate_selection_k=3,
        utility_weights={"load": 0.2, "distance": 0.5, "capacity": 0.2, "reliability": 0.1},  # Distance-first
        enable_compression=True,
        compression_ratio=0.5  # Higher compression ratio
    )

    return configs


def create_communication_scenarios() -> Dict[str, CommunicationConfig]:
    """Create communication scenario configurations."""
    configs = {}

    # Standard communication configuration
    configs["standard"] = CommunicationConfig(
        base_communication_range=200.0,
        base_bandwidth=100.0,
        base_latency=0.001,
        transmission_reliability=0.95
    )

    # High-performance communication configuration
    configs["high_performance"] = CommunicationConfig(
        base_communication_range=300.0,
        base_bandwidth=1000.0,  # 1Gbps
        base_latency=0.0005,
        transmission_reliability=0.99,
        enable_congestion_control=True,
        congestion_window_size=20
    )

    # Constrained-environment configuration
    configs["constrained"] = CommunicationConfig(
        base_communication_range=150.0,
        base_bandwidth=50.0,  # 50Mbps
        base_latency=0.005,
        transmission_reliability=0.90,
        max_packet_size=0.5,  # Small packets
        enable_multi_hop=True,
        max_hops=2
    )

    # Unreliable-network configuration
    configs["unreliable"] = CommunicationConfig(
        base_communication_range=200.0,
        base_bandwidth=80.0,
        base_latency=0.002,
        transmission_reliability=0.85,  # Low reliability
        acknowledgment_timeout=2.0,
        enable_fault_tolerance=True,
        distance_factor=2e-6,  # Greater distance impact
        network_factor=1.5
    )

    return configs


if __name__ == "__main__":
    # Test the collaboration configuration
    print("Testing collaboration configuration...")

    # Basic collaboration configuration test
    collab_config = CollaborationConfig()
    collab_config.validate()
    print("✓ Collaboration configuration validation passed")

    # Communication configuration test
    comm_config = CommunicationConfig()
    comm_config.validate()
    print("✓ Communication configuration validation passed")

    # Communication time computation test
    comm_time = comm_config.calculate_communication_time(10.0, 100.0)
    print(f"✓ Communication time computation: {comm_time:.6f} seconds")

    # Effective bandwidth test
    eff_bandwidth = comm_config.get_effective_bandwidth(150.0, 2)
    print(f"✓ Effective bandwidth: {eff_bandwidth:.1f} Mbps")

    # Collaboration scenario configuration test
    collab_scenarios = create_collaboration_scenarios()
    for name, config in collab_scenarios.items():
        config.validate()
        print(f"✓ Collaboration scenario {name} validation passed")

    # Communication scenario configuration test
    comm_scenarios = create_communication_scenarios()
    for name, config in comm_scenarios.items():
        config.validate()
        print(f"✓ Communication scenario {name} validation passed")

    print("\nCollaboration configuration module tests complete!")