"""
Configuration manager.

Provides unified configuration management, loading, saving, and validation.
"""

import os
import json
import yaml
from pathlib import Path
from typing import Dict, Any, Optional, Type, Union, List
from dataclasses import dataclass, field

from .base_config import BaseConfig
from .simulation_config import SimulationConfig, EnvironmentConfig, ScenarioConfig
from .drone_config import DroneConfig, DroneSwarmConfig
from .task_config import TaskConfig, TaskGenerationConfig
from .collaboration_config import CollaborationConfig, CommunicationConfig
from .drl_config import DRLConfig, TrainingConfig, EvaluationConfig


@dataclass
class SystemConfig(BaseConfig):
    """Overall system configuration class: integrates all sub-configurations."""

    # Basic configuration information
    config_name: str = "default"
    config_version: str = "1.0"
    description: str = "Default system configuration"

    # Subsystem configurations
    simulation: SimulationConfig = field(default_factory=SimulationConfig)
    environment: EnvironmentConfig = field(default_factory=EnvironmentConfig)
    scenario: ScenarioConfig = field(default_factory=ScenarioConfig)

    drone_swarm: DroneSwarmConfig = field(default_factory=DroneSwarmConfig)

    task_generation: TaskGenerationConfig = field(default_factory=TaskGenerationConfig)

    collaboration: CollaborationConfig = field(default_factory=CollaborationConfig)
    communication: CommunicationConfig = field(default_factory=CommunicationConfig)

    drl: DRLConfig = field(default_factory=DRLConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    evaluation: EvaluationConfig = field(default_factory=EvaluationConfig)

    def validate(self) -> None:
        """Validate the overall system configuration."""
        # Validate each sub-configuration
        self.simulation.validate()
        self.environment.validate()
        self.scenario.validate()
        self.drone_swarm.validate()
        self.task_generation.validate()
        self.collaboration.validate()
        self.communication.validate()
        self.drl.validate()
        self.training.validate()
        self.evaluation.validate()

        # Cross-configuration consistency check
        self._validate_cross_config_consistency()

    def _validate_cross_config_consistency(self) -> None:
        """Validate cross-configuration consistency."""

        # Simulation time consistency
        if abs(self.simulation.duration - self.task_generation.generation_duration) > 0.1:
            raise ValueError("Simulation duration and task generation duration should match")

        # Drone count consistency
        expected_drones = self.drone_swarm.num_drones
        if len(self.drone_swarm.individual_configs) > 0:
            if len(self.drone_swarm.individual_configs) != expected_drones:
                raise ValueError("Individual drone configs count does not match num_drones")

        # Communication range consistency
        sim_comm_range = self.environment.base_communication_range
        collab_comm_range = self.collaboration.max_collaboration_distance
        drone_comm_range = self.drone_swarm.drone_template.communication_radius

        if collab_comm_range > sim_comm_range:
            raise ValueError("Collaboration distance cannot exceed communication range")
        if drone_comm_range > sim_comm_range:
            raise ValueError("Drone communication radius cannot exceed environment range")

        # DRL state space consistency
        expected_k = self.collaboration.candidate_selection_k
        if self.drl.neighbor_candidates_k != expected_k:
            raise ValueError(f"DRL neighbor_candidates_k ({self.drl.neighbor_candidates_k}) "
                           f"should match collaboration candidate_selection_k ({expected_k})")

        # Collaboration parameter consistency
        if not self.drone_swarm.enable_collaboration and self.collaboration.enable_collaboration:
            raise ValueError("Collaboration enabled in config but disabled in swarm config")


class ConfigManager:
    """Configuration manager: provides configuration loading, saving, validation, and management."""

    def __init__(self, config_dir: str = "./configs"):
        self.config_dir = Path(config_dir)
        self.config_dir.mkdir(parents=True, exist_ok=True)

        # Configuration type mapping
        self.config_types: Dict[str, Type[BaseConfig]] = {
            "simulation": SimulationConfig,
            "environment": EnvironmentConfig,
            "scenario": ScenarioConfig,
            "drone": DroneConfig,
            "drone_swarm": DroneSwarmConfig,
            "task": TaskConfig,
            "task_generation": TaskGenerationConfig,
            "collaboration": CollaborationConfig,
            "communication": CommunicationConfig,
            "drl": DRLConfig,
            "training": TrainingConfig,
            "evaluation": EvaluationConfig,
            "system": SystemConfig
        }

        # Cache of already-loaded configurations
        self.loaded_configs: Dict[str, BaseConfig] = {}

    def load_config(self, config_type: str, config_name: str = "default") -> BaseConfig:
        """
        Load the configuration of the given type and name.

        Args:
            config_type: Configuration type
            config_name: Configuration name

        Returns:
            The loaded configuration object
        """
        cache_key = f"{config_type}_{config_name}"

        # Check the cache
        if cache_key in self.loaded_configs:
            return self.loaded_configs[cache_key]

        if config_type not in self.config_types:
            raise ValueError(f"Unknown config type: {config_type}")

        config_class = self.config_types[config_type]

        # Build the file path
        config_file = self.config_dir / config_type / f"{config_name}.yaml"

        if not config_file.exists():
            # If the file does not exist, return the default configuration
            print(f"Config file not found: {config_file}, using default configuration")
            config = config_class()
        else:
            config = config_class.load_from_file(str(config_file))

        # Validate the configuration
        config.validate()

        # Cache the configuration
        self.loaded_configs[cache_key] = config

        return config

    def save_config(self, config: BaseConfig, config_type: str, config_name: str = "default") -> str:
        """
        Save a configuration to a file.

        Args:
            config: Configuration object
            config_type: Configuration type
            config_name: Configuration name

        Returns:
            The path of the saved file
        """
        if config_type not in self.config_types:
            raise ValueError(f"Unknown config type: {config_type}")

        # Validate the configuration
        config.validate()

        # Create the directory
        config_dir = self.config_dir / config_type
        config_dir.mkdir(parents=True, exist_ok=True)

        # Save the file
        config_file = config_dir / f"{config_name}.yaml"
        config.save_to_file(str(config_file))

        # Update the cache
        cache_key = f"{config_type}_{config_name}"
        self.loaded_configs[cache_key] = config

        return str(config_file)

    def load_system_config(self, config_name: str = "default") -> SystemConfig:
        """Load the complete system configuration."""
        return self.load_config("system", config_name)

    def create_system_config_from_components(self, **kwargs) -> SystemConfig:
        """Create a system configuration from individual component configurations."""

        config = SystemConfig()

        # Load each sub-configuration
        if "simulation_config" in kwargs:
            config.simulation = kwargs["simulation_config"]
        if "environment_config" in kwargs:
            config.environment = kwargs["environment_config"]
        if "scenario_config" in kwargs:
            config.scenario = kwargs["scenario_config"]
        if "drone_swarm_config" in kwargs:
            config.drone_swarm = kwargs["drone_swarm_config"]
        if "task_generation_config" in kwargs:
            config.task_generation = kwargs["task_generation_config"]
        if "collaboration_config" in kwargs:
            config.collaboration = kwargs["collaboration_config"]
        if "communication_config" in kwargs:
            config.communication = kwargs["communication_config"]
        if "drl_config" in kwargs:
            config.drl = kwargs["drl_config"]
        if "training_config" in kwargs:
            config.training = kwargs["training_config"]
        if "evaluation_config" in kwargs:
            config.evaluation = kwargs["evaluation_config"]

        # Set basic information
        if "config_name" in kwargs:
            config.config_name = kwargs["config_name"]
        if "description" in kwargs:
            config.description = kwargs["description"]

        # Validate the configuration
        config.validate()

        return config

    def list_configs(self, config_type: str) -> List[str]:
        """List all available configurations of the given type."""
        if config_type not in self.config_types:
            raise ValueError(f"Unknown config type: {config_type}")

        config_dir = self.config_dir / config_type
        if not config_dir.exists():
            return []

        config_files = []
        for file_path in config_dir.glob("*.yaml"):
            config_files.append(file_path.stem)

        return sorted(config_files)

    def delete_config(self, config_type: str, config_name: str) -> bool:
        """Delete the specified configuration."""
        if config_type not in self.config_types:
            raise ValueError(f"Unknown config type: {config_type}")

        config_file = self.config_dir / config_type / f"{config_name}.yaml"

        if config_file.exists():
            config_file.unlink()

            # Clear the cache
            cache_key = f"{config_type}_{config_name}"
            if cache_key in self.loaded_configs:
                del self.loaded_configs[cache_key]

            return True
        return False

    def backup_configs(self, backup_dir: str) -> str:
        """Back up all configuration files."""
        import shutil
        import datetime
        
        backup_path = Path(backup_dir) / f"config_backup_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
        backup_path.mkdir(parents=True, exist_ok=True)
        
        shutil.copytree(self.config_dir, backup_path / "configs")
        
        return str(backup_path)

    def validate_all_configs(self) -> Dict[str, List[str]]:
        """Validate all saved configuration files."""
        validation_results = {}

        for config_type in self.config_types:
            config_names = self.list_configs(config_type)
            validation_results[config_type] = []

            for config_name in config_names:
                try:
                    config = self.load_config(config_type, config_name)
                    # If loading succeeds, validation passed
                    validation_results[config_type].append(f"✓ {config_name}")
                except Exception as e:
                    validation_results[config_type].append(f"✗ {config_name}: {e}")

        return validation_results

    def clear_cache(self):
        """Clear the configuration cache."""
        self.loaded_configs.clear()


# Convenience functions
def load_config(config_type: str, config_name: str = "default", config_dir: str = "./configs") -> BaseConfig:
    """Convenience function for loading a configuration."""
    manager = ConfigManager(config_dir)
    return manager.load_config(config_type, config_name)


def save_config(config: BaseConfig, config_type: str, config_name: str = "default",
               config_dir: str = "./configs") -> str:
    """Convenience function for saving a configuration."""
    manager = ConfigManager(config_dir)
    return manager.save_config(config, config_type, config_name)


def create_default_configs(config_dir: str = "./configs") -> Dict[str, str]:
    """Create default configuration files."""
    manager = ConfigManager(config_dir)

    # Create the various default configurations
    saved_files = {}

    # Simulation configuration
    saved_files["simulation"] = manager.save_config(SimulationConfig(), "simulation", "default")

    # Environment configuration
    saved_files["environment"] = manager.save_config(EnvironmentConfig(), "environment", "default")

    # Drone swarm configuration
    drone_swarm = DroneSwarmConfig()
    drone_swarm.generate_individual_configs()
    saved_files["drone_swarm"] = manager.save_config(drone_swarm, "drone_swarm", "default")

    # Task generation configuration
    saved_files["task_generation"] = manager.save_config(TaskGenerationConfig(), "task_generation", "default")

    # Collaboration configuration
    saved_files["collaboration"] = manager.save_config(CollaborationConfig(), "collaboration", "default")

    # Communication configuration
    saved_files["communication"] = manager.save_config(CommunicationConfig(), "communication", "default")

    # DRL configuration
    saved_files["drl"] = manager.save_config(DRLConfig(), "drl", "default")

    # Training configuration
    saved_files["training"] = manager.save_config(TrainingConfig(), "training", "default")

    # Evaluation configuration
    saved_files["evaluation"] = manager.save_config(EvaluationConfig(), "evaluation", "default")

    # Overall system configuration
    system_config = manager.create_system_config_from_components(
        simulation_config=SimulationConfig(),
        environment_config=EnvironmentConfig(),
        scenario_config=ScenarioConfig(),
        drone_swarm_config=drone_swarm,
        task_generation_config=TaskGenerationConfig(),
        collaboration_config=CollaborationConfig(),
        communication_config=CommunicationConfig(),
        drl_config=DRLConfig(),
        training_config=TrainingConfig(),
        evaluation_config=EvaluationConfig(),
        config_name="default_system",
        description="Default system configuration with all components"
    )
    
    saved_files["system"] = manager.save_config(system_config, "system", "default")
    
    return saved_files


if __name__ == "__main__":
    # Test the configuration manager
    print("Testing configuration manager...")

    # Create the configuration manager
    manager = ConfigManager("./test_configs")

    # Test saving and loading
    sim_config = SimulationConfig(duration=60.0, area_size=500.0)
    saved_path = manager.save_config(sim_config, "simulation", "test")
    print(f"✓ Configuration saved: {saved_path}")

    # Load the configuration
    loaded_config = manager.load_config("simulation", "test")
    print(f"✓ Configuration loaded: duration={loaded_config.duration}")

    # Test system configuration
    try:
        system_config = manager.create_system_config_from_components(
            simulation_config=SimulationConfig(),
            drone_swarm_config=DroneSwarmConfig()
        )
        print("✓ System configuration created successfully")
    except Exception as e:
        print(f"✗ System configuration creation failed: {e}")

    # Test the configuration list
    config_list = manager.list_configs("simulation")
    print(f"✓ Simulation configuration list: {config_list}")

    # Test default configuration creation
    print("\nCreating default configuration files...")
    default_files = create_default_configs("./test_configs")
    for config_type, file_path in default_files.items():
        print(f"✓ {config_type}: {file_path}")

    # Validate all configurations
    print("\nValidating all configurations...")
    validation_results = manager.validate_all_configs()
    for config_type, results in validation_results.items():
        if results:  # Only show types that have configurations
            print(f"{config_type}:")
            for result in results:
                print(f"  {result}")

    # Clean up test files
    import shutil
    shutil.rmtree("./test_configs", ignore_errors=True)

    print("\nConfiguration manager tests complete!")