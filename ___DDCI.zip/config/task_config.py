"""
Task configuration module.

Provides task generation and processing configuration based on the hierarchical
task model in CLAUDE.md.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Union
from .base_config import BaseConfig, ConfigValidator
from tasks import TaskPriority


@dataclass
class TaskConfig(BaseConfig):
    """Task configuration class."""

    # Basic task attributes
    task_type: str = "inference"  # Task type: "inference", "training", "data_processing"
    priority: TaskPriority = TaskPriority.MEDIUM  # Default priority

    # Computation requirements
    flops_requirement: float = 1000.0  # FLOPS requirement
    memory_requirement: float = 100.0  # Memory requirement (MB)
    data_size: float = 10.0  # Data size (MB)

    # Time constraints
    deadline: Optional[float] = None  # Deadline (seconds); None means no hard deadline
    max_processing_time: float = 10.0  # Maximum processing time (seconds)

    # Divisibility
    divisible: bool = True  # Whether the task is divisible
    min_partition_size: float = 100.0  # Minimum partition size (FLOPS)
    max_partitions: int = 8  # Maximum number of partitions

    # Collaboration requirements
    collaboration_required: bool = False  # Whether collaboration is required
    min_collaborators: int = 1  # Minimum number of collaborators
    max_collaborators: int = 2  # Maximum number of collaborators

    def validate(self) -> None:
        """Validate the task configuration."""
        # Computation requirement validation
        ConfigValidator.validate_positive_number(self.flops_requirement, "flops_requirement")
        ConfigValidator.validate_positive_number(self.memory_requirement, "memory_requirement")
        ConfigValidator.validate_positive_number(self.data_size, "data_size")

        # Time constraint validation
        if self.deadline is not None:
            ConfigValidator.validate_positive_number(self.deadline, "deadline")
        ConfigValidator.validate_positive_number(self.max_processing_time, "max_processing_time")

        # Divisibility validation
        if self.divisible:
            ConfigValidator.validate_positive_number(self.min_partition_size, "min_partition_size")
            ConfigValidator.validate_positive_number(self.max_partitions, "max_partitions")
            if self.min_partition_size * self.max_partitions > self.flops_requirement:
                raise ValueError("min_partition_size * max_partitions cannot exceed flops_requirement")

        # Collaboration validation
        if self.collaboration_required:
            ConfigValidator.validate_positive_number(self.min_collaborators, "min_collaborators")
            ConfigValidator.validate_positive_number(self.max_collaborators, "max_collaborators")
            if self.min_collaborators > self.max_collaborators:
                raise ValueError("min_collaborators cannot exceed max_collaborators")

        # Task type validation
        valid_types = ["inference", "training", "data_processing", "communication", "monitoring"]
        if self.task_type not in valid_types:
            raise ValueError(f"task_type must be one of {valid_types}")


@dataclass
class PriorityTaskConfig(BaseConfig):
    """Priority-specific task configuration."""

    priority: TaskPriority

    # Arrival process parameters (based on the CLAUDE.md formulas)
    arrival_rate: float = 1.0  # Base arrival rate lambda (tasks/second)
    arrival_process_type: str = "poisson"  # Arrival process type

    # Priority-specific parameters
    batch_size_range: Tuple[int, int] = (1, 1)  # Batch size range
    spatial_correlation: float = 0.0  # Spatial correlation (0-1)
    time_correlation: float = 0.0  # Temporal correlation (0-1)

    # Task feature distributions
    flops_distribution: str = "normal"  # FLOPS distribution type
    flops_params: Dict[str, float] = field(default_factory=lambda: {"mean": 1000.0, "std": 200.0})

    data_size_distribution: str = "exponential"  # Data size distribution
    data_size_params: Dict[str, float] = field(default_factory=lambda: {"scale": 10.0})

    # Deadline distribution
    deadline_distribution: str = "uniform"  # Deadline distribution
    deadline_params: Dict[str, float] = field(default_factory=lambda: {"low": 5.0, "high": 15.0})

    def validate(self) -> None:
        """Validate the priority task configuration."""
        # Arrival process validation
        ConfigValidator.validate_positive_number(self.arrival_rate, "arrival_rate")

        valid_processes = ["poisson", "compound_poisson", "batch_arrival", "periodic"]
        if self.arrival_process_type not in valid_processes:
            raise ValueError(f"arrival_process_type must be one of {valid_processes}")

        # Batch size validation
        min_batch, max_batch = self.batch_size_range
        if min_batch > max_batch or min_batch < 1:
            raise ValueError("Invalid batch_size_range")

        # Correlation validation
        ConfigValidator.validate_range(self.spatial_correlation, 0.0, 1.0, "spatial_correlation")
        ConfigValidator.validate_range(self.time_correlation, 0.0, 1.0, "time_correlation")

        # Distribution parameter validation
        valid_distributions = ["normal", "exponential", "uniform", "gamma", "lognormal"]
        if self.flops_distribution not in valid_distributions:
            raise ValueError(f"flops_distribution must be one of {valid_distributions}")
        if self.data_size_distribution not in valid_distributions:
            raise ValueError(f"data_size_distribution must be one of {valid_distributions}")
        if self.deadline_distribution not in valid_distributions:
            raise ValueError(f"deadline_distribution must be one of {valid_distributions}")


@dataclass
class TaskGenerationConfig(BaseConfig):
    """Task generation configuration class."""

    # Global generation parameters
    enable_task_generation: bool = True  # Enable task generation
    generation_duration: float = 30.0  # Generation duration (seconds)
    warm_up_time: float = 2.0  # Warm-up time (seconds)

    # Per-priority configuration
    high_priority_config: PriorityTaskConfig = field(default_factory=lambda: PriorityTaskConfig(
        priority=TaskPriority.HIGH,
        arrival_rate=0.1,  # lambda_3 = 0.1 (emergency events)
        arrival_process_type="poisson",
        flops_params={"mean": 500.0, "std": 100.0},  # High-priority tasks are relatively simple
        deadline_params={"low": 1.0, "high": 3.0}  # Strict deadlines
    ))

    medium_priority_config: PriorityTaskConfig = field(default_factory=lambda: PriorityTaskConfig(
        priority=TaskPriority.MEDIUM,
        arrival_rate=0.5,  # lambda_2 = 0.5 (medium inference tasks)
        arrival_process_type="compound_poisson",
        spatial_correlation=0.3,  # Has spatial correlation
        flops_params={"mean": 2000.0, "std": 500.0},
        deadline_params={"low": 5.0, "high": 15.0}
    ))

    low_priority_config: PriorityTaskConfig = field(default_factory=lambda: PriorityTaskConfig(
        priority=TaskPriority.LOW,
        arrival_rate=1.0,  # lambda_1 = 1.0 (regular tasks)
        arrival_process_type="poisson",
        flops_params={"mean": 1500.0, "std": 300.0},
        deadline_params={"low": 10.0, "high": 30.0}
    ))

    background_priority_config: PriorityTaskConfig = field(default_factory=lambda: PriorityTaskConfig(
        priority=TaskPriority.BACKGROUND,
        arrival_rate=0.2,  # lambda_0 = 0.2 (background tasks)
        arrival_process_type="batch_arrival",
        batch_size_range=(1, 5),  # Batch arrival
        flops_params={"mean": 800.0, "std": 200.0},
        deadline_params={"low": 30.0, "high": 60.0}  # Relaxed deadlines
    ))

    # Dynamic adjustment parameters
    enable_dynamic_rates: bool = False  # Enable dynamic arrival rates
    rate_variation_amplitude: float = 0.3  # Arrival rate variation amplitude
    rate_variation_period: float = 10.0  # Variation period (seconds)

    # Environment-related parameters (based on the CLAUDE.md danger function)
    danger_factors: Dict[str, float] = field(default_factory=lambda: {
        "weather": 0.0,  # Weather risk factor
        "obstacles": 0.1,  # Obstacle density
        "interference": 0.0,  # Interference level
        "network_quality": 0.0  # Network quality impact
    })

    # Spatial distribution parameters
    spatial_task_distribution: str = "uniform"  # Task spatial distribution
    hotspot_regions: List[Tuple[float, float, float]] = field(default_factory=list)  # Hotspot regions (x, y, intensity)

    def validate(self) -> None:
        """Validate the task generation configuration."""
        # Basic parameter validation
        ConfigValidator.validate_positive_number(self.generation_duration, "generation_duration")
        if self.warm_up_time < 0:
            raise ValueError("warm_up_time cannot be negative")
        if self.warm_up_time >= self.generation_duration:
            raise ValueError("warm_up_time must be less than generation_duration")

        # Priority configuration validation
        self.high_priority_config.validate()
        self.medium_priority_config.validate()
        self.low_priority_config.validate()
        self.background_priority_config.validate()

        # Dynamic adjustment validation
        if self.enable_dynamic_rates:
            ConfigValidator.validate_range(self.rate_variation_amplitude, 0.0, 1.0, "rate_variation_amplitude")
            ConfigValidator.validate_positive_number(self.rate_variation_period, "rate_variation_period")

        # Danger factor validation
        for factor, value in self.danger_factors.items():
            ConfigValidator.validate_range(value, 0.0, 1.0, f"danger_factors[{factor}]")

        # Spatial distribution validation
        valid_spatial_distributions = ["uniform", "normal", "hotspot", "clustered"]
        if self.spatial_task_distribution not in valid_spatial_distributions:
            raise ValueError(f"spatial_task_distribution must be one of {valid_spatial_distributions}")

        # Hotspot region validation
        for i, hotspot in enumerate(self.hotspot_regions):
            if len(hotspot) != 3:
                raise ValueError(f"hotspot_regions[{i}] must have 3 elements (x, y, intensity)")
            x, y, intensity = hotspot
            if intensity <= 0:
                raise ValueError(f"hotspot intensity must be positive, got {intensity}")
                
    def get_effective_arrival_rate(self, priority: TaskPriority, current_time: float = 0.0) -> float:
        """
        Get the effective arrival rate, accounting for environmental impact and dynamic adjustment.
        Based on the CLAUDE.md formula: lambda_3(t) = lambda_{3,base} * (1 + sum_j omega_j * h_j(t))
        """
        # Get the base configuration
        if priority == TaskPriority.HIGH:
            config = self.high_priority_config
        elif priority == TaskPriority.MEDIUM:
            config = self.medium_priority_config
        elif priority == TaskPriority.LOW:
            config = self.low_priority_config
        else:
            config = self.background_priority_config
            
        base_rate = config.arrival_rate

        # Environmental impact (primarily affects high-priority tasks)
        if priority == TaskPriority.HIGH:
            danger_multiplier = 1.0 + sum(self.danger_factors.values())
            base_rate *= danger_multiplier

        # Dynamic adjustment
        if self.enable_dynamic_rates:
            import math
            variation = self.rate_variation_amplitude * math.sin(
                2 * math.pi * current_time / self.rate_variation_period
            )
            base_rate *= (1.0 + variation)

        return max(0.01, base_rate)  # Ensure a minimum arrival rate


def create_scenario_task_configs() -> Dict[str, TaskGenerationConfig]:
    """Create task configurations for different scenarios."""
    configs = {}

    # Standard-load scenario
    configs["standard_load"] = TaskGenerationConfig(
        generation_duration=30.0,
        high_priority_config=PriorityTaskConfig(
            priority=TaskPriority.HIGH,
            arrival_rate=0.1,
            flops_params={"mean": 500.0, "std": 100.0}
        ),
        medium_priority_config=PriorityTaskConfig(
            priority=TaskPriority.MEDIUM,
            arrival_rate=0.5,
            flops_params={"mean": 2000.0, "std": 400.0}
        )
    )
    
    # High-load scenario
    configs["high_load"] = TaskGenerationConfig(
        generation_duration=30.0,
        high_priority_config=PriorityTaskConfig(
            priority=TaskPriority.HIGH,
            arrival_rate=0.3,  # More emergency tasks
            flops_params={"mean": 600.0, "std": 150.0}
        ),
        medium_priority_config=PriorityTaskConfig(
            priority=TaskPriority.MEDIUM,
            arrival_rate=1.2,  # More medium tasks
            flops_params={"mean": 2500.0, "std": 600.0}
        ),
        low_priority_config=PriorityTaskConfig(
            priority=TaskPriority.LOW,
            arrival_rate=2.0,  # More regular tasks
            flops_params={"mean": 1800.0, "std": 400.0}
        ),
        enable_dynamic_rates=True,
        rate_variation_amplitude=0.4
    )

    # Burst-event scenario
    configs["burst_events"] = TaskGenerationConfig(
        generation_duration=30.0,
        high_priority_config=PriorityTaskConfig(
            priority=TaskPriority.HIGH,
            arrival_rate=0.05,  # Low base frequency
            arrival_process_type="compound_poisson",
            batch_size_range=(1, 3),  # Batch arrival during bursts
            flops_params={"mean": 800.0, "std": 200.0}
        ),
        danger_factors={
            "weather": 0.3,
            "obstacles": 0.2,
            "interference": 0.1,
            "network_quality": 0.2
        },
        enable_dynamic_rates=True,
        rate_variation_amplitude=0.6,
        rate_variation_period=5.0  # Rapid variation
    )

    # Collaboration-intensive scenario
    configs["collaboration_intensive"] = TaskGenerationConfig(
        generation_duration=30.0,
        medium_priority_config=PriorityTaskConfig(
            priority=TaskPriority.MEDIUM,
            arrival_rate=0.8,
            flops_params={"mean": 3000.0, "std": 800.0},  # Large tasks require collaboration
            spatial_correlation=0.5  # High spatial correlation
        ),
        spatial_task_distribution="hotspot",
        hotspot_regions=[(100, 100, 2.0), (300, 300, 1.5)]  # Hotspot regions
    )

    return configs


if __name__ == "__main__":
    # Test the task configuration
    print("Testing task configuration...")

    # Basic task configuration test
    task_config = TaskConfig()
    task_config.validate()
    print("✓ Task configuration validation passed")

    # Priority task configuration test
    priority_config = PriorityTaskConfig(priority=TaskPriority.HIGH)
    priority_config.validate()
    print("✓ Priority task configuration validation passed")

    # Task generation configuration test
    gen_config = TaskGenerationConfig()
    gen_config.validate()
    print("✓ Task generation configuration validation passed")

    # Effective arrival rate computation test
    effective_rate = gen_config.get_effective_arrival_rate(TaskPriority.HIGH, 10.0)
    print(f"✓ High-priority effective arrival rate: {effective_rate:.3f}")

    # Scenario configuration test
    scenario_configs = create_scenario_task_configs()
    for name, config in scenario_configs.items():
        config.validate()
        print(f"✓ Scenario configuration {name} validation passed")

    print("\nTask configuration module tests complete!")