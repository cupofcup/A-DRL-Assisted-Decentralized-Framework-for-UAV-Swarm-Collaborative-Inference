"""
Drone configuration module.

Provides drone and swarm configuration based on the system parameters in CLAUDE.md.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from .base_config import BaseConfig, ConfigValidator


@dataclass
class DroneConfig(BaseConfig):
    """Single-drone configuration class."""

    # Basic attributes
    drone_id: str = "drone_0"  # Drone ID
    initial_position: Tuple[float, float] = (0.0, 0.0)  # Initial position (x, y)

    # Computation capacity parameters
    max_computation_capacity: float = 1000.0  # Maximum computation capacity (FLOPS/s)
    current_load: float = 0.0  # Current load (0-1)
    max_concurrent_tasks: int = 5  # Maximum number of concurrent tasks

    # Communication parameters
    communication_radius: float = 200.0  # Communication radius (meters)
    max_bandwidth: float = 100.0  # Maximum bandwidth (Mbps)
    transmission_power: float = 1.0  # Transmission power (W)
    antenna_gain: float = 2.0  # Antenna gain (dBi)

    # Mobility parameters
    mobility_enabled: bool = True  # Enable mobility
    max_speed: float = 10.0  # Maximum speed (m/s)
    acceleration: float = 2.0  # Acceleration (m/s^2)
    movement_pattern: str = "random_waypoint"  # Movement pattern

    # Energy parameters
    initial_battery: float = 100.0  # Initial battery level (%)
    energy_consumption_rate: float = 1.0  # Energy consumption rate (W)
    low_battery_threshold: float = 20.0  # Low battery threshold (%)

    # Failure and reliability parameters
    failure_probability: float = 0.0  # Failure probability (per second)
    repair_time: float = 10.0  # Repair time (seconds)
    availability: float = 1.0  # Availability (0-1)

    def validate(self) -> None:
        """Validate the drone configuration."""
        # Computation capacity validation
        ConfigValidator.validate_positive_number(self.max_computation_capacity, "max_computation_capacity")
        ConfigValidator.validate_range(self.current_load, 0.0, 1.0, "current_load")
        ConfigValidator.validate_positive_number(self.max_concurrent_tasks, "max_concurrent_tasks")

        # Communication parameter validation
        ConfigValidator.validate_positive_number(self.communication_radius, "communication_radius")
        ConfigValidator.validate_positive_number(self.max_bandwidth, "max_bandwidth")
        ConfigValidator.validate_positive_number(self.transmission_power, "transmission_power")

        # Mobility parameter validation
        if self.mobility_enabled:
            ConfigValidator.validate_positive_number(self.max_speed, "max_speed")
            ConfigValidator.validate_positive_number(self.acceleration, "acceleration")

            valid_patterns = ["random_waypoint", "circular", "linear", "stationary"]
            if self.movement_pattern not in valid_patterns:
                raise ValueError(f"movement_pattern must be one of {valid_patterns}")

        # Energy parameter validation
        ConfigValidator.validate_range(self.initial_battery, 0.0, 100.0, "initial_battery")
        ConfigValidator.validate_positive_number(self.energy_consumption_rate, "energy_consumption_rate")
        ConfigValidator.validate_range(self.low_battery_threshold, 0.0, 100.0, "low_battery_threshold")

        # Reliability parameter validation
        ConfigValidator.validate_range(self.failure_probability, 0.0, 1.0, "failure_probability")
        if self.failure_probability > 0:
            ConfigValidator.validate_positive_number(self.repair_time, "repair_time")
        ConfigValidator.validate_range(self.availability, 0.0, 1.0, "availability")


@dataclass
class DroneSwarmConfig(BaseConfig):
    """Drone swarm configuration class."""

    # Basic swarm parameters
    num_drones: int = 10  # Number of drones
    deployment_pattern: str = "grid"  # Deployment pattern: "grid", "random", "cluster", "line"

    # Spatial distribution parameters
    area_size: float = 400.0  # Deployment area size (meters)
    min_distance: float = 50.0  # Minimum distance between drones (meters)
    formation_type: str = "flexible"  # Formation type: "rigid", "flexible", "free"

    # Swarm collaboration parameters
    enable_collaboration: bool = True  # Enable collaboration
    max_collaboration_distance: float = 200.0  # Maximum collaboration distance (meters)
    collaboration_threshold: float = 0.7  # Collaboration threshold

    # Communication topology parameters
    topology_type: str = "dynamic"  # Topology type: "static", "dynamic", "mesh", "star"
    connectivity_maintenance: bool = True  # Maintain connectivity
    min_connectivity_ratio: float = 0.8  # Minimum connectivity ratio

    # Load balancing parameters
    enable_load_balancing: bool = True  # Enable load balancing
    load_balancing_algorithm: str = "weighted_random"  # Load balancing algorithm
    rebalance_interval: float = 2.0  # Rebalance interval (seconds)

    # Fault tolerance parameters
    fault_tolerance_level: str = "medium"  # Fault tolerance level: "low", "medium", "high"
    redundancy_factor: float = 1.2  # Redundancy factor
    recovery_strategy: str = "automatic"  # Recovery strategy: "manual", "automatic", "hybrid"

    # Per-drone configuration template
    drone_template: DroneConfig = field(default_factory=DroneConfig)
    individual_configs: List[DroneConfig] = field(default_factory=list)

    def validate(self) -> None:
        """Validate the swarm configuration."""
        # Basic parameter validation
        ConfigValidator.validate_positive_number(self.num_drones, "num_drones")
        if self.num_drones > 50:  # Reasonable upper limit
            raise ValueError("num_drones should not exceed 50 for simulation performance")

        valid_patterns = ["grid", "random", "cluster", "line", "circle"]
        if self.deployment_pattern not in valid_patterns:
            raise ValueError(f"deployment_pattern must be one of {valid_patterns}")

        # Spatial parameter validation
        ConfigValidator.validate_positive_number(self.area_size, "area_size")
        ConfigValidator.validate_positive_number(self.min_distance, "min_distance")

        # Check spatial capacity
        max_drones_in_area = (self.area_size / self.min_distance) ** 2
        if self.num_drones > max_drones_in_area:
            raise ValueError(f"Too many drones for area size. Max: {int(max_drones_in_area)}")

        valid_formations = ["rigid", "flexible", "free"]
        if self.formation_type not in valid_formations:
            raise ValueError(f"formation_type must be one of {valid_formations}")

        # Collaboration parameter validation
        if self.enable_collaboration:
            ConfigValidator.validate_positive_number(self.max_collaboration_distance, "max_collaboration_distance")
            ConfigValidator.validate_range(self.collaboration_threshold, 0.0, 1.0, "collaboration_threshold")

        # Topology parameter validation
        valid_topologies = ["static", "dynamic", "mesh", "star", "tree"]
        if self.topology_type not in valid_topologies:
            raise ValueError(f"topology_type must be one of {valid_topologies}")

        if self.connectivity_maintenance:
            ConfigValidator.validate_range(self.min_connectivity_ratio, 0.0, 1.0, "min_connectivity_ratio")

        # Load balancing parameter validation
        if self.enable_load_balancing:
            valid_algorithms = ["round_robin", "weighted_random", "least_loaded", "geographic"]
            if self.load_balancing_algorithm not in valid_algorithms:
                raise ValueError(f"load_balancing_algorithm must be one of {valid_algorithms}")
            ConfigValidator.validate_positive_number(self.rebalance_interval, "rebalance_interval")

        # Fault tolerance parameter validation
        valid_fault_levels = ["low", "medium", "high"]
        if self.fault_tolerance_level not in valid_fault_levels:
            raise ValueError(f"fault_tolerance_level must be one of {valid_fault_levels}")

        ConfigValidator.validate_positive_number(self.redundancy_factor, "redundancy_factor")

        valid_recovery = ["manual", "automatic", "hybrid"]
        if self.recovery_strategy not in valid_recovery:
            raise ValueError(f"recovery_strategy must be one of {valid_recovery}")

        # Validate the drone configuration template
        self.drone_template.validate()

        # Validate individual configurations
        if self.individual_configs:
            if len(self.individual_configs) != self.num_drones:
                raise ValueError(f"individual_configs length ({len(self.individual_configs)}) "
                               f"must match num_drones ({self.num_drones})")
            for i, config in enumerate(self.individual_configs):
                try:
                    config.validate()
                except Exception as e:
                    raise ValueError(f"Invalid config for drone {i}: {e}")
                    
    def generate_individual_configs(self) -> List[DroneConfig]:
        """Generate individual configurations based on the template and deployment pattern."""
        configs = []

        # Generate positions
        positions = self._generate_positions()

        for i in range(self.num_drones):
            # Copy the template
            config = DroneConfig(
                drone_id=f"drone_{i}",
                initial_position=positions[i],
                max_computation_capacity=self.drone_template.max_computation_capacity,
                communication_radius=self.drone_template.communication_radius,
                max_bandwidth=self.drone_template.max_bandwidth,
                mobility_enabled=self.drone_template.mobility_enabled,
                max_speed=self.drone_template.max_speed,
                movement_pattern=self.drone_template.movement_pattern,
                initial_battery=self.drone_template.initial_battery,
                failure_probability=self.drone_template.failure_probability
            )
            configs.append(config)
            
        self.individual_configs = configs
        return configs
        
    def _generate_positions(self) -> List[Tuple[float, float]]:
        """Generate positions based on the deployment pattern."""
        import math
        import random

        positions = []

        if self.deployment_pattern == "grid":
            # Grid deployment
            side_length = math.ceil(math.sqrt(self.num_drones))
            spacing = self.area_size / (side_length + 1)
            
            for i in range(self.num_drones):
                row = i // side_length
                col = i % side_length
                x = spacing * (col + 1)
                y = spacing * (row + 1)
                positions.append((x, y))
                
        elif self.deployment_pattern == "random":
            # Random deployment
            random.seed(42)  # Ensure reproducibility
            for _ in range(self.num_drones):
                x = random.uniform(0, self.area_size)
                y = random.uniform(0, self.area_size)
                positions.append((x, y))
                
        elif self.deployment_pattern == "cluster":
            # Cluster deployment
            center_x, center_y = self.area_size / 2, self.area_size / 2
            cluster_radius = min(self.area_size / 4, self.min_distance * self.num_drones / 4)

            for i in range(self.num_drones):
                angle = 2 * math.pi * i / self.num_drones
                radius = cluster_radius * (0.5 + 0.5 * (i % 2))  # Two concentric rings
                x = center_x + radius * math.cos(angle)
                y = center_y + radius * math.sin(angle)
                positions.append((x, y))
                
        elif self.deployment_pattern == "line":
            # Linear deployment
            spacing = self.area_size / (self.num_drones + 1)
            y = self.area_size / 2
            
            for i in range(self.num_drones):
                x = spacing * (i + 1)
                positions.append((x, y))
                
        elif self.deployment_pattern == "circle":
            # Circular deployment
            center_x, center_y = self.area_size / 2, self.area_size / 2
            radius = min(self.area_size / 3, self.area_size / 2 - 10)
            
            for i in range(self.num_drones):
                angle = 2 * math.pi * i / self.num_drones
                x = center_x + radius * math.cos(angle)
                y = center_y + radius * math.sin(angle)
                positions.append((x, y))
                
        return positions


def create_standard_swarm_configs() -> Dict[str, DroneSwarmConfig]:
    """Create standard swarm configurations."""
    configs = {}

    # Small collaborative swarm
    configs["small_collab"] = DroneSwarmConfig(
        num_drones=10,
        deployment_pattern="grid",
        enable_collaboration=True,
        topology_type="dynamic",
        enable_load_balancing=True,
        fault_tolerance_level="medium"
    )
    
    # Medium distributed swarm
    configs["medium_distributed"] = DroneSwarmConfig(
        num_drones=10,
        deployment_pattern="random",
        enable_collaboration=True,
        max_collaboration_distance=150.0,
        topology_type="mesh",
        enable_load_balancing=True,
        fault_tolerance_level="high"
    )
    
    # Large high-availability swarm
    configs["large_ha"] = DroneSwarmConfig(
        num_drones=20,
        deployment_pattern="cluster",
        enable_collaboration=True,
        topology_type="dynamic",
        connectivity_maintenance=True,
        min_connectivity_ratio=0.9,
        enable_load_balancing=True,
        load_balancing_algorithm="least_loaded",
        fault_tolerance_level="high",
        redundancy_factor=1.5
    )
    
    # High-mobility swarm
    configs["high_mobility"] = DroneSwarmConfig(
        num_drones=8,
        deployment_pattern="line",
        formation_type="flexible",
        enable_collaboration=True,
        topology_type="dynamic",
        drone_template=DroneConfig(
            mobility_enabled=True,
            max_speed=15.0,
            movement_pattern="random_waypoint"
        )
    )
    
    return configs


if __name__ == "__main__":
    # Test the drone configuration
    print("Testing drone configuration...")

    # Single-drone configuration test
    drone_config = DroneConfig()
    drone_config.validate()
    print("✓ Drone configuration validation passed")

    # Swarm configuration test
    swarm_config = DroneSwarmConfig()
    swarm_config.validate()
    print("✓ Swarm configuration validation passed")

    # Generate individual configurations
    individual_configs = swarm_config.generate_individual_configs()
    print(f"✓ Generated {len(individual_configs)} individual configurations")

    # Standard configuration test
    standard_configs = create_standard_swarm_configs()
    for name, config in standard_configs.items():
        config.validate()
        print(f"✓ Standard configuration {name} validation passed")

    print("\nDrone configuration module tests complete!")