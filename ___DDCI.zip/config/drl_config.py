"""
DRL configuration module.

Provides DRL training and inference configuration based on the reinforcement
learning architecture in CLAUDE.md.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from .base_config import BaseConfig, ConfigValidator


@dataclass
class DRLConfig(BaseConfig):
    """DRL agent configuration class."""

    # State space configuration (based on CLAUDE.md: s_i(t) in R^{3+2K})
    state_space_dim: int = 9  # State space dimension (3+2*3)
    neighbor_candidates_k: int = 3  # K candidate neighbors

    # State feature configuration
    self_state_features: List[str] = field(default_factory=lambda: [
        "flops_norm",      # Normalized FLOPS requirement of the current task
        "queue_load",      # Queue load
        "busy_rate"        # Busy rate
    ])

    neighbor_state_features: List[str] = field(default_factory=lambda: [
        "distance_norm",   # Normalized distance
        "load_rate"        # Load rate
    ])

    # Action space configuration
    action_space_type: str = "discrete"  # Action space type: "discrete", "continuous", "hybrid"

    # Discrete action space (partner_idx, layer_cut)
    partner_selection_actions: int = 3  # Number of collaboration partner selection actions
    layer_cut_actions: int = 9  # Number of partition point selection actions (1-9) ResNet18
    total_discrete_actions: int = 27  # 3 x 9 = 27

    # Network architecture configuration
    network_type: str = "mlp"  # Network type: "mlp", "cnn", "rnn", "transformer"
    hidden_layers: List[int] = field(default_factory=lambda: [256, 128, 64])
    activation_function: str = "relu"  # Activation function
    use_dueling: bool = False  # Use a Dueling network
    use_double_q: bool = True  # Use Double Q-Learning

    # Output head configuration
    separate_output_heads: bool = True  # Separate output heads
    partner_head_dim: int = 3  # Collaboration partner selection head dimension
    layer_head_dim: int = 9    # Layer partition head dimension (ResNet18)

    def validate(self) -> None:
        """Validate the DRL configuration."""
        # State space validation
        expected_dim = len(self.self_state_features) + len(self.neighbor_state_features) * self.neighbor_candidates_k
        if self.state_space_dim != expected_dim:
            raise ValueError(f"state_space_dim ({self.state_space_dim}) does not match "
                           f"expected dimension ({expected_dim})")
        
        ConfigValidator.validate_positive_number(self.neighbor_candidates_k, "neighbor_candidates_k")
        if self.neighbor_candidates_k > 10:
            raise ValueError("neighbor_candidates_k should not exceed 10")

        # Action space validation
        valid_action_types = ["discrete", "continuous", "hybrid"]
        if self.action_space_type not in valid_action_types:
            raise ValueError(f"action_space_type must be one of {valid_action_types}")

        if self.action_space_type == "discrete":
            ConfigValidator.validate_positive_number(self.partner_selection_actions, "partner_selection_actions")
            ConfigValidator.validate_positive_number(self.layer_cut_actions, "layer_cut_actions")
            
            expected_total = self.partner_selection_actions * self.layer_cut_actions
            if self.total_discrete_actions != expected_total:
                raise ValueError(f"total_discrete_actions should be {expected_total}")

        # Network architecture validation
        valid_network_types = ["mlp", "cnn", "rnn", "transformer"]
        if self.network_type not in valid_network_types:
            raise ValueError(f"network_type must be one of {valid_network_types}")

        for i, layer_size in enumerate(self.hidden_layers):
            ConfigValidator.validate_positive_number(layer_size, f"hidden_layers[{i}]")

        valid_activations = ["relu", "tanh", "sigmoid", "leaky_relu", "elu"]
        if self.activation_function not in valid_activations:
            raise ValueError(f"activation_function must be one of {valid_activations}")

        # Output head validation
        if self.separate_output_heads:
            if self.partner_head_dim != self.partner_selection_actions:
                raise ValueError("partner_head_dim should match partner_selection_actions")
            if self.layer_head_dim != self.layer_cut_actions:
                raise ValueError("layer_head_dim should match layer_cut_actions")


@dataclass
class TrainingConfig(BaseConfig):
    """DRL training configuration class."""

    # Basic training parameters
    algorithm: str = "dqn"  # Algorithm: "dqn", "ddqn", "ppo", "sac", "td3"
    total_timesteps: int = 100000  # Total number of training steps
    learning_rate: float = 1e-3  # Learning rate
    batch_size: int = 32  # Batch size

    # Exploration parameters
    exploration_method: str = "epsilon_greedy"  # Exploration method
    initial_epsilon: float = 1.0  # Initial exploration rate
    final_epsilon: float = 0.05  # Final exploration rate
    epsilon_decay_steps: int = 50000  # Number of exploration rate decay steps

    # Experience replay configuration
    buffer_size: int = 50000  # Experience replay buffer size
    replay_start_size: int = 1000  # Minimum number of experiences before replay starts
    prioritized_replay: bool = False  # Prioritized experience replay

    # Network update configuration
    target_update_frequency: int = 1000  # Target network update frequency
    gradient_steps: int = 1  # Number of gradient steps per update
    max_grad_norm: float = 10.0  # Gradient clipping threshold

    # Reward function configuration (based on the CLAUDE.md formula)
    reward_weights: Dict[str, float] = field(default_factory=lambda: {
        "completion": 1.0,      # Completion reward weight
        "latency_penalty": 0.5, # Latency penalty weight (alpha)
        "comm_penalty": 0.3     # Communication cost penalty weight (beta)
    })

    # Priority weights (based on CLAUDE.md)
    priority_weights: Dict[str, float] = field(default_factory=lambda: {
        "high": 4.0,       # w_3
        "medium": 2.0,     # w_2
        "low": 1.0,        # w_1
        "background": 0.5  # w_0
    })

    # Training schedule configuration
    evaluation_frequency: int = 5000  # Evaluation frequency
    save_frequency: int = 10000  # Model save frequency
    log_frequency: int = 1000   # Logging frequency

    # Environment configuration
    env_id: str = "DroneCollaboration-v0"  # Environment ID
    n_envs: int = 1  # Number of parallel environments
    normalize_observations: bool = True  # Normalize observations
    normalize_rewards: bool = False  # Normalize rewards

    # Early stopping and scheduling
    early_stopping: bool = True  # Early stopping
    patience: int = 20  # Early stopping patience
    min_improvement: float = 0.01  # Minimum improvement threshold

    # Learning rate schedule
    lr_schedule: str = "constant"  # Learning rate schedule: "constant", "linear", "exponential"
    lr_decay_rate: float = 0.99  # Learning rate decay rate

    def validate(self) -> None:
        """Validate the training configuration."""
        # Basic parameter validation
        valid_algorithms = ["dqn", "ddqn", "ppo", "sac", "td3", "a2c", "ppo2"]
        if self.algorithm not in valid_algorithms:
            raise ValueError(f"algorithm must be one of {valid_algorithms}")

        ConfigValidator.validate_positive_number(self.total_timesteps, "total_timesteps")
        ConfigValidator.validate_positive_number(self.learning_rate, "learning_rate")
        ConfigValidator.validate_positive_number(self.batch_size, "batch_size")

        # Exploration parameter validation
        valid_exploration = ["epsilon_greedy", "ucb", "thompson_sampling", "gaussian"]
        if self.exploration_method not in valid_exploration:
            raise ValueError(f"exploration_method must be one of {valid_exploration}")

        if self.exploration_method == "epsilon_greedy":
            ConfigValidator.validate_range(self.initial_epsilon, 0.0, 1.0, "initial_epsilon")
            ConfigValidator.validate_range(self.final_epsilon, 0.0, 1.0, "final_epsilon")
            if self.initial_epsilon < self.final_epsilon:
                raise ValueError("initial_epsilon should be >= final_epsilon")
            ConfigValidator.validate_positive_number(self.epsilon_decay_steps, "epsilon_decay_steps")

        # Experience replay validation
        ConfigValidator.validate_positive_number(self.buffer_size, "buffer_size")
        ConfigValidator.validate_positive_number(self.replay_start_size, "replay_start_size")
        if self.replay_start_size > self.buffer_size:
            raise ValueError("replay_start_size should not exceed buffer_size")

        # Network update validation
        ConfigValidator.validate_positive_number(self.target_update_frequency, "target_update_frequency")
        ConfigValidator.validate_positive_number(self.gradient_steps, "gradient_steps")
        ConfigValidator.validate_positive_number(self.max_grad_norm, "max_grad_norm")

        # Reward weight validation
        for weight_name, weight_value in self.reward_weights.items():
            ConfigValidator.validate_positive_number(weight_value, f"reward_weights[{weight_name}]")

        # Priority weight validation (based on the CLAUDE.md constraint)
        priority_order = ["background", "low", "medium", "high"]
        for i in range(len(priority_order) - 1):
            curr_weight = self.priority_weights[priority_order[i]]
            next_weight = self.priority_weights[priority_order[i + 1]]
            if curr_weight >= next_weight:
                raise ValueError(f"Priority weights must be increasing: {priority_order[i]} < {priority_order[i+1]}")

        # Training schedule validation
        ConfigValidator.validate_positive_number(self.evaluation_frequency, "evaluation_frequency")
        ConfigValidator.validate_positive_number(self.save_frequency, "save_frequency")
        ConfigValidator.validate_positive_number(self.log_frequency, "log_frequency")

        # Environment configuration validation
        ConfigValidator.validate_positive_number(self.n_envs, "n_envs")

        # Early stopping validation
        if self.early_stopping:
            ConfigValidator.validate_positive_number(self.patience, "patience")
            ConfigValidator.validate_positive_number(self.min_improvement, "min_improvement")

        # Learning rate schedule validation
        valid_schedules = ["constant", "linear", "exponential", "cosine"]
        if self.lr_schedule not in valid_schedules:
            raise ValueError(f"lr_schedule must be one of {valid_schedules}")
            
        if self.lr_schedule in ["exponential"]:
            ConfigValidator.validate_range(self.lr_decay_rate, 0.1, 1.0, "lr_decay_rate")


@dataclass
class EvaluationConfig(BaseConfig):
    """DRL evaluation configuration class."""

    # Basic evaluation parameters
    n_eval_episodes: int = 100  # Number of evaluation episodes
    eval_frequency: int = 5000  # Evaluation frequency
    deterministic: bool = True  # Deterministic evaluation

    # Evaluation metrics
    evaluation_metrics: List[str] = field(default_factory=lambda: [
        "episode_reward",
        "episode_length", 
        "task_completion_rate",
        "collaboration_rate",
        "average_latency",
        "load_balance_index"
    ])
    
    # Performance baselines
    baseline_algorithms: List[str] = field(default_factory=lambda: [
        "random",          # Random policy
        "greedy_local",    # Greedy local processing
        "always_collaborate", # Always collaborate
        "round_robin"      # Round-robin selection
    ])

    # Evaluation environment configuration
    eval_env_configs: List[str] = field(default_factory=lambda: [
        "standard",        # Standard environment
        "high_load",       # High-load environment
        "network_partitioned", # Network partition environment
        "dynamic"          # Dynamic environment
    ])

    # Statistical analysis configuration
    confidence_level: float = 0.95  # Confidence level
    statistical_tests: List[str] = field(default_factory=lambda: [
        "t_test",          # t-test
        "wilcoxon",        # Wilcoxon signed-rank test
        "mann_whitney"     # Mann-Whitney U test
    ])

    # Visualization configuration
    generate_plots: bool = True  # Generate plots
    plot_types: List[str] = field(default_factory=lambda: [
        "learning_curve",
        "reward_distribution", 
        "action_distribution",
        "collaboration_analysis"
    ])
    
    def validate(self) -> None:
        """Validate the evaluation configuration."""
        # Basic parameter validation
        ConfigValidator.validate_positive_number(self.n_eval_episodes, "n_eval_episodes")
        ConfigValidator.validate_positive_number(self.eval_frequency, "eval_frequency")

        # Confidence level validation
        ConfigValidator.validate_range(self.confidence_level, 0.8, 0.99, "confidence_level")


def create_drl_algorithm_configs() -> Dict[str, TrainingConfig]:
    """Create DRL algorithm configurations."""
    configs = {}

    # DQN configuration
    configs["dqn"] = TrainingConfig(
        algorithm="dqn",
        learning_rate=1e-3,
        batch_size=32,
        buffer_size=50000,
        target_update_frequency=1000,
        exploration_method="epsilon_greedy",
        initial_epsilon=1.0,
        final_epsilon=0.05
    )
    
    # Double DQN configuration
    configs["ddqn"] = TrainingConfig(
        algorithm="ddqn",
        learning_rate=5e-4,
        batch_size=64,
        buffer_size=100000,
        target_update_frequency=500,
        exploration_method="epsilon_greedy",
        initial_epsilon=0.9,
        final_epsilon=0.02,
        prioritized_replay=True
    )
    
    # PPO configuration
    configs["ppo"] = TrainingConfig(
        algorithm="ppo",
        learning_rate=3e-4,
        batch_size=256,
        n_envs=4,  # PPO typically uses parallel environments
        total_timesteps=200000
    )

    # SAC configuration (continuous action space)
    configs["sac"] = TrainingConfig(
        algorithm="sac",
        learning_rate=1e-3,
        batch_size=256,
        buffer_size=100000,
        gradient_steps=1,
        exploration_method="gaussian"
    )
    
    return configs


def create_training_scenarios() -> Dict[str, TrainingConfig]:
    """Create training scenario configurations."""
    configs = {}

    # Quick training configuration
    configs["quick"] = TrainingConfig(
        algorithm="dqn",
        total_timesteps=20000,
        learning_rate=1e-3,
        batch_size=16,
        buffer_size=10000,
        evaluation_frequency=2000,
        log_frequency=500
    )
    
    # Standard training configuration
    configs["standard"] = TrainingConfig(
        algorithm="ddqn",
        total_timesteps=100000,
        learning_rate=5e-4,
        batch_size=32,
        buffer_size=50000,
        prioritized_replay=True,
        evaluation_frequency=5000
    )
    
    # Deep training configuration
    configs["deep"] = TrainingConfig(
        algorithm="ddqn", 
        total_timesteps=500000,
        learning_rate=1e-4,
        batch_size=64,
        buffer_size=200000,
        target_update_frequency=2000,
        prioritized_replay=True,
        early_stopping=True,
        patience=30
    )
    
    # Multi-environment training configuration
    configs["multi_env"] = TrainingConfig(
        algorithm="ppo",
        total_timesteps=300000,
        learning_rate=3e-4,
        batch_size=512,
        n_envs=8,  # 8 parallel environments
        evaluation_frequency=10000
    )
    
    return configs


if __name__ == "__main__":
    # Test the DRL configuration
    print("Testing DRL configuration...")

    # Basic DRL configuration test
    drl_config = DRLConfig()
    drl_config.validate()
    print("✓ DRL configuration validation passed")

    # Training configuration test
    training_config = TrainingConfig()
    training_config.validate()
    print("✓ Training configuration validation passed")

    # Evaluation configuration test
    eval_config = EvaluationConfig()
    eval_config.validate()
    print("✓ Evaluation configuration validation passed")

    # Algorithm configuration test
    algorithm_configs = create_drl_algorithm_configs()
    for name, config in algorithm_configs.items():
        config.validate()
        print(f"✓ Algorithm configuration {name} validation passed")

    # Training scenario configuration test
    training_scenarios = create_training_scenarios()
    for name, config in training_scenarios.items():
        config.validate()
        print(f"✓ Training scenario {name} validation passed")

    # State space dimension validation
    expected_dim = len(drl_config.self_state_features) + len(drl_config.neighbor_state_features) * drl_config.neighbor_candidates_k
    print(f"✓ State space dimension: {expected_dim} (expected: {drl_config.state_space_dim})")

    # Action space size validation
    total_actions = drl_config.partner_selection_actions * drl_config.layer_cut_actions
    print(f"✓ Action space size: {total_actions}")

    print("\nDRL configuration module tests complete!")