"""
Simulation configuration module.

Provides the core configuration parameters for running simulations.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from .base_config import BaseConfig, ConfigValidator


@dataclass
class SimulationConfig(BaseConfig):
    """Simulation configuration class."""

    # Basic simulation parameters
    duration: float = 30.0  # Simulation duration (seconds)
    time_step: float = 0.1  # Simulation time step (seconds)
    random_seed: Optional[int] = 42  # Random seed

    # Scenario parameters
    area_size: float = 400.0  # Simulation area size (meters)
    area_bounds: Tuple[float, float, float, float] = (0.0, 0.0, 400.0, 400.0)  # (x_min, y_min, x_max, y_max)

    # Performance monitoring parameters
    metrics_update_interval: float = 1.0  # Metrics update interval (seconds)
    enable_detailed_logging: bool = True  # Enable detailed logging
    log_level: str = "INFO"  # Log level

    # Visualization parameters
    enable_visualization: bool = False  # Enable real-time visualization
    visualization_update_rate: float = 10.0  # Visualization update rate (Hz)
    save_animation: bool = False  # Save animation

    # Output parameters
    output_dir: str = "./simulation_results"  # Output directory
    save_intermediate_results: bool = True  # Save intermediate results
    result_format: str = "json"  # Result format ("json", "csv", "pickle")

    # Parallel processing parameters
    enable_parallel: bool = False  # Enable parallel processing
    num_workers: int = 4  # Number of worker processes

    def validate(self) -> None:
        """Validate the simulation configuration."""
        # Time parameter validation
        ConfigValidator.validate_positive_number(self.duration, "duration")
        ConfigValidator.validate_positive_number(self.time_step, "time_step")
        ConfigValidator.validate_positive_number(self.metrics_update_interval, "metrics_update_interval")
        
        if self.time_step > self.duration:
            raise ValueError("time_step cannot be larger than duration")
            
        # Spatial parameter validation
        ConfigValidator.validate_positive_number(self.area_size, "area_size")

        x_min, y_min, x_max, y_max = self.area_bounds
        if x_min >= x_max or y_min >= y_max:
            raise ValueError("Invalid area_bounds: min values must be less than max values")

        # Visualization parameter validation
        if self.enable_visualization:
            ConfigValidator.validate_positive_number(self.visualization_update_rate, "visualization_update_rate")

        # Log level validation
        valid_log_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if self.log_level not in valid_log_levels:
            raise ValueError(f"log_level must be one of {valid_log_levels}, got {self.log_level}")

        # Result format validation
        valid_formats = ["json", "csv", "pickle"]
        if self.result_format not in valid_formats:
            raise ValueError(f"result_format must be one of {valid_formats}, got {self.result_format}")

        # Parallel parameter validation
        if self.enable_parallel:
            ConfigValidator.validate_positive_number(self.num_workers, "num_workers")
            if self.num_workers > 16:  # Reasonable upper limit
                raise ValueError("num_workers should not exceed 16 for optimal performance")


@dataclass
class EnvironmentConfig(BaseConfig):
    """Environment configuration class."""

    # Physical environment parameters
    gravity: float = 9.81  # Gravitational acceleration
    air_density: float = 1.225  # Air density (kg/m^3)
    wind_speed: float = 0.0  # Wind speed (m/s)
    wind_direction: float = 0.0  # Wind direction (degrees)

    # Obstacle configuration
    enable_obstacles: bool = False  # Enable obstacles
    obstacle_density: float = 0.1  # Obstacle density
    obstacle_size_range: Tuple[float, float] = (10.0, 50.0)  # Obstacle size range

    # Network environment parameters
    base_communication_range: float = 200.0  # Base communication range (meters)
    communication_reliability: float = 0.95  # Communication reliability
    network_latency_base: float = 0.001  # Base network latency (seconds)
    network_bandwidth: float = 100.0  # Network bandwidth (Mbps)

    # Interference and noise
    enable_interference: bool = False  # Enable interference
    interference_level: float = 0.1  # Interference level (0-1)
    signal_noise_ratio: float = 20.0  # Signal-to-noise ratio (dB)

    def validate(self) -> None:
        """Validate the environment configuration."""
        # Physical parameter validation
        ConfigValidator.validate_positive_number(self.gravity, "gravity")
        ConfigValidator.validate_positive_number(self.air_density, "air_density")

        if self.wind_speed < 0:
            raise ValueError("wind_speed cannot be negative")

        ConfigValidator.validate_range(self.wind_direction, 0.0, 360.0, "wind_direction")

        # Obstacle parameter validation
        if self.enable_obstacles:
            ConfigValidator.validate_range(self.obstacle_density, 0.0, 1.0, "obstacle_density")
            min_size, max_size = self.obstacle_size_range
            if min_size >= max_size:
                raise ValueError("obstacle_size_range: min_size must be less than max_size")
            ConfigValidator.validate_positive_number(min_size, "obstacle_size_range[0]")

        # Network parameter validation
        ConfigValidator.validate_positive_number(self.base_communication_range, "base_communication_range")
        ConfigValidator.validate_probability(self.communication_reliability, "communication_reliability")
        ConfigValidator.validate_positive_number(self.network_latency_base, "network_latency_base")
        ConfigValidator.validate_positive_number(self.network_bandwidth, "network_bandwidth")

        # Interference parameter validation
        if self.enable_interference:
            ConfigValidator.validate_range(self.interference_level, 0.0, 1.0, "interference_level")
            if self.signal_noise_ratio < 0:
                raise ValueError("signal_noise_ratio cannot be negative")


@dataclass
class ScenarioConfig(BaseConfig):
    """Scenario configuration class: predefined simulation scenarios."""

    name: str = "default"  # Scenario name
    description: str = "Default simulation scenario"  # Scenario description

    # Scenario type
    scenario_type: str = "normal"  # "normal", "high_load", "network_partitioned", "dynamic"

    # Dynamic variation parameters
    enable_dynamic_topology: bool = True  # Enable dynamic topology
    topology_change_interval: float = 5.0  # Topology change interval (seconds)

    enable_load_variation: bool = True  # Enable load variation
    load_variation_amplitude: float = 0.3  # Load variation amplitude (0-1)
    load_variation_period: float = 10.0  # Load variation period (seconds)

    # Failure injection
    enable_failure_injection: bool = False  # Enable failure injection
    failure_rate: float = 0.01  # Failure rate (per second)
    failure_duration_range: Tuple[float, float] = (1.0, 5.0)  # Failure duration range (seconds)

    # Burst events
    enable_burst_events: bool = False  # Enable burst events
    burst_intensity: float = 2.0  # Burst intensity multiplier
    burst_duration: float = 2.0  # Burst duration (seconds)
    burst_frequency: float = 0.1  # Burst frequency (per second)

    def validate(self) -> None:
        """Validate the scenario configuration."""
        valid_scenario_types = ["normal", "high_load", "network_partitioned", "dynamic", "adversarial"]
        if self.scenario_type not in valid_scenario_types:
            raise ValueError(f"scenario_type must be one of {valid_scenario_types}")

        # Dynamic parameter validation
        if self.enable_dynamic_topology:
            ConfigValidator.validate_positive_number(self.topology_change_interval, "topology_change_interval")

        if self.enable_load_variation:
            ConfigValidator.validate_range(self.load_variation_amplitude, 0.0, 1.0, "load_variation_amplitude")
            ConfigValidator.validate_positive_number(self.load_variation_period, "load_variation_period")

        # Failure parameter validation
        if self.enable_failure_injection:
            ConfigValidator.validate_range(self.failure_rate, 0.0, 1.0, "failure_rate")
            min_dur, max_dur = self.failure_duration_range
            if min_dur >= max_dur:
                raise ValueError("failure_duration_range: min must be less than max")
            ConfigValidator.validate_positive_number(min_dur, "failure_duration_range[0]")

        # Burst event validation
        if self.enable_burst_events:
            ConfigValidator.validate_positive_number(self.burst_intensity, "burst_intensity")
            ConfigValidator.validate_positive_number(self.burst_duration, "burst_duration")
            ConfigValidator.validate_positive_number(self.burst_frequency, "burst_frequency")


def create_standard_scenarios() -> Dict[str, ScenarioConfig]:
    """Create standard simulation scenarios."""
    scenarios = {}

    # Baseline scenario
    scenarios["baseline"] = ScenarioConfig(
        name="baseline",
        description="Baseline test scenario: stable environment, uniform load",
        scenario_type="normal",
        enable_dynamic_topology=False,
        enable_load_variation=False,
        enable_failure_injection=False,
        enable_burst_events=False
    )

    # High-load scenario
    scenarios["high_load"] = ScenarioConfig(
        name="high_load",
        description="High-load test scenario: dense tasks, heavy network pressure",
        scenario_type="high_load",
        enable_dynamic_topology=True,
        topology_change_interval=3.0,
        enable_load_variation=True,
        load_variation_amplitude=0.5,
        load_variation_period=8.0
    )

    # Network partition scenario
    scenarios["network_partitioned"] = ScenarioConfig(
        name="network_partitioned",
        description="Network partition scenario: simulates communication outages and recovery",
        scenario_type="network_partitioned",
        enable_dynamic_topology=True,
        topology_change_interval=2.0,
        enable_failure_injection=True,
        failure_rate=0.05,
        failure_duration_range=(2.0, 8.0)
    )

    # Dynamic environment scenario
    scenarios["dynamic"] = ScenarioConfig(
        name="dynamic",
        description="Dynamic environment scenario: topology changes, load fluctuations, burst events",
        scenario_type="dynamic",
        enable_dynamic_topology=True,
        topology_change_interval=4.0,
        enable_load_variation=True,
        load_variation_amplitude=0.4,
        load_variation_period=12.0,
        enable_burst_events=True,
        burst_intensity=3.0,
        burst_duration=1.5,
        burst_frequency=0.05
    )
    
    return scenarios


if __name__ == "__main__":
    # Test the simulation configuration
    print("Testing simulation configuration...")

    # Basic configuration test
    config = SimulationConfig()
    config.validate()
    print(f"✓ Default configuration validation passed")

    # Environment configuration test
    env_config = EnvironmentConfig()
    env_config.validate()
    print("✓ Environment configuration validation passed")

    # Scenario configuration test
    scenarios = create_standard_scenarios()
    for name, scenario in scenarios.items():
        scenario.validate()
        print(f"✓ Scenario {name} validation passed")

    # Configuration save and load test
    try:
        config.save_to_file("./test_config.json")
        loaded_config = SimulationConfig.load_from_file("./test_config.json")
        print("✓ Configuration save and load test passed")

        # Clean up test file
        import os
        os.remove("./test_config.json")

    except Exception as e:
        print(f"✗ Configuration file test failed: {e}")

    print("\nSimulation configuration module tests complete!")