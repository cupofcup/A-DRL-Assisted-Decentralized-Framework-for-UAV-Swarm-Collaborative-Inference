"""
Dynamic Topology Environment

Three approaches to solving the fixed-policy problem:
1. Random initial deployment (re-randomize deployment every episode)
2. Mobility (positions change during execution)
3. Combination (random deployment + mobility)

Core idea: make neighbor relationships change dynamically, forcing the DRL to learn
genuinely dynamic decisions.
"""

import sys
import os
import numpy as np
from typing import Tuple, Dict

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from environment.drone_collaboration_env import DroneCollaborationEnv
from config import ConfigManager


class DynamicTopologyEnv(DroneCollaborationEnv):
    """
    Dynamic-topology drone collaboration environment

    Improvements:
    1. Randomly initialize drone positions each episode (break the fixed topology)
    2. Optional: movement at runtime (further increase dynamism)
    3. Force neighbor relationships to change, letting the DRL learn dynamic decisions
    """

    def __init__(
        self,
        config_manager: ConfigManager,
        num_drones: int = 10,
        k_neighbors: int = 3,
        simulation_time: float = 40.0,
        render_mode=None,
        enable_pipeline: bool = True,
        network_type: str = 'resnet-8',
        bandwidth_mbps: float = 400.0,  # 5GHz WiFi 802.11ac nominal bandwidth
        # New topology parameters
        randomize_positions: bool = False,   # whether to randomize initial positions (generally keep False)
        enable_mobility: bool = True,        # whether to enable periodic movement (recommended True)
        move_every_n_steps: int = 50,       # move once every N steps
        move_distance: float = 30.0,        # distance moved each time (meters)
        move_probability: float = 0.8,      # movement probability (0-1, 0.8 means 80% chance to move)
        area_size: float = 400.0,           # area size (meters)
        min_distance: float = 20.0,         # minimum spacing (avoid overlap)
        # Sensitivity-experiment parameters
        communication_radius: float = 200.0, # communication range (meters)
        task_rate_multiplier: float = 1.0,   # task arrival rate multiplier
        ablate_priority: bool = False,        # state-feature ablation
        ablate_deadline_urgency: bool = False,  # ablate deadline_urgency alone
        ablate_reward_priority: bool = False,  # reward-component ablation (w_p=1)
        ablate_priority_arbitration: bool = False,  # mechanism ablation (HIGH no longer preempts the fast partner first)
        ablate_pareto: bool = False,          # Pareto ablation
        fifo_mode: bool = False,              # queue ablation: FIFO scheduling (ignore priority)
        enable_preemption: bool = True,       # queue ablation: preemption switch
        enable_recovery: bool = True,         # ablation: link-recovery state machine switch
        reward_coeffs: dict = None,           # reward coefficients (sensitivity analysis)
        battery_capacity_wh: float = 100.0,   # battery capacity (can be reduced for stress testing)
        capacity_levels: list = None,         # heterogeneity experiment: custom compute-capability tiers
    ):
        """
        Initialize the dynamic-topology environment

        Args:
            randomize_positions: whether to randomize deployment on each reset (generally False)
            enable_mobility: whether to enable periodic movement (recommended True)
            move_every_n_steps: move once every N steps
            move_distance: distance moved each time (meters)
            area_size: deployment area size
            min_distance: minimum distance between drones (unused)
        """
        # Save topology parameters (before super().__init__)
        self.randomize_positions = randomize_positions
        self.enable_mobility = enable_mobility
        self.move_every_n_steps = move_every_n_steps
        self.move_distance = move_distance
        self.move_probability = move_probability
        self.area_size = area_size
        self.min_distance = min_distance

        # Movement-related state
        self.step_count = 0  # total step counter
        self.fixed_positions = {}  # stores the original fixed positions

        # Call the parent-class initializer
        super().__init__(
            config_manager=config_manager,
            num_drones=num_drones,
            k_neighbors=k_neighbors,
            simulation_time=simulation_time,
            render_mode=render_mode,
            enable_pipeline=enable_pipeline,
            network_type=network_type,
            bandwidth_mbps=bandwidth_mbps,
            communication_radius=communication_radius,
            task_rate_multiplier=task_rate_multiplier,
            ablate_priority=ablate_priority,
            ablate_deadline_urgency=ablate_deadline_urgency,
            ablate_reward_priority=ablate_reward_priority,
            ablate_priority_arbitration=ablate_priority_arbitration,
            ablate_pareto=ablate_pareto,
            fifo_mode=fifo_mode,
            enable_preemption=enable_preemption,
            enable_recovery=enable_recovery,
            reward_coeffs=reward_coeffs,
            battery_capacity_wh=battery_capacity_wh,
            capacity_levels=capacity_levels
        )

        # Record the fixed positions (for comparison)
        for drone_id in self.task_queues.keys():
            drone_state = self.spatial_manager.drones[drone_id]
            self.fixed_positions[drone_id] = drone_state.position

        if self.randomize_positions:
            print(f"[TOPOLOGY] Random initial deployment enabled")
            print(f"  Area size: {area_size}m x {area_size}m")

        if self.enable_mobility:
            print(f"[MOBILITY] Periodic movement enabled")
            print(f"  Move every: {move_every_n_steps} steps")
            print(f"  Move distance: {move_distance} meters")
            print(f"  Move probability: {move_probability:.0%} (each drone independently)")
            print(f"  -> Neighbor relationships will change dynamically, forcing the DRL to learn dynamic decisions")

    def _generate_random_positions(self) -> Dict[str, Tuple[float, float]]:
        """
        Generate random but reasonable drone positions

        Constraints:
        1. Within the area bounds
        2. Maintain a minimum distance from each other
        3. Ensure all drones are within communication range (connected graph)

        Returns:
            positions: {drone_id: (x, y)}
        """
        positions = {}
        drone_ids = list(self.task_queues.keys())
        max_attempts = 1000

        for drone_id in drone_ids:
            placed = False
            for attempt in range(max_attempts):
                # Random position
                x = np.random.uniform(50, self.area_size - 50)
                y = np.random.uniform(50, self.area_size - 50)
                new_pos = np.array([x, y])

                # Check the distance from already-placed drones
                valid = True
                for other_id, other_pos in positions.items():
                    dist = np.linalg.norm(new_pos - np.array(other_pos))
                    if dist < self.min_distance:
                        valid = False
                        break

                if valid:
                    positions[drone_id] = (x, y)
                    placed = True
                    break

            if not placed:
                # On failure, use the fixed position
                positions[drone_id] = self.fixed_positions[drone_id]

        return positions

    def _perform_periodic_movement(self):
        """
        Task-aware / coverage-oriented movement (replaces pure random walk):

        Strategy:
        1. UAVs with pending tasks: move toward the task-generation location (respond to task hotspots)
        2. Idle UAVs: coverage patrol (move away from other UAVs, fill empty regions)
        3. Repulsion: all UAVs keep a minimum distance (avoid clustering, keep coverage dispersed)

        More realistic than a pure random walk (UAVs are attracted by tasks), and more
        flexible than a fixed formation.
        """
        if not self.enable_mobility:
            return

        moved_count = 0
        repulsion_radius = 80.0  # repulsion radius (meters)

        drone_ids = list(self.task_queues.keys())
        positions = {did: np.array(self.spatial_manager.drones[did].position) for did in drone_ids}

        for drone_id in drone_ids:
            if np.random.random() > self.move_probability:
                continue

            current_pos = positions[drone_id]

            # --- Repulsion: move away from neighbors that are too close (coverage balance) ---
            rep = np.array([0.0, 0.0])
            for other_id, other_pos in positions.items():
                if other_id == drone_id:
                    continue
                diff = current_pos - other_pos
                d = np.linalg.norm(diff)
                if 0 < d < repulsion_radius:
                    rep += (diff / d) * (repulsion_radius - d) / repulsion_radius

            # --- Attraction: toward the nearest task location or coverage direction ---
            queue = self.task_queues[drone_id]
            # Collect the locations of this UAV's pending tasks
            task_positions = []
            for p_queue in queue.priority_queues.values():
                for entry in p_queue:
                    if hasattr(entry, 'task') and hasattr(entry.task, 'location'):
                        task_positions.append(np.array(entry.task.location))

            if task_positions:
                # Has tasks: move toward the nearest task location
                dists = [np.linalg.norm(tp - current_pos) for tp in task_positions]
                nearest_task = task_positions[int(np.argmin(dists))]
                attract = nearest_task - current_pos
                attract_norm = np.linalg.norm(attract)
                if attract_norm > 1.0:
                    attract = attract / attract_norm
                else:
                    attract = np.array([0.0, 0.0])
            else:
                # No tasks: coverage patrol (spread away from the area center + random)
                center = np.array([self.area_size / 2, self.area_size / 2])
                to_edge = current_pos - center
                edge_norm = np.linalg.norm(to_edge)
                if edge_norm > 1.0:
                    attract = to_edge / edge_norm * 0.3  # slight outward spread
                else:
                    attract = np.array([0.0, 0.0])
                # Add a random direction
                angle = np.random.uniform(0, 2 * np.pi)
                attract += np.array([np.cos(angle), np.sin(angle)]) * 0.7

            # --- Compose the movement direction ---
            direction = attract + rep * 0.4  # repulsion weight 0.4
            dir_norm = np.linalg.norm(direction)
            if dir_norm > 0.01:
                direction = direction / dir_norm
            else:
                # Degenerate case: random direction
                angle = np.random.uniform(0, 2 * np.pi)
                direction = np.array([np.cos(angle), np.sin(angle)])

            # Movement distance
            distance = np.random.uniform(self.move_distance * 0.5, self.move_distance)
            new_pos = current_pos + direction * distance

            # Clamp within the area
            new_pos[0] = np.clip(new_pos[0], 50, self.area_size - 50)
            new_pos[1] = np.clip(new_pos[1], 50, self.area_size - 50)

            # Doppler realization: derive a continuous cruise velocity vector from this
            # displacement over the interval between two movements, and persist it to
            # DroneState.velocity. This makes the relative speed nonzero at each subsequent
            # decision step, so the Doppler penalty (signal_attenuation.calculate_sinr) truly
            # takes effect instead of being nominal only.
            # Interval = move_every_n_steps x step size (0.1s).
            move_interval_s = max(1e-3, self.move_every_n_steps * 0.1)
            actual_disp = new_pos - current_pos
            velocity = tuple(actual_disp / move_interval_s)  # (vx, vy) m/s

            # Update position + velocity
            self.spatial_manager.update_drone_position(drone_id, tuple(new_pos), velocity)
            positions[drone_id] = new_pos  # update this round's position for subsequent UAV repulsion calculations
            moved_count += 1

    def step(self, action: int):
        """
        Execute one step, including periodic movement
        """
        # Increment the step counter
        self.step_count += 1

        # Check whether movement is needed (move once every N steps)
        if self.enable_mobility and (self.step_count % self.move_every_n_steps == 0):
            self._perform_periodic_movement()

        # Call the parent-class step
        return super().step(action)

    def reset(self, seed=None, options=None):
        """
        Reset the environment, including position initialization
        """
        # Call the parent-class reset
        obs, info = super().reset(seed=seed, options=options)

        # Reset the step counter
        self.step_count = 0

        # Randomize initial positions (if enabled)
        if self.randomize_positions:
            new_positions = self._generate_random_positions()
            for drone_id, pos in new_positions.items():
                self.spatial_manager.update_drone_position(drone_id, pos)

            # Re-fetch the observation (positions changed)
            observation = self._get_observation()
            return observation.to_array(), info
        else:
            # Keep fixed initial positions, breaking the fixed topology via periodic movement
            return obs, info

    def get_topology_stats(self) -> Dict:
        """Get topology statistics"""
        positions = {}
        for drone_id in self.task_queues.keys():
            drone_state = self.spatial_manager.drones[drone_id]
            positions[drone_id] = np.array(drone_state.position)

        # Compute all distances
        all_distances = []
        for i, id1 in enumerate(sorted(positions.keys())):
            for id2 in sorted(positions.keys())[i+1:]:
                dist = np.linalg.norm(positions[id1] - positions[id2])
                all_distances.append(dist)

        # Compute the neighbor count of each drone (within 200 meters)
        neighbor_counts = []
        for drone_id in positions.keys():
            my_pos = positions[drone_id]
            neighbors = sum(
                1 for other_id, other_pos in positions.items()
                if other_id != drone_id and np.linalg.norm(my_pos - other_pos) <= 200
            )
            neighbor_counts.append(neighbors)

        return {
            'randomize_positions': self.randomize_positions,
            'enable_mobility': self.enable_mobility,
            'avg_distance': np.mean(all_distances),
            'min_distance': np.min(all_distances),
            'max_distance': np.max(all_distances),
            'avg_neighbors': np.mean(neighbor_counts),
            'min_neighbors': np.min(neighbor_counts),
            'max_neighbors': np.max(neighbor_counts),
        }


def test_topology_variations():
    """Test the effect of different topology configurations"""
    print("="*80)
    print("Topology dynamism test")
    print("="*80)

    config_manager = ConfigManager()

    # Test 1: fixed topology (baseline)
    print("\n[Test 1: fixed topology (current scheme)]")
    env1 = DynamicTopologyEnv(
        config_manager=config_manager,
        num_drones=10,
        k_neighbors=3,
        randomize_positions=False,  # fixed positions
        enable_mobility=False
    )

    # Run 3 episodes and see whether neighbors change
    neighbor_records_1 = []
    for ep in range(3):
        obs, info = env1.reset(seed=42 + ep)
        # Get the neighbor distances directly from the observation (distances of the first 3 neighbors)
        neighbor_dists = obs[3::2][:3]  # take the distance features
        neighbor_records_1.append(tuple(neighbor_dists))
        print(f"  Episode {ep+1}: drone_0 neighbor distances = {neighbor_dists}")

    stats1 = env1.get_topology_stats()
    print(f"  Average distance: {stats1['avg_distance']:.1f} meters")
    print(f"  Average neighbor count: {stats1['avg_neighbors']:.1f}")
    env1.close()

    # Test 2: random initial deployment
    print("\n[Test 2: random initial deployment]")
    env2 = DynamicTopologyEnv(
        config_manager=config_manager,
        num_drones=10,
        k_neighbors=3,
        randomize_positions=True,   # random positions
        enable_mobility=False
    )

    neighbor_records_2 = []
    for ep in range(3):
        obs, info = env2.reset(seed=42 + ep)
        neighbor_dists = obs[3::2][:3]
        neighbor_records_2.append(tuple(neighbor_dists))
        print(f"  Episode {ep+1}: drone_0 neighbor distances = {neighbor_dists}")

    stats2 = env2.get_topology_stats()
    print(f"  Average distance: {stats2['avg_distance']:.1f} meters")
    print(f"  Average neighbor count: {stats2['avg_neighbors']:.1f}")
    env2.close()

    # Test 3: random deployment + mobility
    print("\n[Test 3: random deployment + mobility]")
    env3 = DynamicTopologyEnv(
        config_manager=config_manager,
        num_drones=10,
        k_neighbors=3,
        randomize_positions=True,   # random positions
        enable_mobility=True,       # enable movement
        move_speed=10.0,            # 10 m/s
        move_interval=1.0
    )

    obs, info = env3.reset(seed=42)
    print("  Run 10 steps and observe neighbor changes:")

    for step in range(10):
        action = env3.action_space.sample()
        obs, reward, terminated, truncated, info = env3.step(action)

        if step % 3 == 0:  # print once every 3 steps
            neighbor_dists = obs[3::2][:3]
            print(f"    Step {step}: drone_0 neighbor distances = {neighbor_dists}")

        if terminated or truncated:
            break

    stats3 = env3.get_topology_stats()
    print(f"  Average distance: {stats3['avg_distance']:.1f} meters")
    print(f"  Average neighbor count: {stats3['avg_neighbors']:.1f}")
    env3.close()

    # Comparison conclusions
    print("\n" + "="*80)
    print("[Conclusions]")
    print("="*80)

    # Check whether neighbors change
    fixed_same = all(neighbor_records_1[0] == rec for rec in neighbor_records_1)
    random_same = all(neighbor_records_2[0] == rec for rec in neighbor_records_2)

    if fixed_same:
        print("[OK] Fixed topology: neighbor relationships never change (confirms the problem)")

    if not random_same:
        print("[OK] Random deployment: neighbor relationships differ across episodes (solves the fixed policy)")
    else:
        print("[WARN] Random deployment: neighbor relationships are still the same (may need a larger random range)")

    print("\nRecommended approaches:")
    print("  1. Simplest: enable randomize_positions=True (little code change needed)")
    print("  2. More realistic: randomize_positions=True + enable_mobility=True")
    print("  3. Key point: ensure neighbor relationships differ across episodes, forcing the DRL to learn dynamic decisions")
    print("="*80)


if __name__ == "__main__":
    test_topology_variations()
